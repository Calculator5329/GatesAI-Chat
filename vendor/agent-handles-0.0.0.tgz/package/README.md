# agent-handles

agent-handles gives every interactive element in a React app a stable,
readable identity, generates a registry of what exists, and lets an agent
drive the running app through those identities instead of guessing at CSS
selectors. Journeys are stored as data, compiled to Playwright for CI, and
every action an agent takes comes back with a receipt.

![An agent driving Fathom through nine pages over the drive API, one receipt per command](docs/replay.gif)

That is a real recording: 90 commands across nine pages of Fathom, a
market-analysis app, replayed from a journey file one command at a time and
paced so a person can follow it. Live demo with the recorded journeys and the
evidence table: https://agent-handles.web.app

## What it has done

GatesAI Chat, a desktop and web chat client, runs **104 generated end-to-end
journeys** on every e2e pass. They are data in its `journeys/manifest.json`,
compiled by agent-handles into `tests/e2e/journeys.generated.spec.ts`, and they
run on desktop, web and a 390x844 mobile viewport. Nobody hand-writes or
hand-edits those specs. After every step, each one also fails if a visible
control has no identity, an identity is missing from the registry, or two
controls share one. Its adoption went clean in one prompted pass: 223 of 223
control candidates identified.

The design was also checked head to head. Two blind agents got the same
test-writing task, one with selectors only and one with the registry and
drive. The registry spec came out 43% shorter and survived a UI refactor that
broke the selector spec
([results](docs/evidence/ab-experiment-2026-08-25/RESULTS.md)).

## Install and use

Not on npm yet. Install from a packed tarball or a file path, then:

```ts
// vite.config.ts (Webpack: AgentHandlesPlugin from agent-handles/webpack)
import { agentHandles } from "agent-handles/vite";
export default defineConfig({ plugins: [react(), agentHandles()] });
```

```sh
npx agent-handles adopt                # detect the app, scaffold, write the adoption prompt
npx agent-handles scan regenerate      # rebuild testid-registry.json from source
npx agent-handles ratchet check        # fail if identity coverage went down
npx agent-handles journeys compile     # journeys/manifest.json to Playwright specs
npx agent-handles journeys run --all   # replay every journey live through the drive API
```

Identities follow `area.component.element[.qualifier]`, like
`backtest.builder.add-portfolio`, and live in source as `data-testid`. `adopt`
never rewrites your code: it writes a prompt a coding agent works through in
gated checkpoints, and `adopt verify` decides when the app is actually done.
While the dev server runs, `GET /__agent-handles/registry` lists every identity
with the actions its element takes (`type` for a text box, `click` for a
button or dropdown trigger, none for a readout), and the dev server rewrites
the committed registry on every save. An agent can post
`{"action": "type", "testId": "ui.ticker-picker.search", "value": "TXRH"}` to
`/__agent-handles/command` and get back a receipt saying what the box holds
afterward. The drive only exists in dev: it binds to loopback, needs a
per-session token, and a test checks that production builds carry none of it.

More detail:

- [docs/guide.md](docs/guide.md): the identity grammar, every module, the drive
  API, journeys, the journey map, adoption, compatibility and current status
- [docs/resolve.md](docs/resolve.md): the optional English-to-handle layer
  (TypeSafe Jev, the reflex ledger, and the confidence cut behind `drive say`)
- [docs/compatibility.md](docs/compatibility.md): Vite 5 to 8, Webpack 5, CRA
- [docs/changelog.md](docs/changelog.md) and [docs/roadmap.md](docs/roadmap.md)

## app-explorer

app-explorer is the first tool built on the drive API, kept in a separate
private repository. It reads an app's registry, walks every reachable state
clicking every identified control, and keeps a screenshot, receipt log and
console and network transcript for each step. When something goes wrong
(a console error, a failed request, a control that does nothing, state that
does not survive a reload) it files a finding as a replayable journey with that
evidence attached. A fix counts only when the same journey replays clean. On
Fathom, one finding was a Monte Carlo page that broke on reload
because the dev server answered a data request with HTML; an agent fixed the
loading and the finding's journey replayed clean on main.

## How it was built

Coding agents wrote the code and ran the trials, across roughly 117 commits
between 2026-08-24 and 2026-09-18. Ethan directed it. The scanner, identity
grammar and registry schema were lifted from an earlier internal tool and made
into their own package. The decisions that shaped it were his:

- Fathom, his own app, would be the first adopter.
- The drive track had to earn its place. He had the A/B experiment run before
  building further, on the rule that if handles did not win, the track stopped.
- From watching the first live drive sessions: journeys that jump by URL and
  journeys that click through the real controls test different things, and
  coverage has to say which one it is.
- Identities are never injected at build time. Adding one is a reviewed source
  edit. The coverage floor only moves down.
- Authentication stays a wall. Pages behind a real login are recorded as out of
  reach, and real credentials are never automated.
- Keep the product on React with Vite and Webpack rather than chasing Vue and
  other frameworks.
- Production apps are acceptance tests for the package. When one exposed a gap,
  the fix went into the package and its bundled prompts, never into
  app-specific patches.

What verified it: a Vitest suite of about 330 tests; gates like the ratchet and
the no-executor-in-production check were each watched to fail before being
trusted; journeys had to pass twice in a row; and real adoptions on N2K
(146/146 controls), GatesAI Chat (223/223), the open-source Memos (462 resolved)
and a partial run on Actual Budget, which is recorded as unfinished rather than
green.

## License

MIT. See [LICENSE](LICENSE). Copyright (c) 2026 Ethan Gates.
