# agent-handles

Make a web app's interface addressable by AI agents.

Most AI agents drive a web page the way a stranger would: they read the DOM,
guess at CSS selectors, and hope the markup does not change underneath them.
agent-handles replaces the guessing with a contract. Every interactive
element in the app carries a stable, human-readable identity; a generated
registry describes everything that exists; and a small HTTP API lets an
agent operate the running app through those identities, getting a signed
receipt for every action it takes.

It is built as a set of adapters for [Vite](https://vitejs.dev/) projects,
but the artifacts it produces (registry, journeys, receipts) are plain JSON
with no framework assumptions.

A static showcase page (a recorded Fathom journey you can step through,
the live registry, and the evidence table) lives in `site/`; open
`site/index.html` directly or serve the directory with any static server.
Rebuild its inlined data from Fathom's committed artifacts with
`node site/build.mjs`.

## The idea in one example

A ticker search box in the app is written once, in source, with an identity:

```jsx
<input data-testid="ui.ticker-picker.search" ... />
```

From that single attribute, the toolchain derives everything else:

- The **registry** records that `ui.ticker-picker.search` exists, what kind
  of element it is, and which source file renders it.
- An agent can **drive** it: `{"action": "type", "testId":
  "ui.ticker-picker.search", "value": "TXRH"}` posted to the dev server
  types into the real page, letter by letter, with real keyboard events.
- The **receipt** that comes back says what actually happened, including the
  value the box holds *after* the keystrokes, so the agent notices if it
  typed into a box that was not empty.
- A recorded sequence of these commands is a **journey**, stored as data and
  compiled to a [Playwright](https://playwright.dev/) test for CI.
- A human can **watch** any journey replay live in their own browser tab,
  with a glowing cursor gliding between elements.

## Journey execution artifacts

Regenerate compiled specs after upgrading this package (`agent-handles journeys
compile`); do not hand-edit generated tests. Ordinary Playwright runs now attach
runtime observations, final-page screenshots, visual receipts and an artifact index
to each test under `testInfo.outputPath`. Retain the runner's normal output/report
artifacts when evidence is needed after the run. Tests no longer overwrite committed
`.agent-handles/runtime-observations` or manual visual-review baselines.

`adopt verify` creates a separate retained directory per command attempt under
`~/.cache/tmp/agent-handles-runs/`, and passes `AGENT_HANDLES_OBSERVATION_RUN` to its
configured `adoption.journeyVerifyCommand`. The command must preserve this inherited
environment for its Playwright child. Each attempt in `agent-handles-adoption.json`
records the exact run directory, identity, referenced relative paths and SHA-256
hashes. Failed attempts retain partial artifacts. These are diagnostic evidence,
not a replacement for manual surface reviews or a new baseline authority.

Current verification requires matching run, manifest and registry provenance plus
contained regular files with valid hashes. Copying historical files or changing
mtime cannot satisfy it. Project/test/retry identities prevent output collisions;
all retry artifacts remain available, while final retry outcomes follow Playwright's
existing success contract. Legacy observation inspection and live journey cumulative
observations remain historical. Existing committed observations are not deleted or
automatically refreshed. There is no automatic retention cleanup in this change.

## The identity grammar

Identities follow `area.component.element[.qualifier]`:

```
backtest.builder.picker-p1     the ticker picker for portfolio 1
app.nav.stock                  the Research link in the top nav
montecarlo.plan.starting-balance
ui.ticker-picker.option-TXRH   a dynamic option, matched by pattern
```

Three or four segments, kebab-case, from broad to narrow. The point is that
an identity survives refactors: the button can move files, change tags, and
restyle completely, and `backtest.builder.add-portfolio` still means the
same thing. Dynamic elements (one option per search result, one row per
holding) are declared as patterns like `ui.ticker-picker.option-*`.

## What is in the box

The package installs one CLI (`npx agent-handles`) and four importable
modules (`/scanner`, `/vite`, `/journeys`, `/drive`).

### Scanner and registry

`npx agent-handles scan regenerate` walks `.tsx` and `.jsx` source and
measures versioned **control candidates**, not an invented list of everything
that could ever be interactive:

- **Definite:** native controls, `a[href]`, semantic elements, and wrapper
  components configured by the adopter.
- **Review required:** event handlers, interactive ARIA roles, focusable
  elements, dynamic tag aliases, and composition patterns static code cannot
  prove.

Every candidate must finish identified, owner-approved non-interactive, or
owner-approved unreachable in the declared journey scope. Source detection is
measured; the latter classifications are narrated judgments and stay visibly
`needs_owner_verdict` until an owner records a choice. Empty or unsupported
scans refuse to produce green 0/0 evidence.

Existing projects may already use shorter or otherwise incompatible
`data-testid` values. Adoption inventories those declarations instead of
crashing before the prompt. The coding-agent phase replaces each one and
records an `identityRenames` relationship, or a reasoned
`identityTombstones` entry when the addressed surface was deliberately
removed. The registry refuses silent disappearance, identity reuse, rename
chains, and stale journeys; a stale reference reports its replacement when a
declared rename exists.

### The ratchet

`npx agent-handles ratchet check` compares the current scan against a
committed baseline and fails if identity coverage regressed. The floor
only moves down (fewer unidentified elements), never silently up. This is
paired with an interaction fingerprint: removing a handler, route control, or
candidate cannot masquerade as a coverage improvement. During a declared
adoption, reductions advance the baseline while new gaps remain unresolved;
once verification succeeds, the ratchet seals and any increase is a
regression.

### Vite plugin (verify-only)

`agentHandles()` in `vite.config` does two jobs: it verifies at build time
that the registry is in sync with the source, and *only during dev serve*
it injects the page executor that makes live driving possible. The plugin
never injects identities into the DOM at transform time; adding an id is
always a reviewed source edit. Production builds carry none of the drive
machinery, and a test asserts exactly that.

### Affected-test map (opt-in evidence)

After recording journeys and compiling their tests, add an `affectedMap`
object to `agent-handles.json` or the Vite plugin options:

```json
{
  "playwrightSpecPath": "e2e/journeys.generated.spec.ts",
  "affectedMap": { "repositoryRoot": "../.." }
}
```

`repositoryRoot` is relative to the application root; omit it for a repository
whose application is at its root. A production build emits `affected-map.json`
in the existing `agent-orchestrator/affected-selection-map/v1` shape, plus
`affected-map.evidence.json`. The adapter follows resolved static and dynamic
imports from the source controls named in each journey to their dependencies.
The test association defaults to `playwrightSpecPath`; applications with
separate specs can supply `testsByJourney`, mapping journey names to arrays of
existing test files relative to the application root. `fileName` changes the
map's build-output filename.

The evidence includes graph, source-file, test-file and manifest digests,
individual journey associations, and modules with no association. These are
positive associations for recorded journeys. The map is always marked partial
in its evidence: unvisited controls, server/RPC behavior, external packages,
and configuration changes are not proven safe by an absent edge. Invalid paths,
missing test files, unknown identities and incomplete imported graph edges
refuse emission. The output never changes test selection by itself; AO retains
that authority. Shadow comparison and independent review precede any replacement
of an authored map or full-suite verification.

### The drive API

While the dev server runs, agents talk to it over plain HTTP on loopback:

```
POST /__agent-handles/session        open a session, get a token
POST /__agent-handles/command        {token, command} -> receipt
GET  /__agent-handles/registry       what exists right now
GET  /__agent-handles/receipts       the session's full action log
```

The command vocabulary is `click`, `fill`, `type`, `press`, `hover`,
`right-click`, `select`, `expect`, `read`, `navigate`, and `observe`.
`press` accepts ordinary keys and modifier chords such as `Control+k`,
`Meta+Shift+p`, and `Alt+ArrowDown`.
`expect` waits for a predicate (visible, enabled, checked, contains-text)
and is how a journey asserts. `observe` returns a compact structured
snapshot of every identified element currently on screen, with its value
or text: the agent's cheap alternative to a screenshot. With
`includeUnidentified: true`, it also reports visible semantic controls without
an identity, concrete identities absent from the source registry, and duplicate
visible identities.

Every command returns a **receipt**: what ran, whether it succeeded, a
human-readable detail, timing, and a state echo (current URL, the target's
resulting value, any visible alert text). A journey is nothing more than a
replayable receipt log.

Inside the page, a small executor long-polls the middleware for commands
and executes them against the live DOM with synthetic pointer and keyboard
event sequences that frameworks (React included, Radix included) accept as
real interaction. Each page load registers as its own executor, and a
running journey is pinned to one page, so a second open tab can never
steal every other step.

### Journeys

A journey is a named list of steps in JSON, referencing identities only:

```json
{
  "name": "research-ticker-drill",
  "steps": [
    { "action": "click",  "testId": "app.nav.stock" },
    { "action": "type",   "testId": "ui.ticker-picker.search", "value": "TXRH" },
    { "action": "expect", "testId": "ui.ticker-picker.option-TXRH", "predicate": "visible" },
    { "action": "click",  "testId": "ui.ticker-picker.option-TXRH" }
  ]
}
```

`journeys compile` turns each journey into a Playwright spec (trusted CDP
input, real browser) for CI. After every step and settled render state, the
generated spec reconciles visible semantic controls, fails on unidentified,
registry-unknown, or duplicate controls, and writes path-bound runtime evidence. `journeys run
<name>` performs the same reconciliation while replaying live through the
drive API. Runtime results are always phrased as “N controls observed during M
journeys”; unvisited routes and states remain uncovered, never implicitly
green.

### The journey map

`npx agent-handles journeys map` renders a single self-contained HTML page:
every journey as a lane of colored step chips, hover tracing an identity
across journeys, a per-area coverage table, and a section for surfaces that
are deliberately out of reach (for example, everything behind real
authentication). The dev server also serves the map live at
`/__agent-handles/map` with a Run button per journey; each step's chip
lights up as its receipt streams back. Its **Review visible controls in app**
button turns on a dev-only page/state overlay in the application tab. Every
visible control is reconciled as identified, review-required, unidentified,
registry-unknown, or duplicate. The default issues view uses strong boxes only
for problems and quiet dots for identified controls; **All**, **Names**, and
**Not in journeys** views expose the rest without turning the app into a wall
of labels. Human-readable control text leads the review rail, while identity,
source, dynamic-pattern, and journey evidence remain available on selection.
Each declared page/state can save a durable measured receipt, and compiled
journeys save final-state screenshots. This is a visual review of the current
page and state, not an exhaustive runtime denominator; hidden states and
unvisited routes remain explicitly uncovered.

### The visible cursor

When a session asks for pacing (`paceMs > 0`), the page shows a small
emerald glow that glides to each target, ripples on clicks, flashes green
or red on assertions, and types at human speed. Replays default to 350ms a
step; agent sessions default to 0 and pay no slowdown. It is pure
rendering of drive activity, dev-only like the rest of the executor.

## Security model

The drive API binds to loopback and requires a per-session token even in
dev. Production builds contain no executor and no middleware; that absence
is asserted by a test against the built bundle, not by convention. The
scanner and registry never touch the network.

## Does the contract actually help?

The design was checked with an A/B experiment: the same test-writing task
given to agents with selectors-only access versus registry + drive access.
The registry arm's spec came out 43% shorter and survived a UI refactor
that broke the selector arm. The point of the identity layer is exactly
that second half: the contract holds when the markup moves.

## Quick start: one resumable adoption lifecycle

The deterministic coordinator is one command. It detects the framework, Vite
major, source roots, scripts, routes, Playwright configuration and `testDir`,
current identities, wrapper candidates, package-manager runtime, and existing
adoption state; writes only evidence and scaffolding; and creates a tailored
prompt for the coding agent. It places the generated journey spec inside the
detected Playwright suite, copies its supporting prompts under
`.agent-handles/prompts` so Yarn PnP installs work without `node_modules`, and
never rewrites application source or Vite configuration.

```sh
npm install --save-dev agent-handles   # private for now; installed via file path or packed tarball
npx agent-handles adopt
```

1. Read `.agent-handles/adoption-prompt.md`. If Vite is not wired, it carries
   an exact proposed import/plugin patch for the coding agent to apply:

   ```ts
   import { agentHandles } from "agent-handles/vite";
   export default defineConfig({ plugins: [react(), agentHandles()] });
   ```

2. Hand the tailored prompt to a coding agent. It runs four gated checkpoints:
   project reconnaissance, identity, journeys, then page/state evidence. The
   assessment groups candidates by file and carries one bounded work packet
   forward on every rerun; a large app advances source area by source area
   instead of receiving one enormous application-wide naming prompt. It also
   warns about mechanically generated identity names before journeys. The
   installed `/agent-handles-adopt` skill points at locally copied references:
   - `.agent-handles/prompts/project-reconnaissance.md`: reconciles routes,
     component libraries, custom wrappers, complex widgets, build/setup walls,
     and declared review surfaces.
   - `.agent-handles/prompts/identity-pass.md`: the loop that
     names every interactive element, audits the app's component library
     for wrappers the scanner cannot know in advance, and works until the
     scanner and ratchet both hold at zero. The ratchet is the referee, so
     the agent never has to guess whether it is done.
   - `.agent-handles/prompts/journey-authoring.md`: explores
     the running app live through the drive API (receipts, state echoes,
     observe snapshots), then records each real user goal as a journey and
     verifies it green twice under the compiled Playwright spec.
   - `.agent-handles/prompts/visual-review.md`: reviews every declared
     page/state in the issues-first overlay and saves measured evidence.
3. Finish with `npx agent-handles adopt verify`. The coordinator recomputes
   sources, holds the ratchet, runs a real production build, compares the
   emitted registry, compiles journeys, runs them twice, reconciles fresh
   runtime observations and visual receipts, and writes
   `agent-handles-adoption.json`. Incomplete or failed checks remain in that
   same receipt; an early legacy-identity or build failure no longer erases
   later evidence. Nonstandard monorepo build prerequisites belong in
   `adoption.buildCommand`, and dynamic Vite output directories can use
   `adoption.buildRegistryPath` when automatic emitted-registry discovery is
   insufficient.

Useful lifecycle commands:

```sh
npx agent-handles adopt --print-prompt
npx agent-handles adopt verify
npx agent-handles adopt decide <judgment-id> --choose <option-id>
```

Verification returns `in_progress`, `verified`,
`verified_with_owner_decisions`, `needs_owner_verdict`, `unsupported`, or
`failed`. Only verified statuses exit successfully. `init` remains a deprecated
alias for `adopt` until the next breaking release; new documentation teaches
only `adopt`.

Day-to-day commands remain `scan regenerate`, `scan check`, `ratchet check`,
`ratchet rebaseline`, `journeys compile`, `journeys map`, and `journeys run`.

## Compatibility

The first supported contract is React JSX/TSX with Vite 6, 7, and 8. Both
named and default plugin imports are supported, and the public type seam does
not couple adopters to this package's private Vite major. See
[`docs/compatibility.md`](docs/compatibility.md) for the packed-tarball matrix
and real-project evidence.

## Status

The hardened lifecycle's baseline trial is N2K-v3 on Vite 6: 146/146 static
control candidates identified (127 definite, 19 review-required), a
byte-identical production registry, and three control-path journeys green twice.
Those journeys observed 238 distinct runtime identities with zero unidentified
or duplicate controls; that is additive path evidence, not 238/238 runtime
coverage. Vite 7 acceptance caught two clickable table structures hidden by the
old denominator, and packed Vite 6/7/8 consumers all build clean. See
`docs/changelog.md`, `docs/compatibility.md`, and `docs/roadmap.md` for the
durable evidence and next work. A clean GatesAI Chat/Vite 8 adoption then
resolved 223/223 candidates in one prompted pass, migrated its legacy identity
vocabulary through declared renames, and ran five journeys twice with 71
path-bound controls observed and zero unidentified or duplicate controls. That
trial exposed the remaining scars closed here: Playwright suite placement,
modifier chords, registry-unknown runtime identities, mechanical names, and
human page/state review.

The first open-source component-system dogfood then ran against Memos on React
19/Vite 8 with Base UI, CVA/Tailwind, CodeMirror, TanStack Query Devtools,
guarded routes, repeated cards, and authenticated journeys. Its repaired rerun
resolved all 462 static candidates (454 identified and eight owner-approved
non-interactive), passed four journeys twice, and observed 106 path-bound
identity values with zero unidentified, registry-unknown, or duplicate
controls. The Home overlay simultaneously showed 73/73 visible controls
identified across eight repeated memo cards. That trial also keeps the claim
honest: nested route discovery, large-project batching, third-party widget
bridges, and host-owned journey setup are still the next adaptability gaps.

A subsequent Actual Budget trial exercised a much larger Yarn 4 PnP monorepo
on React 19/Vite 8. Reconnaissance expanded the honest denominator from 758 to
870 controls after five app-owned wrappers were configured. Two bounded prompt
packets resolved 47/47 controls and advanced automatically, including repeated
resource identities, legacy rename/split history, and a Toggle forwarding
bridge. The issues-first overlay rendered and persisted a problem receipt in
the live app. A final frozen-tarball clean rerun required no Agent Handles
package repair: it detected the repository-local Yarn runtime, copied readable
prompts, ran the project's declared sibling-build prerequisite, and proved a
fresh byte-identical `build/testid-registry.json`. The Actual adoption remains
intentionally `in_progress`—758 default-predicate controls (870 after wrapper
configuration), 98 legacy identities, journeys, and declared visual surfaces
still require the coding-agent passes. This is evidence that installation and
verification work, not a claim that a mature 500-file UI becomes fully adopted
instantly.

## Layout

```
bin/agent-handles.mjs   the CLI
src/scan/               static scanner + registry schema
src/vite/               the Vite plugin (verify + dev-only injection)
src/journeys/           journey schema, Playwright compiler, map, replay
src/drive/              middleware (server) + page executor (client)
src/visual/             durable page/state receipts and review gate
test/                   vitest suites for all of the above
site/                   static showcase page (no build step)
docs/                   changelog, roadmap, overview PDF
```

Run the whole suite with `npm test`.
