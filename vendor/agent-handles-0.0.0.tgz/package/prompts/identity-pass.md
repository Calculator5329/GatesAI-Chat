# agent-handles identity pass

You are an AI coding agent working inside a Vite app that has just installed
agent-handles. Your job in this pass: resolve every definite and
review-required control candidate, normally by giving the rendered control a
stable identity. Work until deterministic verification reports zero unresolved
candidates. The tooling below is your referee, so you never have to guess
whether you are done.

This supporting reference is selected by `npx agent-handles adopt`. The
project-specific source sites and Vite patch live in
`.agent-handles/adoption-prompt.md`; follow that tailored prompt first.

## Ground rules

1. Identities are **source edits**, never build-time injection. You add a
   `data-testid` attribute (or a testId prop) in the component's own file,
   like any reviewed code change.
2. The grammar is `area.component.element[.qualifier]`: three or four
   kebab-case segments, broad to narrow. Examples:
   `backtest.builder.add-portfolio`, `app.nav.settings`,
   `montecarlo.plan.starting-balance`, `income.table.row-toggle.aapl`.
3. Never invent a segment vocabulary per file. Read the ids that already
   exist (`testid-registry.json`, `entries`) and stay consistent with them.
   Treat button labels and nearby prose as evidence, not as strings to slug
   mechanically. Avoid ordinal suffixes (`toggle-2`) and long sentence-like
   element names; name the durable user intent instead.
4. Do not remove or rename a valid existing id casually. When the tailored
   prompt lists an invalid or legacy identity, migrate it deliberately: update
   source, tests, and journeys, then record `identityRenames` (or a reasoned
   `identityTombstones` entry for an intentionally removed surface). The
   verifier preserves that history and names the replacement to stale callers.
5. Never weaken the predicate or ratchet, raise a floor, remove an interaction,
   restructure source to hide a candidate, or edit generated evidence to
   manufacture success. The verifier recomputes source and fingerprints sites.

## The loop

Repeat until done:

1. `npx agent-handles scan regenerate`, then read `testid-registry.json`.
   The `unresolvedCandidates` array lists every definite or review-required
   source site that still needs an identity or an owner-approved disposition,
   with its evidence and source location.
   The `invalidIdentities` array is a separate measured migration list. It
   must also reach zero; never hide one by deleting the attribute alone.
2. Pick ONE area (one route or page worth of elements), then work through its
   candidate files in the assessment's listed order. Small, reviewable batches
   beat one giant sweep. Do not apply an app-wide identity codemod.
3. For each element in the area, decide its identity:
   - `area` is the route or page (`backtest`, `settings`), or `app` for
     chrome shared across pages (nav, footer, global dialogs), or `ui` for
     reusable widgets that appear inside many areas.
   - `component` is the widget the element lives in (`builder`, `nav`,
     `ticker-picker`).
   - `element` is the element's role in that widget (`search`,
     `add-portfolio`, `submit`), not its styling or tag name.
   - `qualifier` only when several siblings would otherwise collide.
4. Edit the source. Three shapes cover almost everything:
   - Plain element: `<button data-testid="backtest.builder.add-portfolio">`.
   - **Shared component rendered in several places:** never hardcode one id
     inside the shared file. Give the component a `testId` prop, forward it
     to `data-testid` on the interactive element, and pass a distinct id at
     each call site.
   - **Dynamic collections** (one option per search result, one row per
     item): use a template literal,
     `` data-testid={`ui.ticker-picker.option-${symbol}`} ``. The scanner
     registers the family as a pattern (`ui.ticker-picker.option-*`)
     automatically.
   - **Repeated component instances:** audit components rendered by `.map()`
     and components that can appear more than once even when the declaration
     itself is source-unique. A static id at the component call site will
     collide at runtime. Qualify the identity with a stable resource key and
     confirm the resulting family in the registry and live overlay.
   - **Third-party widgets:** first test whether the package forwards
     `data-testid` to the real DOM control. If not, add a small app-owned bridge
     around the stable interactive boundary. Never edit vendor code or claim a
     widget covered because its wrapper accepted an unused prop.
   - **Legacy identity:** replace the old value everywhere it is referenced
     and add an `identityRenames` entry in `agent-handles.json`, for example
     `"dock-collapsed-rail": "app.dock.collapsed-rail"`. If the surface is
     reused across several distinct source sites, split it with
     `{ "targets": ["app.dock.loading", "app.dock.error"], "reason": "..." }`.
     If the surface is truly removed, use `identityTombstones` with
     `removedAt` and a non-empty `reason`. A rename source cannot be silently
     reused, chained, or mapped to the same target as another source.
5. `npx agent-handles scan regenerate && npx agent-handles ratchet check`.
   The ratchet must report improved or held; if it reports regressed, you
   removed or broke an existing id, fix that before anything else.
6. Run the app's own checks (typecheck, tests) for the files you touched.
7. Commit the area with a message naming it, e.g.
   `handles: identity pass over settings (9 elements)`.

## When the scanner is blind

The scanner classifies definite native/semantic/wrapper controls separately
from review-required event handlers, ARIA roles, focusable elements, dynamic
tags, and uncertain compositions. A new app's component library is unknowable
in advance, so **expect wrapper configuration to be incomplete at first**.

Before your first batch, audit for wrappers the scanner does not know:

1. Read the app's component library (`src/components/ui/` or similar).
   Anything that renders an interactive element under the hood (a `Button`,
   `Link`, `MenuItem`, a Radix/shadcn trigger) is a wrapper the scanner
   should count.
2. Add those component names to `"interactiveComponents": [...]` in
   `agent-handles.json` (this extends the built-in list).
3. Rerun `scan regenerate` and inspect the new definite/review-required sites.
   Static candidates are source evidence, not a claim that every conditional
   runtime state has been visited.

This audit is the single most commonly skipped step, and skipping it is how
an app ends up "100% covered" with its nav links and every custom button
missing.

Also read `project-reconnaissance.md`. Its route, repeated-renderer, and complex
widget checks happen before the first identity batch and are carried into the
regenerated tailored prompt.

## Surfaces you must not cover

Some candidates are genuinely non-interactive or unreachable in the declared
journey scope, most commonly behind real authentication that automation must
never sign into. These are narrated scope reductions, not measured identities.
Add a `controlJudgments` entry keyed by the candidate's stable id, with source
and runtime evidence, at least two concrete options and consequences, and a
proposed default. It stays unresolved until an owner records a choice with
`agent-handles adopt decide`.

```json
"controlJudgments": {
  "candidate:stable-id": {
    "classification": "unreachable",
    "judgment": "Account controls require real authentication outside the declared journey scope.",
    "evidence": ["Route redirects to the production identity provider."],
    "options": [
      { "id": "identify", "consequence": "Add an identity and a safe fixture-backed journey." },
      { "id": "unreachable", "consequence": "Keep the route explicitly uncovered." }
    ],
    "proposal": "unreachable"
  }
}
```

## Done means

- `npx agent-handles scan regenerate` leaves `unresolvedCandidates` empty.
- `invalidIdentities` is empty and every migrated or removed identity is
  present in `identityHistory` through a declared rename or tombstone.
- `npx agent-handles ratchet check` holds at zero.
- `npx agent-handles scan check` passes (committed registry matches
  source).
- The wrapper audit above was actually performed, and
  `interactiveComponents` reflects this app's real component library.
- Every scope reduction carries a narrated owner decision; it is never folded
  into measured truth silently.
- The tailored prompt's identity-quality warnings are empty, or every
  intentionally exceptional name has a written acknowledgement in
  `adoption.identityNameNotes`.

Then move on to `journey-authoring.md` in this same directory.
