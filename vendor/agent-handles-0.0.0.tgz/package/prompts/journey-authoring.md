# agent-handles journey authoring

You are an AI coding agent in a React Vite or Webpack app whose identity pass is complete
(zero unidentified elements; see `identity-pass.md`). Your job in this
pass: turn the app's real user goals into recorded journeys that replay
live and run green under Playwright.

This supporting reference is selected by `npx agent-handles adopt` after the
identity checkpoint. The project-specific commands live in
`.agent-handles/adoption-prompt.md`.

## What a journey is

A named list of steps in `journeys/manifest.json`, referencing element
identities only, never CSS selectors:

```json
{
  "name": "research-ticker-drill",
  "title": "Find a ticker, then switch to another",
  "description": "Nav to Research, find TXRH letter by letter, open it, switch to AAPL through the header control.",
  "steps": [
    { "action": "click",  "testId": "app.nav.stock" },
    { "action": "type",   "testId": "ui.ticker-picker.search", "value": "TXRH" },
    { "action": "expect", "testId": "ui.ticker-picker.option-TXRH", "predicate": "visible" },
    { "action": "click",  "testId": "ui.ticker-picker.option-TXRH" },
    { "action": "expect", "testId": "stock.header.title", "predicate": "contains-text", "value": "TXRH" }
  ]
}
```

One journey per real user goal. Not one per element: a journey is a story
(build a portfolio and read the result; change a plan and see it recompute),
and its value is that an agent or a CI run can retell it.

## Explore live before you write

Do not author journeys from source reading alone. Run the dev server, then
drive the real app and watch what actually happens:

```sh
TOKEN=$(curl -s -X POST localhost:PORT/__agent-handles/session | jq -r .token)

# What is on screen right now (identified elements, values, alerts):
curl -s -X POST localhost:PORT/__agent-handles/command \
  -H 'content-type: application/json' \
  -d '{"token":"'$TOKEN'","command":{"action":"observe","includeUnidentified":true}}'

# Try a step; the receipt tells you what really happened:
curl -s -X POST localhost:PORT/__agent-handles/command \
  -H 'content-type: application/json' \
  -d '{"token":"'$TOKEN'","command":{"action":"click","testId":"app.nav.stock"}}'
```

Read every receipt. `ok` is not the interesting part; the `state` echo is:
the URL you landed on, the value a field actually holds after typing (typing
appends like real keystrokes), and any alert text the app raised. If a
receipt surprises you, the journey you were about to write was wrong.

Before choosing journeys, reconcile the router source, visible navigation,
guarded redirects, and `adoption.reviewSurfaces`. Static route detection is a
starting point only. Use local fixtures or host-owned setup for authentication;
never sign into a production account or place a credential in a journey.

The vocabulary: `click`, `fill` (one-shot value), `type` (letter by letter,
per-keystroke events, use for autocompletes), `press` (one key or a modifier
chord such as `Control+k`, `Meta+Shift+p`, or `Alt+ArrowDown`), `hover`,
`right-click`, `select` (native selects only; custom dropdowns are click
journeys against the options' own ids), `expect`
(visible / enabled / disabled / checked / unchecked / contains-text),
`read`, `navigate` (in-app path), `observe`.

## Journey design rules

1. **Assert, do not just act.** Every journey ends with an `expect` that
   proves the goal was reached, and uses intermediate `expect` steps
   wherever the app needs time (an option appearing, a result rendering).
   A journey of pure clicks that "passes" has proven nothing.
2. **Two kinds, both wanted.** Control-path journeys reach state through
   the UI controls; url-path journeys enter through a deep link
   (`navigate`) and verify the surface renders from the URL alone. Apps
   with shareable URLs need both told.
3. **Steps wait, journeys do not sleep.** `expect` and interactions
   already wait for their element. Never add artificial delay steps.
4. **Respect disclosure.** If a control is hidden behind a toggle or a
   menu, the journey opens it the way a user would; that disclosure is
   part of the story, not an obstacle.
5. **Stay outside declared walls.** Surfaces in
   `unreachableSurfaces` (agent-handles.json) get no journeys; automation
   never signs into real accounts.
6. **Cover areas, then flows across them.** Aim first for every reachable
   area appearing in at least one journey, then add the cross-area flows
   users actually perform.
7. **Runtime observation is additive.** An observed control proves only that
   it appeared on that journey path. Never report an observed count as N/N
   runtime coverage, and never infer unvisited routes or conditional states are
   green.

## Verify each journey three ways

1. **Live replay:** `npx agent-handles journeys run <name> --url
   http://localhost:PORT` with the app open in a browser tab. Watch the
   receipts; run it twice in a row (the second run starts from the state
   the first left behind, which catches missing resets and appended input).
2. **Compiled truth:** `npx agent-handles journeys compile`, then run the
   generated Playwright spec twice. The generated spec reconciles visible
   semantic controls after every step and writes fresh per-journey evidence;
   unidentified, registry-unknown, or duplicate controls fail. Green twice is
   the bar; a journey that passes once is not recorded, it is lucky.
3. **The map:** `npx agent-handles journeys map` and read it. Every
   reachable area should appear in the coverage table with at least one
   exercised id; the unreachable section should list exactly the declared
   walls, nothing more. In the live map, use **Review visible controls in app**
   on each meaningful page/state. Inspect every outlined badge and clear all
   unidentified, registry-unknown, and duplicate controls. Record this as
   reviewed page/state evidence only; never promote it to exhaustive runtime
   coverage.
4. **Final-state evidence:** each compiled journey saves a PNG plus a measured
   page/state receipt under `.agent-handles/visual-reviews/`. Inspect the image
   and use `visual-review.md` for states a journey does not finish on.

## Done means

- Every reachable area of the app appears in at least one journey.
- Every journey is green twice under the compiled Playwright spec.
- The journey map renders with no area at zero coverage except by an
  explicit, written decision (e.g. a styleguide page).
- `journeys/manifest.json` and the generated spec are committed, and the
  changelog records what the journeys cover.
- `npx agent-handles adopt verify` records two fresh runs and phrases runtime
  evidence as “N controls observed during M journeys; zero unidentified,” with
  unvisited states explicitly uncovered.
