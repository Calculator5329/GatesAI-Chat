# Agent Handles project reconnaissance

You are adapting Agent Handles to this project, not applying a generic test-ID
codemod. Before editing controls, build a compact model of how this application
actually renders interaction.

The tailored prompt and `.agent-handles/adoption-assessment.json` contain
measured starting evidence. Treat that evidence as a lead, not an exhaustive
route or component inventory.

## Establish the local execution context

Read package scripts, bundler configuration and existing test/emulator setup
before launching anything. Never infer that a script named start/dev is safe:
production applications can default to live backends. Use existing local
fixtures and fictional accounts; record missing infrastructure as a scope limit.
For Webpack read `webpack-integration.md` in this directory. The package supplies
the adapter; keep source changes limited to integration, identities and journeys.
Do not repair unrelated application behavior merely to make adoption pass.

## Set the application source scope

When UI imports cross monorepo packages, set `sourceRoots` to the application
and actually consumed UI directories, e.g. `[".", "../packages/ui"]`. Paths are
relative to this app root; the scanner and both build adapters use the same list.
Do not scan an entire repository merely to include one sibling library: unrelated
examples and other applications are not this app. Record the import evidence
supporting the list. `sourceRoots` overrides legacy `sourceRoot`, and explicit
missing paths fail. Dependency/VCS/generated-output directories are pruned.
After expanding roots, rerun `agent-handles adopt` before the identity batch.
During an unsealed, in-progress adoption it records a source-scope admission
receipt and initializes floors only for files outside the prior measured roots.
Old floors cannot rise, prior interaction sites cannot disappear, and prior roots
cannot be removed. Sealed adoptions cannot use this path. Never hand-reset the
ratchet to make a scope change pass.

If wrapper discovery exposes extra controls inside already measured files,
resolve the controls named by the ratchet error using `identity-pass.md` before
continuing the preferred batch or rerunning adopt. The source-scope admission
initializes newly included files; it does not raise old-file floors. Do not
remove the wrapper configuration or reset the ratchet to suppress the discovery.

## Inspect four seams

1. **Routes and states.** Read the router source, layout guards, redirects, and
   navigation controls. Compare those with the statically detected routes and
   with the running app. Declare the meaningful page/states that visual review
   must visit under `adoption.reviewSurfaces` in `agent-handles.json`:

   ```json
   {
     "adoption": {
       "visualReviewRequired": true,
       "reviewSurfaces": [
         { "id": "home-populated", "route": "/", "label": "Home with populated results" },
         { "id": "settings-account", "route": "/settings", "label": "Account settings" }
       ]
     }
   }
   ```

   A route can need several states, such as empty, populated, dialog open, or
   error. Do not claim that a route string represents every conditional state.

2. **Component boundaries.** Inspect the local UI/component folders and the
   installed design-system packages. Find wrappers that render buttons, links,
   inputs, menu items, triggers, tabs, and other controls. Confirm where a
   `testId` or `data-testid` reaches the rendered DOM. Add actual interactive
   wrapper names to `interactiveComponents`; do not add every capitalized JSX
   tag.

3. **Repeated renderers.** Search for `.map()`, virtualized rows, lists, cards,
   tree nodes, search results, and reusable controls mounted more than once.
   A source-unique static identity is not enough when several instances can be
   visible together. Use a stable resource key in a dynamic identity family,
   then let runtime duplicate detection prove the concrete instances differ.

4. **Complex and third-party widgets.** Inspect editors, canvases, grids,
   charts, devtools, portals, and slot/as-child composition. If the library
   does not forward DOM attributes, add a small app-owned bridge at the nearest
   stable interactive boundary. Hidden accessibility plumbing is runtime
   evidence, not a reason to ignore real small controls.

## Record what is learned

- Put deterministic wrapper and review-surface configuration in
  `agent-handles.json`.
- Put scope reductions in structured `controlJudgments` with evidence, two
  choices, consequences, and a proposed default.
- Keep app startup, fixture, and authentication commands under `adoption`.
- Rerun `npx agent-handles adopt` after reconnaissance. The next tailored
  prompt must carry the new project facts forward rather than relying on this
  agent's memory.

Reconnaissance is complete when the current prompt reflects the real wrapper
set, route sources, review surfaces, and host setup closely enough to begin one
bounded identity batch.
