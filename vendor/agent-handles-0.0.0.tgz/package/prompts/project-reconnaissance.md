# Agent Handles project reconnaissance

You are adapting Agent Handles to this project, not applying a generic test-ID
codemod. Before editing controls, build a compact model of how this application
actually renders interaction.

The tailored prompt and `.agent-handles/adoption-assessment.json` contain
measured starting evidence. Treat that evidence as a lead, not an exhaustive
route or component inventory.

## Inspect four seams

1. **Routes and states.** Read the router source, layout guards, redirects, and
   navigation controls. Compare those with the statically detected routes and
   with the running app. Declare the meaningful page/states that visual review
   must visit under `adoption.reviewSurfaces` in `agent-handles.json`:

   ```json
   {
     "adoption": {
       "visualReviewRequired": true,
       "reviewSurfaces": [
         { "id": "home-populated", "route": "/", "label": "Home with populated results" },
         { "id": "settings-account", "route": "/settings", "label": "Account settings" }
       ]
     }
   }
   ```

   A route can need several states, such as empty, populated, dialog open, or
   error. Do not claim that a route string represents every conditional state.

2. **Component boundaries.** Inspect the local UI/component folders and the
   installed design-system packages. Find wrappers that render buttons, links,
   inputs, menu items, triggers, tabs, and other controls. Confirm where a
   `testId` or `data-testid` reaches the rendered DOM. Add actual interactive
   wrapper names to `interactiveComponents`; do not add every capitalized JSX
   tag.

3. **Repeated renderers.** Search for `.map()`, virtualized rows, lists, cards,
   tree nodes, search results, and reusable controls mounted more than once.
   A source-unique static identity is not enough when several instances can be
   visible together. Use a stable resource key in a dynamic identity family,
   then let runtime duplicate detection prove the concrete instances differ.

4. **Complex and third-party widgets.** Inspect editors, canvases, grids,
   charts, devtools, portals, and slot/as-child composition. If the library
   does not forward DOM attributes, add a small app-owned bridge at the nearest
   stable interactive boundary. Hidden accessibility plumbing is runtime
   evidence, not a reason to ignore real small controls.

## Record what is learned

- Put deterministic wrapper and review-surface configuration in
  `agent-handles.json`.
- Put scope reductions in structured `controlJudgments` with evidence, two
  choices, consequences, and a proposed default.
- Keep app startup, fixture, and authentication commands under `adoption`.
- Rerun `npx agent-handles adopt` after reconnaissance. The next tailored
  prompt must carry the new project facts forward rather than relying on this
  agent's memory.

Reconnaissance is complete when the current prompt reflects the real wrapper
set, route sources, review surfaces, and host setup closely enough to begin one
bounded identity batch.
