# Agent Handles page and state review

Visual review checks the rendered application a person can see. It supplements
static candidates and journeys; it never creates an exhaustive runtime
denominator.

## Review loop

1. Start the application in its safe local or fixture-backed mode.
2. Open `npx agent-handles journeys map` in live mode and choose **Review
   visible controls in app**.
3. Visit each `adoption.reviewSurfaces` entry in its declared state. Use the
   application's controls to open menus, dialogs, disclosures, populated
   collections, empty states, and errors that matter to that surface.
4. Use the overlay's **Issues** view first. Clear every unidentified,
   registry-unknown, duplicate, and review-required control.
5. Use **Names** to inspect semantic identity quality and **Not in journeys**
   to find visible controls no recorded journey has observed.
6. Save a page/state receipt with a specific label. A problem-bearing receipt
   is preserved as evidence but cannot satisfy verification.
7. Compile and run journeys. Each completed journey writes a final-state PNG
   and JSON receipt under `.agent-handles/visual-reviews/`.

## Reading the interface

- Identified controls are quiet dots in the default issues view.
- Problems receive strong outlines and appear in the review rail.
- Human-readable control text is primary. The raw identity, source address,
  registry pattern, and journey names appear as supporting detail.
- Repeated instances remain individually measurable even when the rail groups
  their shared family.

## Honest completion

For each saved state, report: “N controls visible in this state; zero identity
issues.” Separately report how many declared states have receipts. Never call
that runtime coverage, and never render unvisited routes or hidden states as
green.

Visual review is complete when every declared surface has a current clean
receipt, every journey has a durable final-state screenshot, and
`npx agent-handles adopt verify` accepts the measured visual evidence.
