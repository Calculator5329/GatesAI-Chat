# Webpack 5 and Create React App integration

Use this adapter for Webpack 5, including react-scripts 5 and
react-app-rewired. Do not migrate the application's bundler. Inspect its actual
configuration and preserve every existing override, proxy, middleware, loader,
entry, and build check. Never edit node_modules or eject CRA.

## Webpack config

CommonJS and ESM can import the same public interface. For CommonJS:

```js
const { AgentHandlesPlugin, withAgentHandlesDevServer } = require('agent-handles/webpack');
module.exports = (env, argv) => {
  const config = makeExistingConfig(env, argv); // keep the existing config construction
  config.plugins = [...(config.plugins || []), new AgentHandlesPlugin({ drive: argv.mode === 'development' })];
  config.devServer = withAgentHandlesDevServer(config.devServer);
  return config;
};
```

For ESM use `import { AgentHandlesPlugin, withAgentHandlesDevServer } from
'agent-handles/webpack'`. Adapt an existing object export directly; for a
function export retain its arguments and return behavior. Multi-compiler apps
need the plugin on the browser compilation only. Set `appRoot` when compiler
context is a monorepo root, and use that same root for both helpers.

## CRA/react-app-rewired

The overrides file must retain both the existing webpack override and the
existing devServer override. A function-only export becomes the `webpack`
property of an object. The following is a composition example; replace
`existingWebpack` and `existingDevServer` with the existing functions (or omit
the calls when none exist), not undefined placeholders:

```js
const { AgentHandlesPlugin, withAgentHandlesDevServer } = require('agent-handles/webpack');
module.exports = {
  webpack(config, env) {
    config = existingWebpack(config, env);
    config.plugins.push(new AgentHandlesPlugin({ drive: env === 'development' }));
    return config;
  },
  devServer(configFunction) {
    const existing = existingDevServer(configFunction);
    return (proxy, allowedHost) => withAgentHandlesDevServer(existing(proxy, allowedHost));
  },
};
```

If CRA has no override mechanism, add react-app-rewired as a dev dependency and
change only the react-scripts command executable to react-app-rewired for start
and build; preserve all environment variables, flags and unrelated scripts.
Create the object override above without the `existing*` calls. Do not execute
an app's default start command until its backend destination is established.

## Local fixture and verification

1. Read existing emulator/E2E startup, authentication and seeding configuration.
   Use fictional seeded data and loopback services. Persist the exact safe
   startup and build commands in `agent-handles.json` adoption configuration.
   Missing real credentials do not justify connecting a test to production.
2. The plugin verifies identities and emits the same `testid-registry.json` as
   Vite. `drive: true` is only effective when Webpack mode is `development`.
   The dev-server helper installs the existing loopback/token-protected drive
   protocol. Both halves are required: a registry endpoint alone cannot drive
   a browser; browser executor injection alone cannot accept commands.
3. Run the unchanged app build, inspect emitted registry equality, then run the
   safe dev server and a real drive command in a browser. Verify the receipt
   reflects the actual post-action state. Production JS/HTML must contain no
   `__agent-handles` or `next-command` executor markers even with `drive: true`.
4. Run `agent-handles adopt` again and follow the refreshed identity/journey/
   visual review checkpoints. Finish with `agent-handles adopt verify`.

Static config detection is a reconnaissance clue; the build, runtime and
journey receipts determine verified adoption. If custom output paths are not
statically detected, set `adoption.buildRegistryPath` to the real emitted path.
The Vite affected-map option has no Webpack equivalent yet; report that feature
as unavailable rather than inventing an affected map.
