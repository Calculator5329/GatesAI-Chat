// Shared registry, ratchet and drive services used by build-tool adapters.
import fs from "node:fs/promises";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import {
  DEFAULT_CONFIG,
  extendInteractiveComponents,
  renderRegistry,
} from "../scan/index.mjs";
import { assertRatchetNotRaised, evaluateRatchet, emptyRatchet, RATCHET_SCHEMA } from "../ratchet/index.mjs";
import { createDriveMiddleware, DRIVE_CLIENT_PATH } from "../drive/index.mjs";
import { renderRuntimeActionabilityPredicate, renderRuntimeObservationPredicate } from "../runtime/observation.mjs";
import { readVisualReviews, writeVisualReview } from "../visual/review.mjs";


const execFileAsync = promisify(execFile);

async function readJson(file, fallback) {
  try { return JSON.parse(await fs.readFile(file, "utf8")); }
  catch (error) {
    if (error?.code === "ENOENT") return fallback;
    throw error;
  }
}


// The registry as committed at git HEAD, or undefined outside git or before
// its first commit.
async function committedRegistry(registryPath) {
  try {
    const { stdout } = await execFileAsync("git", ["-C", path.dirname(registryPath), "show", `HEAD:./${path.basename(registryPath)}`],
      { maxBuffer: 256 * 1024 * 1024 });
    return JSON.parse(stdout);
  } catch {
    return undefined;
  }
}

export function createAdapter(options = {}, root) {
  let stored = {};
  const paths = (root) => {
    const appRoot = path.resolve(root, options.appRoot ?? ".");
    const sourceRoots = options.sourceRoots ?? (options.sourceRoot === undefined ? stored.sourceRoots : undefined);
    if (sourceRoots !== undefined && (!Array.isArray(sourceRoots) || !sourceRoots.length || sourceRoots.some((entry) => typeof entry !== "string" || !entry.trim()))) throw new Error("sourceRoots must be a non-empty array of directory paths");
    return {
      appRoot,
      ...(sourceRoots && { sourceRoots: sourceRoots.map((directory) => path.resolve(appRoot, directory)) }),
      sourceRoot: path.resolve(appRoot, options.sourceRoot ?? stored.sourceRoot ?? "src"),
      registryPath: path.resolve(appRoot, options.registryPath ?? stored.registryPath ?? "testid-registry.json"),
      journeyManifestPath: path.resolve(appRoot, options.journeyManifestPath ?? stored.journeyManifestPath ?? "journeys/manifest.json"),
      ratchetPath: path.resolve(appRoot, options.ratchetPath ?? stored.ratchetPath ?? "testid-ratchet.json"),
    };
  };
  // agent-handles.json's `interactiveComponents` keeps the plugin and the
  // CLI counting with the same predicate; explicit plugin options win.
  let config = options.config ?? DEFAULT_CONFIG;
  async function resolveConfig(root) {
    stored = await readJson(path.join(path.resolve(root, options.appRoot ?? "."), "agent-handles.json"), {});
    if (options.config) { config = options.config; return; }
    config = extendInteractiveComponents(DEFAULT_CONFIG, stored.interactiveComponents);
    if (stored.config) config = { ...config, ...stored.config };
    if (stored.controlJudgments) config = { ...config, controlJudgments: stored.controlJudgments };
    if (stored.identityRenames) config = { ...config, identityRenames: stored.identityRenames };
    if (stored.identityTombstones) config = { ...config, identityTombstones: stored.identityTombstones };
  }

  async function renderCurrentRegistry() {
    await resolveConfig(root);
    return renderRegistry({ ...paths(root), config });
  }

  // Dev: keep the committed registry file current, the way a router plugin
  // keeps its generated route file current. Writes only when the file already
  // exists in the configured schema (an unadopted app gets no file, and an
  // older schema is left for `adopt` to migrate with its archive) and the
  // content changed. Identity history is checked against the registry at git
  // HEAD, the committed record: a half-typed id an editor autosaved never got
  // there, and a committed id removed mid-session still needs a rename or
  // tombstone. Outside git it falls back to the file as this process first
  // read it. A refusal throws and leaves the file alone. The write goes to a
  // temporary file and is renamed over, so a reader never sees half a file.
  let firstRead;
  async function syncRegistryFile() {
    await resolveConfig(root);
    const current = paths(root);
    let onDisk;
    try { onDisk = await fs.readFile(current.registryPath, "utf8"); }
    catch (error) {
      if (error?.code === "ENOENT") return { written: false, reason: "no registry file" };
      throw error;
    }
    const existing = JSON.parse(onDisk);
    if (existing.schema !== config.registrySchema) {
      return {
        written: false,
        skipped: `registry uses ${existing.schema}; run \`agent-handles adopt\` to migrate it to ${config.registrySchema}, the dev server will not`,
      };
    }
    firstRead ??= existing;
    const committed = await committedRegistry(current.registryPath);
    const previousRegistry = committed?.schema === config.registrySchema ? committed : firstRead;
    const rendered = await renderRegistry({ ...current, config, previousRegistry });
    if (rendered === onDisk) return { written: false, reason: "unchanged" };
    const temporary = `${current.registryPath}.${process.pid}.tmp`;
    await fs.writeFile(temporary, rendered);
    await fs.rename(temporary, current.registryPath);
    return { written: true, path: current.registryPath, entries: JSON.parse(rendered).entries?.length ?? 0 };
  }

  // The build gate: regenerate the registry in memory and hold it to the
  // committed ratchet floors. Regression throws (build fails, loudly).
  async function checkRatchet(logger) {
    const registry = JSON.parse(await renderCurrentRegistry());
    const { appRoot, ratchetPath } = paths(root);
    const ratchet = await readJson(ratchetPath, emptyRatchet());
    if (ratchet.schema !== RATCHET_SCHEMA) {
      throw new Error(`${ratchetPath} does not carry schema ${RATCHET_SCHEMA}`);
    }
    const adoptionState = await readJson(path.join(appRoot, ".agent-handles/adoption-state.json"), null);
    const mode = adoptionState?.status === "in_progress" && !adoptionState?.sealedRatchet ? "adoption" : "sealed";
    if ((registry.invalidIdentities?.length ?? 0) > 0) {
      const examples = registry.invalidIdentities
        .slice(0, 5)
        .map(({ reason }) => reason)
        .join("; ");
      const detail = `${registry.invalidIdentities.length} invalid or legacy identity declaration(s) require migration: ${examples}`;
      if (mode === "sealed") throw new Error(detail);
      logger.warn(`[agent-handles] ${detail}`);
    }
    if (mode === "sealed") assertRatchetNotRaised(ratchet, adoptionState?.sealedRatchet);
    const result = evaluateRatchet(registry, ratchet, { mode });
    for (const warning of result.warnings) logger.warn(`[agent-handles] ${warning}`);
    return { registry, result };
  }

  async function createMiddleware() {
    const appRoot = paths(root).appRoot;
    return createDriveMiddleware({
      renderRegistry: renderCurrentRegistry,
      loadMapContext: async () => {
        await resolveConfig(root);
        const stored = await readJson(path.join(appRoot, "agent-handles.json"), {});
        return { manifest: await readJson(paths(root).journeyManifestPath, null),
          unreachable: stored.unreachableSurfaces,
          reviewSurfaces: stored.adoption?.reviewSurfaces ?? [],
          visualReviews: await readVisualReviews(appRoot), appLabel: stored.appLabel || path.basename(appRoot) };
      },
      loadVisualReviews: () => readVisualReviews(appRoot),
      recordVisualReview: (input) => writeVisualReview(appRoot, input),
    });
  }
  return { paths, resolveConfig, renderCurrentRegistry, syncRegistryFile, checkRatchet, createMiddleware, get config() { return config; } };
}
export async function renderClient() {
  return [renderRuntimeObservationPredicate(), renderRuntimeActionabilityPredicate(),
    await fs.readFile(DRIVE_CLIENT_PATH, "utf8")].join("\n\n");
}
