import fs from "node:fs/promises";
import path from "node:path";

export const ADOPTION_ASSESSMENT_SCHEMA = "agent-handles/adoption-assessment/v1";
export const ADOPTION_STATE_SCHEMA = "agent-handles/adoption-state/v1";
export const ADOPTION_RECEIPT_SCHEMA = "agent-handles/adoption-receipt/v1";

const VITE_CONFIG_NAMES = [
  "vite.config.ts", "vite.config.js", "vite.config.mts", "vite.config.mjs",
];
const PLAYWRIGHT_CONFIG_NAMES = [
  "playwright.config.ts", "playwright.config.js", "playwright.config.mts",
  "playwright.config.mjs", "playwright.config.cts", "playwright.config.cjs",
];

async function exists(file) {
  try { await fs.access(file); return true; }
  catch { return false; }
}

function dependencyVersion(packageJson, name) {
  return packageJson.dependencies?.[name] ?? packageJson.devDependencies?.[name];
}

function majorOf(version) {
  const match = String(version ?? "").match(/(\d+)/u);
  return match ? Number(match[1]) : undefined;
}

async function jsonIfPresent(file) {
  try { return JSON.parse(await fs.readFile(file, "utf8")); }
  catch (error) {
    if (error?.code === "ENOENT") return undefined;
    throw error;
  }
}

function normalizedRelative(value) {
  return String(value).replaceAll("\\", "/").replace(/^\.\//u, "").replace(/\/$/u, "");
}

function literalConfigString(source, key) {
  const match = source.match(new RegExp(`(?:^|[,{\\s])${key}\\s*:\\s*["']([^"']+)["']`, "u"));
  return match?.[1];
}

export async function detectPlaywrightProject(root) {
  const configPath = (await Promise.all(PLAYWRIGHT_CONFIG_NAMES.map(async (name) => (
    await exists(path.join(root, name)) ? name : undefined
  )))).find(Boolean);
  const source = configPath ? await fs.readFile(path.join(root, configPath), "utf8") : "";
  const declaredTestDir = literalConfigString(source, "testDir");
  const testDir = declaredTestDir ? normalizedRelative(declaredTestDir) : undefined;
  const projectNames = [...source.matchAll(/\bname\s*:\s*["']([^"']+)["']/gu)]
    .map((match) => match[1]);
  return {
    configured: Boolean(configPath),
    configPath,
    testDir,
    testDirEvidence: declaredTestDir ? "literal-config" : configPath ? "not-statically-declared" : "no-config",
    projectNames: [...new Set(projectNames)],
    suggestedSpecPath: `${testDir || "tests"}/journeys.generated.spec.ts`,
  };
}

export function analyzeIdentityQuality(registry, notes = {}) {
  const declarations = [
    ...(registry.entries ?? []).map((entry) => ({ id: entry.id, file: entry.file, line: entry.line, kind: "literal" })),
    ...(registry.patterns ?? []).map((entry) => ({ id: entry.pattern, file: entry.file, line: entry.line, kind: "pattern" })),
  ];
  const warnings = [];
  const add = (declaration, rule, message) => {
    const stableId = `identity-name:${declaration.id}:${rule}`;
    warnings.push({ stableId, ...declaration, rule, message, acknowledgement: notes[stableId] ?? notes[declaration.id] });
  };
  for (const declaration of declarations) {
    const concrete = declaration.id.endsWith("*") ? declaration.id.slice(0, -1) : declaration.id;
    const segments = concrete.split(".");
    const element = segments[2] ?? "";
    if (concrete.length > 72) add(declaration, "total-length", "Identity exceeds 72 characters; name the control's role instead of copying its label.");
    if (element.split("-").filter(Boolean).length >= 7) add(declaration, "sentence-element", "Element segment reads like copied interface text; replace it with a concise semantic role.");
    if (/-[2-9]\d*$/u.test(element)) add(declaration, "ordinal-suffix", "Numbered sibling suffix is mechanical; prefer a meaningful qualifier or a dynamic pattern.");
  }
  return {
    warnings,
    unresolved: warnings.filter((warning) => !warning.acknowledgement),
    acknowledged: warnings.filter((warning) => warning.acknowledgement),
  };
}

async function sourceInventory(root, configuredSourceRoot) {
  const common = [...new Set([configuredSourceRoot, "src", "app", "web/src"].filter(Boolean))];
  const sourceRoots = [];
  const files = [];
  for (const relative of common) {
    const absolute = path.join(root, relative);
    if (!await exists(absolute)) continue;
    sourceRoots.push(relative);
    const walk = async (directory) => {
      for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
        const target = path.join(directory, entry.name);
        if (entry.isDirectory()) await walk(target);
        else if (entry.isFile() && /\.[jt]sx$/u.test(entry.name) && !/\.test\.[jt]sx$/u.test(entry.name)) files.push(target);
      }
    };
    await walk(absolute);
    if (configuredSourceRoot) break;
  }
  const routes = new Set();
  const routeSourceFiles = new Set();
  const navigationSourceFiles = new Set();
  const identityLiterals = [];
  for (const file of [...new Set(files)]) {
    const text = await fs.readFile(file, "utf8");
    const relative = normalizedRelative(path.relative(root, file));
    if (/<Route\b|createBrowserRouter|createHashRouter|RouterProvider|useRoutes\s*\(/u.test(text)) routeSourceFiles.add(relative);
    if (/\b(?:to|href)\s*=|\bnavigate\s*\(|<Link\b|<NavLink\b/u.test(text)) navigationSourceFiles.add(relative);
    for (const pattern of [
      /<Route\b[^>]*\bpath\s*=\s*["']([^"']+)["']/gu,
      /\bpath\s*:\s*["'](\/[^"']*)["']/gu,
      /\b(?:to|href)\s*=\s*["'](\/[^"']*)["']/gu,
    ]) {
      for (const match of text.matchAll(pattern)) routes.add(match[1]);
    }
    for (const match of text.matchAll(/(?:data-testid|testId|[A-Za-z][\w]*TestId)\s*=\s*["']([^"']+)["']/gu)) {
      identityLiterals.push(match[1]);
    }
  }
  const segmentCounts = (index) => Object.entries(identityLiterals.reduce((counts, id) => {
    const segment = id.split(".")[index];
    if (segment) counts[segment] = (counts[segment] ?? 0) + 1;
    return counts;
  }, {})).sort((left, right) => right[1] - left[1] || left[0].localeCompare(right[0]));
  return {
    sourceRoots,
    sourceFileCount: [...new Set(files)].length,
    routes: [...routes].sort(),
    routeSourceFiles: [...routeSourceFiles].sort(),
    navigationSourceFiles: [...navigationSourceFiles].sort(),
    identityVocabulary: {
      literalIds: identityLiterals.length,
      areas: segmentCounts(0),
      components: segmentCounts(1),
    },
  };
}

export async function detectProject(root, { sourceRoot } = {}) {
  const packagePath = path.join(root, "package.json");
  const packageJson = await fs.readFile(packagePath, "utf8")
    .then((text) => JSON.parse(text))
    .catch((error) => {
      if (error?.code === "ENOENT") return {};
      throw error;
    });
  const viteConfigName = (await Promise.all(VITE_CONFIG_NAMES.map(async (name) => (
    await exists(path.join(root, name)) ? name : undefined
  )))).find(Boolean);
  const viteConfigText = viteConfigName
    ? await fs.readFile(path.join(root, viteConfigName), "utf8")
    : "";
  const viteVersion = dependencyVersion(packageJson, "vite");
  const framework = dependencyVersion(packageJson, "react") ? "react" : "unknown";
  let packageManager = "npm";
  let packageManagerRoot = root;
  for (let current = root; ; current = path.dirname(current)) {
    const currentPackage = await jsonIfPresent(path.join(current, "package.json"));
    const declared = currentPackage?.packageManager?.match(/^(npm|pnpm|yarn)@/u)?.[1];
    if (declared) {
      packageManager = declared;
      packageManagerRoot = current;
      break;
    }
    if (await exists(path.join(current, "pnpm-lock.yaml"))) {
      packageManager = "pnpm";
      packageManagerRoot = current;
      break;
    }
    if (await exists(path.join(current, "yarn.lock"))) {
      packageManager = "yarn";
      packageManagerRoot = current;
      break;
    }
    if (await exists(path.join(current, "package-lock.json"))) {
      packageManager = "npm";
      packageManagerRoot = current;
      break;
    }
    const parent = path.dirname(current);
    if (parent === current || await exists(path.join(current, ".git"))) break;
  }
  let packageManagerCommand = packageManager;
  if (packageManager === "yarn") {
    const releasesDirectory = path.join(packageManagerRoot, ".yarn", "releases");
    const localYarn = (await fs.readdir(releasesDirectory).catch((error) => {
      if (error?.code === "ENOENT") return [];
      throw error;
    })).filter((name) => /^yarn-.*\.cjs$/u.test(name)).sort().at(-1);
    if (localYarn) {
      packageManagerCommand = `node ${normalizedRelative(path.relative(root, path.join(releasesDirectory, localYarn)))}`;
    }
  }
  const outDirExpression = viteConfigText.match(/outDir\s*:\s*([^\n,}]+)/u)?.[1] ?? "";
  const directOutDir = outDirExpression.match(/^\s*["']([^"']+)["']/u)?.[1];
  const conditionalOutDirs = [...outDirExpression.matchAll(/[?:]\s*["']([^"']+)["']/gu)]
    .map((match) => match[1]);
  const outputDirectories = [...new Set([
    ...(directOutDir ? [directOutDir] : conditionalOutDirs),
    "dist",
    "build",
    "out",
  ])];
  const wired = /from\s+["']agent-handles\/vite["']/u.test(viteConfigText)
    && /agentHandles\s*\(/u.test(viteConfigText);
  const [inventory, config, registry, ratchet, adoptionState, playwright] = await Promise.all([
    sourceInventory(root, sourceRoot),
    jsonIfPresent(path.join(root, "agent-handles.json")),
    jsonIfPresent(path.join(root, "testid-registry.json")),
    jsonIfPresent(path.join(root, "testid-ratchet.json")),
    jsonIfPresent(path.join(root, ".agent-handles/adoption-state.json")),
    detectPlaywrightProject(root),
  ]);
  const configuredSpecPath = normalizedRelative(config?.playwrightSpecPath ?? playwright.suggestedSpecPath);
  const packageNames = Object.keys({ ...packageJson.dependencies, ...packageJson.devDependencies }).sort();
  const componentLibraries = packageNames.filter((name) => /base-ui|radix|mui|material-ui|chakra|mantine|headlessui|react-aria|antd|daisyui|class-variance-authority|tailwindcss/iu.test(name));
  const complexWidgets = packageNames.filter((name) => /codemirror|monaco|ag-grid|react-table|xyflow|reactflow|slate|lexical|tiptap|editorjs|chart|dnd/iu.test(name));
  const specInTestDir = !playwright.testDir
    || configuredSpecPath === playwright.testDir
    || configuredSpecPath.startsWith(`${playwright.testDir}/`);
  return {
    packageName: packageJson.name ?? path.basename(root),
    framework,
    vite: {
      configured: Boolean(viteConfigName),
      configPath: viteConfigName,
      version: viteVersion,
      major: majorOf(viteVersion),
      wired,
      supported: [6, 7, 8].includes(majorOf(viteVersion)),
      outputDirectories,
    },
    packageManager,
    packageManagerCommand,
    packageManagerRoot: normalizedRelative(path.relative(root, packageManagerRoot)) || ".",
    playwright: {
      ...playwright,
      configuredSpecPath,
      specInTestDir,
    },
    ...inventory,
    scripts: packageJson.scripts ?? {},
    dependencies: {
      react: dependencyVersion(packageJson, "react"),
      playwright: dependencyVersion(packageJson, "@playwright/test"),
      agentHandles: dependencyVersion(packageJson, "agent-handles"),
    },
    projectLibraries: { componentLibraries, complexWidgets },
    currentAgentHandlesState: {
      configured: Boolean(config),
      registrySchema: registry?.schema,
      ratchetSchema: ratchet?.schema,
      adoptionStatus: adoptionState?.status,
      adoptionPassCount: adoptionState?.passCount ?? 0,
    },
    proposedVitePatch: wired || !viteConfigName ? undefined : {
      file: viteConfigName,
      import: 'import { agentHandles } from "agent-handles/vite";',
      plugin: "agentHandles(),",
      instruction: "Add the import with the other imports, then add agentHandles() to the existing plugins array. Preserve every existing plugin and option.",
    },
  };
}

export function createAssessment({ detected, registry, config }) {
  const candidates = registry.candidates ?? [];
  const wrappers = new Set(candidates
    .filter((candidate) => candidate.evidence?.some((item) => item.startsWith("configured-wrapper:")))
    .map((candidate) => candidate.element));
  const unresolvedCandidates = candidates.filter((candidate) => candidate.disposition === "unresolved");
  const candidateGroups = Object.entries(unresolvedCandidates.reduce((groups, candidate) => {
    const key = candidate.file;
    const group = groups[key] ??= { file: key, total: 0, definite: 0, reviewRequired: 0 };
    group.total += 1;
    if (candidate.classification === "definite") group.definite += 1;
    else group.reviewRequired += 1;
    return groups;
  }, {})).map(([, group]) => group).sort((left, right) => right.total - left.total || left.file.localeCompare(right.file));
  const identityQuality = analyzeIdentityQuality(registry, config.adoption?.identityNameNotes);
  const currentGroup = candidateGroups[0];
  const currentCandidates = currentGroup
    ? unresolvedCandidates.filter((candidate) => candidate.file === currentGroup.file).slice(0, 16)
      .map(({ id, file, line, element, classification, evidence }) => ({ id, file, line, element, classification, evidence }))
    : [];
  return {
    schema: ADOPTION_ASSESSMENT_SCHEMA,
    generatedAt: new Date().toISOString(),
    project: detected,
    sourceRoot: config.sourceRoot ?? "src",
    identityGrammar: registry.grammar,
    identityVocabulary: detected.identityVocabulary ?? { literalIds: 0, areas: [], components: [] },
    routes: detected.routes ?? [],
    sourceRoots: detected.sourceRoots ?? [],
    sourceDigest: registry.sourceDigest,
    controlCandidates: {
      total: registry.coverage?.controlCandidates ?? 0,
      definite: registry.coverage?.definiteCandidates ?? 0,
      reviewRequired: registry.coverage?.reviewRequiredCandidates ?? 0,
      identified: registry.coverage?.identifiedCandidates ?? 0,
      unresolved: registry.coverage?.unresolvedCandidates ?? 0,
    },
    invalidIdentities: (registry.invalidIdentities ?? []).map(({ id, kind, file, line, attribute, reason }) => ({
      id, kind, file, line, attribute, reason,
    })),
    identityHistory: registry.identityHistory ?? { renames: [], tombstones: [] },
    configuredWrappers: [...wrappers].sort(),
    wrapperCandidates: [...new Set(candidates
      .filter((candidate) => /^[A-Z]/u.test(candidate.element) && candidate.classification === "review-required")
      .map((candidate) => candidate.element))].sort(),
    candidateGroups,
    workPacket: {
      reconnaissance: {
        componentLibraries: detected.projectLibraries?.componentLibraries ?? [],
        complexWidgets: detected.projectLibraries?.complexWidgets ?? [],
        routeSourceFiles: detected.routeSourceFiles ?? [],
        navigationSourceFiles: detected.navigationSourceFiles ?? [],
        wrapperCandidates: [...new Set(candidates
          .filter((candidate) => /^[A-Z]/u.test(candidate.element) && candidate.classification === "review-required")
          .map((candidate) => candidate.element))].sort(),
      },
      identity: {
        currentGroup,
        currentCandidates,
        remainingGroups: candidateGroups.length,
      },
      visualReview: {
        required: config.adoption?.visualReviewRequired === true,
        declaredSurfaces: config.adoption?.reviewSurfaces ?? [],
      },
    },
    identityQuality,
    reviewRequired: candidates
      .filter((candidate) => candidate.classification === "review-required" && candidate.disposition === "unresolved")
      .map(({ id, file, line, element, evidence }) => ({ id, file, line, element, evidence })),
    exactCommands: Object.fromEntries(Object.entries({
      scan: "agent-handles scan check",
      ratchet: "agent-handles ratchet check",
      compile: "agent-handles journeys compile",
      verify: "agent-handles adopt verify",
      adopt: "agent-handles adopt",
    }).map(([name, command]) => [
      name,
      (detected.packageManager ?? "npm") === "npm"
        ? `npx ${command}`
        : `${detected.packageManagerCommand ?? detected.packageManager} exec ${command}`,
    ])),
  };
}

export function renderAdoptionPrompt(assessment) {
  const packet = assessment.workPacket ?? {};
  const currentCandidates = packet.identity?.currentCandidates ?? assessment.reviewRequired.slice(0, 16);
  const reviewList = currentCandidates.length > 0
    ? currentCandidates.map((candidate) =>
      `- ${candidate.id} — ${candidate.file}:${candidate.line} <${candidate.element}> (${candidate.evidence.join(", ")})`).join("\n")
    : "- None in the current batch.";
  const patch = assessment.project.proposedVitePatch
    ? [
      `Edit ${assessment.project.proposedVitePatch.file}:`,
      `- ${assessment.project.proposedVitePatch.import}`,
      `- ${assessment.project.proposedVitePatch.plugin}`,
      `- ${assessment.project.proposedVitePatch.instruction}`,
    ].join("\n")
    : assessment.project.vite.wired
      ? "The Vite plugin is already wired. Preserve it."
      : "No supported Vite configuration was detected. Do not guess; leave adoption unsupported and report the evidence.";
  const legacyList = assessment.invalidIdentities.length > 0
    ? assessment.invalidIdentities.slice(0, 16).map((identity) =>
      `- ${identity.file}:${identity.line} ${identity.attribute}=${JSON.stringify(identity.id)} (${identity.kind})`).join("\n")
    : "- None.";
  const groups = assessment.candidateGroups.length > 0
    ? assessment.candidateGroups.slice(0, 12).map((group) => `- ${group.file}: ${group.total} unresolved (${group.definite} definite, ${group.reviewRequired} review-required)`).join("\n")
    : "- None.";
  const quality = assessment.identityQuality.unresolved.length > 0
    ? assessment.identityQuality.unresolved.slice(0, 16).map((warning) => `- ${warning.stableId} — ${warning.file}:${warning.line} ${warning.id}: ${warning.message}`).join("\n")
    : "- None.";
  const playwright = assessment.project.playwright ?? {
    configPath: undefined,
    testDir: undefined,
    configuredSpecPath: "tests/journeys.generated.spec.ts",
    specInTestDir: true,
    projectNames: [],
  };
  return `# Agent Handles adoption prompt — ${assessment.project.packageName}

You are the project-specific editor. Deterministic Agent Handles code owns
detection and verification; you own source inspection, identity naming, and
journey authoring. Never edit generated evidence to manufacture success.

Measured project facts:
- framework: ${assessment.project.framework}
- Vite: ${assessment.project.vite.version ?? "not detected"}
- source root: ${assessment.sourceRoot}
- detected routes: ${assessment.routes.length > 0 ? assessment.routes.join(", ") : "none statically declared"}
- existing identity areas: ${assessment.identityVocabulary.areas.slice(0, 8).map(([name, count]) => `${name} (${count})`).join(", ") || "none"}
- wrapper candidates for review: ${assessment.wrapperCandidates.join(", ") || "none"}
- control candidates: ${assessment.controlCandidates.total} total, ${assessment.controlCandidates.definite} definite, ${assessment.controlCandidates.reviewRequired} review-required, ${assessment.controlCandidates.unresolved} unresolved
- invalid or legacy identities requiring migration: ${assessment.invalidIdentities.length}
- Playwright config: ${playwright.configPath ?? "none"}; detected testDir: ${playwright.testDir ?? "not statically declared"}; generated spec: ${playwright.configuredSpecPath}
- component/composition packages: ${packet.reconnaissance?.componentLibraries?.join(", ") || "none detected"}
- complex widget packages: ${packet.reconnaissance?.complexWidgets?.join(", ") || "none detected"}
- route source files: ${packet.reconnaissance?.routeSourceFiles?.slice(0, 12).join(", ") || "none detected"}

The full measured inventory is in .agent-handles/adoption-assessment.json.
This prompt is the current bounded work packet and is regenerated whenever you
rerun ${assessment.exactCommands.adopt}. Do not paste the whole registry into another
prompt or attempt one application-wide sweep.

## Phase 0 — project reconnaissance

Read .agent-handles/prompts/project-reconnaissance.md. Inspect the
actual router, navigation, component-library wrappers, repeated renderers,
portals, and complex third-party widgets before editing identities. Reconcile
the measured route list against source and a running app. Configure discovered
interactive wrappers and declare meaningful reviewSurfaces in
agent-handles.json under adoption. Do not silently shrink route or state scope.

## Phase 1 — identity

${patch}

Migrate every invalid or legacy identity below. Replace it with a stable
${assessment.identityGrammar} identity, update every source/test/journey
reference, and record the relationship in agent-handles.json under
identityRenames as either "old-id": "area.component.element" or an object
with target and reason. When one reused legacy selector must split into several
unique identities, use an object with targets and a reason. If the addressed surface was deliberately removed,
record identityTombstones with a non-empty reason instead. Never silently
delete or reuse an old identity, and never edit the generated registry to hide
one. Renames and tombstones are verified against the prior registry.

Invalid or legacy identities:
${legacyList}

Inspect every definite and review-required candidate. Give every actual control
a stable identity using ${assessment.identityGrammar}. A shared wrapper must
forward a testId prop, and each call site must provide the distinct identity.
For a review-required site that is not a control or is unreachable in the
declared journey scope, add a structured controlJudgments entry to
agent-handles.json with judgment, evidence, at least two options, and a
proposal. Such a scope reduction remains needs-owner-verdict until the owner
records a choice.

Current identity batch (${packet.identity?.remainingGroups ?? assessment.candidateGroups.length} source group(s) remain):
${reviewList}

Work one source area at a time in this measured order; rerun the scanner after
each group instead of applying one application-wide naming codemod:
${groups}

Before accepting a static identity, inspect whether its component is rendered
inside map/loop code or instantiated more than once. Repeated instances need a
stable resource-qualified dynamic identity. For third-party controls that do
not forward DOM attributes, add an app-owned bridge and verify the rendered
DOM instead of declaring the widget covered from source shape alone.

Identity names describe stable roles, never whole labels or source mechanics.
Keep the full identity at 72 characters or fewer where possible, use a concise
element role, and replace suffixes such as open-2 or toggle-3 with semantic
qualifiers or dynamic patterns. Resolve each deterministic warning below. If a
warning is genuinely intentional, record a reason in agent-handles.json at
adoption.identityNameNotes using the warning's stable ID; the receipt keeps
that narrated exception separate from measured identity evidence.

Identity-name warnings:
${quality}

Run ${assessment.exactCommands.scan} and ${assessment.exactCommands.ratchet}
until every candidate is resolved. Do not remove handlers, roles, routes, or
controls to improve the denominator. Do not weaken the predicate or raise a
ratchet floor.

## Phase 2 — journeys

Start only after phase 1 is clean. Explore the running app and author meaningful
control-path journeys plus any explicitly labeled URL-path journeys. Runtime
observation is path-bound evidence: report “N controls observed during M
journeys, zero unidentified,” never an exhaustive runtime percentage. Compile
the manifest and run the configured journey verification twice.

Use safe local fixtures or host-owned setup for guarded routes. Never use a
production credential. Exercise every declared review surface through a real
user goal or record a structured owner judgment for the wall.

Write the compiled spec to ${playwright.configuredSpecPath}. ${playwright.specInTestDir
    ? "That path is inside the detected Playwright testDir."
    : `It is outside the detected testDir ${playwright.testDir}; update playwrightSpecPath before compiling.`}
${playwright.projectNames.length > 1
    ? `Playwright declares multiple projects (${playwright.projectNames.join(", ")}); choose the app-valid project in adoption.journeyVerifyCommand rather than guessing.`
    : playwright.projectNames.length === 1
      ? `Playwright project detected: ${playwright.projectNames[0]}.`
      : "No statically named Playwright project was detected."}

## Phase 3 — page and state evidence

Read .agent-handles/prompts/visual-review.md. Open the live journey
map, turn on Page and state review, and inspect every declared surface in its
meaningful states. The overlay defaults to issues, keeps identities secondary,
and records measured receipts. Compiled journeys save a durable final-state
screenshot automatically. Clear unidentified, registry-unknown, duplicate,
and review-required controls. A clean state is still path-bound evidence, not
an exhaustive runtime percentage.

Finish with ${assessment.exactCommands.verify}. A narrated claim is never a
measurement; the durable adoption receipt is the handoff.
`;
}

export function ownerVerdicts(registry) {
  return (registry.candidates ?? [])
    .filter((candidate) => candidate.judgment && !candidate.judgment.ownerDecision)
    .map((candidate) => ({
      id: candidate.id,
      judgment: candidate.judgment.judgment ?? `Classify ${candidate.file}:${candidate.line} as ${candidate.judgment.classification}.`,
      evidence: candidate.judgment.evidence,
      options: candidate.judgment.options.length >= 2 ? candidate.judgment.options : [
        { id: "identify", consequence: "Treat it as a control and add a stable identity." },
        { id: candidate.judgment.classification, consequence: `Accept the proposed ${candidate.judgment.classification} scope reduction.` },
      ],
      proposal: candidate.judgment.proposal ?? candidate.judgment.classification,
    }));
}

/**
 * Aggregate path-bound Playwright journey evidence. A successful aggregate
 * requires a fresh receipt for every expected journey, so an old green file
 * cannot make a new run appear observed.
 */
export async function readRuntimeObservations(root, { since = 0, expectedJourneyNames = [] } = {}) {
  const directory = path.join(root, ".agent-handles", "runtime-observations");
  const names = await fs.readdir(directory).catch((error) => {
    if (error?.code === "ENOENT") return [];
    throw error;
  });
  const receipts = [];
  for (const name of names.filter((entry) => entry.endsWith(".json")).sort()) {
    const file = path.join(directory, name);
    const stat = await fs.stat(file);
    const receipt = JSON.parse(await fs.readFile(file, "utf8"));
    if (receipt.schema !== "agent-handles/runtime-journey-observation/v1") continue;
    if (stat.mtimeMs + 1 < since) continue;
    receipts.push({ ...receipt, evidenceFile: path.relative(root, file) });
  }
  const byJourney = new Map(receipts.map((receipt) => [receipt.journeyName, receipt]));
  const missingJourneys = expectedJourneyNames.filter((name) => !byJourney.has(name));
  const observedTestIds = new Set();
  const unidentified = [];
  const unknownTestIds = [];
  const duplicateTestIds = new Set();
  for (const receipt of receipts) {
    for (const testId of receipt.observedTestIds ?? []) observedTestIds.add(testId);
    for (const candidate of receipt.unidentified ?? []) unidentified.push({ journeyName: receipt.journeyName, ...candidate });
    for (const candidate of receipt.unknownTestIds ?? []) unknownTestIds.push({ journeyName: receipt.journeyName, ...candidate });
    for (const testId of receipt.duplicateTestIds ?? []) duplicateTestIds.add(testId);
  }
  return {
    schema: "agent-handles/runtime-observations/v1",
    measuredAt: new Date().toISOString(),
    journeys: byJourney.size,
    journeyNames: [...byJourney.keys()].sort(),
    expectedJourneyNames: [...expectedJourneyNames].sort(),
    missingJourneys,
    interactiveElementsObserved: observedTestIds.size,
    observedTestIds: [...observedTestIds].sort(),
    unidentifiedObserved: unidentified.length,
    unidentified,
    unknownTestIds,
    duplicateTestIds: [...duplicateTestIds].sort(),
    perJourney: [...byJourney.values()].sort((left, right) => left.journeyName.localeCompare(right.journeyName)),
    statement: `${observedTestIds.size} controls observed during ${byJourney.size} journey(s); ${unidentified.length} unidentified and ${unknownTestIds.length} unknown to the registry. Runtime evidence is path-bound; unvisited routes and states are uncovered, not green.`,
  };
}
