import path from 'node:path';
import { evaluateRatchet } from '../ratchet/index.mjs';

const contains = (root, file) => {
  const relative = path.relative(root, file);
  return relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative));
};

// Reconnaissance can discover existing UI outside the bootstrap root. This is
// an admission of new source scope, never a reset of already measured floors.
export function admitAdoptionSourceScope({ appRoot, previousRoots, currentRoots, state, registry, ratchet }) {
  if (!Array.isArray(previousRoots) || !previousRoots.length) return null;
  const before = previousRoots.map((root) => path.resolve(appRoot, root));
  const after = currentRoots.map((root) => path.resolve(appRoot, root));
  if (before.every((root) => after.includes(root)) && after.every((root) => before.includes(root))) return null;
  if (state?.status !== 'in_progress' || state?.sealedRatchet) throw new Error('Source scope admission is only allowed during an unsealed adoption. Preserve the sealed ratchet.');
  if (!before.every((root) => after.some((current) => contains(current, root)))) throw new Error('Source scope admission cannot remove a previously measured source root.');
  const admitted = {};
  for (const entry of registry.unidentifiedInteractive ?? []) {
    const absolute = path.resolve(appRoot, entry.file);
    if (!before.some((root) => contains(root, absolute)) && after.some((root) => contains(root, absolute))
      && !Object.hasOwn(ratchet.floors ?? {}, entry.file)) admitted[entry.file] = (admitted[entry.file] ?? 0) + 1;
  }
  const expanded = { ...ratchet, floors: { ...ratchet.floors, ...admitted } };
  // The unchanged sealed evaluator must still accept all old floors and all
  // previous interaction sites. A renamed/moved file cannot erase its history.
  const result = evaluateRatchet(registry, expanded);
  return { schema: 'agent-handles/source-scope-admission/v1', previousRoots, currentRoots,
    admittedFiles: admitted, sourceDigest: registry.sourceDigest, previousRatchet: ratchet,
    nextRatchet: result.nextRatchet };
}
