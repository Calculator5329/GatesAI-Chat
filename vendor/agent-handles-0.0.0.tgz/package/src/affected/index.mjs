import { createHash } from "node:crypto";
import path from "node:path";

// Frozen identifier carried by emitted and stored maps; kept unchanged after agent-orchestrator retired (2026-09-25).
export const AFFECTED_MAP_SCHEMA = "agent-orchestrator/affected-selection-map/v1";
const TEST_FILE = /\.(?:test|spec)\.(?:[cm]?[jt]sx?)$/u;
const sorted = (values) => [...new Set(values)].sort();

export function repositoryPath(value) {
  if (typeof value !== "string" || !value || value.includes("\\") || value.includes("\0")
    || value.includes("?") || value.includes("#") || path.posix.isAbsolute(value)
    || /^[a-z]:/iu.test(value) || value.split("/").some((part) => part === ".." || part === "." || !part)) {
    throw new Error(`affected map needs a normalized repository-relative path: ${JSON.stringify(value)}`);
  }
  return value;
}

/** Positive dependency evidence only. Absence from this map never proves a test can be skipped. */
export function buildAffectedMap({ modules, registry, manifest, testsByJourney }) {
  if (!Array.isArray(modules) || modules.length === 0) throw new Error("affected map needs a non-empty resolved module graph");
  if (!Array.isArray(manifest?.journeys) || manifest.journeys.length === 0) throw new Error("affected map needs recorded journeys");
  if (!Array.isArray(registry?.entries) || !Array.isArray(registry?.patterns)) throw new Error("affected map needs a source registry");
  const graph = new Map();
  for (const module of modules) {
    const file = repositoryPath(module.file);
    if (!Array.isArray(module.imports)) throw new Error(`affected map module ${file} needs imports`);
    const imports = sorted(module.imports.map(repositoryPath));
    graph.set(file, sorted([...(graph.get(file) ?? []), ...imports]));
  }
  const associations = new Map();
  const journeyEvidence = [];
  const names = new Set();
  for (const journey of manifest.journeys) {
    if (!journey?.name || names.has(journey.name) || !Array.isArray(journey.steps)) throw new Error("affected map needs unique named journeys with steps");
    names.add(journey.name);
    const tests = sorted((testsByJourney?.[journey.name] ?? []).map(repositoryPath));
    if (tests.length === 0 || tests.some((test) => !TEST_FILE.test(test))) throw new Error(`affected map journey ${journey.name} needs real test-file associations`);
    const identities = sorted(journey.steps.map((step) => step.testId).filter(Boolean));
    if (identities.length === 0) throw new Error(`affected map journey ${journey.name} has no identified controls`);
    const roots = new Set();
    for (const identity of identities) {
      const declarations = [
        ...registry.entries.filter((entry) => entry.id === identity),
        ...registry.patterns.filter((entry) => entry.pattern?.endsWith("*") && identity.startsWith(entry.pattern.slice(0, -1))),
      ];
      if (declarations.length === 0) throw new Error(`affected map journey ${journey.name} names unknown identity ${identity}`);
      for (const declaration of declarations) {
        const file = repositoryPath(declaration.file);
        if (!graph.has(file)) throw new Error(`affected map identity ${identity} source ${file} is absent from the resolved graph`);
        roots.add(file);
      }
    }
    const seen = new Set();
    const pending = [...roots];
    while (pending.length > 0) {
      const file = pending.pop();
      if (seen.has(file)) continue;
      if (!graph.has(file)) throw new Error(`affected map graph lacks imported module ${file}`);
      seen.add(file);
      if (!TEST_FILE.test(file)) associations.set(file, sorted([...(associations.get(file) ?? []), ...tests]));
      pending.push(...graph.get(file));
    }
    journeyEvidence.push({ name: journey.name, tests, identities, sourceRoots: sorted(roots), dependencySources: sorted(seen) });
  }
  const mappings = [...associations].sort(([a], [b]) => a.localeCompare(b)).map(([source, tests]) => ({ sources: [source], tests }));
  const map = { schema: AFFECTED_MAP_SCHEMA, mappings };
  const graphEvidence = [...graph].sort(([a], [b]) => a.localeCompare(b)).map(([file, imports]) => ({ file, imports }));
  const evidence = {
    schema: "agent-handles/affected-map-evidence/v1",
    scope: "recorded-journey-dependency-closure",
    complete: false,
    statement: "Positive associations for recorded journeys only; absent modules and unvisited or server-side behavior remain uncovered. AO retains test-selection authority.",
    graphDigest: `sha256:${createHash("sha256").update(JSON.stringify(graphEvidence)).digest("hex")}`,
    mapDigest: `sha256:${createHash("sha256").update(JSON.stringify(map)).digest("hex")}`,
    registrySourceDigest: registry.sourceDigest ?? null,
    graph: graphEvidence,
    journeys: journeyEvidence.sort((a, b) => a.name.localeCompare(b.name)),
    unassociatedModules: sorted([...graph.keys()].filter((file) => !associations.has(file))),
  };
  return { map, evidence };
}
