import fs from "node:fs/promises";
import { createHash } from "node:crypto";
import path from "node:path";
import { buildAffectedMap, repositoryPath } from "./index.mjs";

/** Convert a completed Vite build graph to framework-neutral, positive test associations. */
export async function affectedBuildArtifacts({ context, appRoot, config, registry, manifest, defaultTestFile }) {
  const repositoryRoot = path.resolve(appRoot, config.repositoryRoot ?? ".");
  const relative = (absolute) => {
    const file = path.relative(repositoryRoot, absolute).split(path.sep).join("/");
    return repositoryPath(file);
  };
  const inRepository = (id) => {
    if (typeof id !== "string" || id.includes("\0") || !path.isAbsolute(id)) return null;
    const absolute = id.split("?")[0].split("#")[0];
    const file = path.relative(repositoryRoot, absolute).split(path.sep).join("/");
    if (!file || file.startsWith("../") || file === ".." || file.split("/").includes("node_modules")) return null;
    return repositoryPath(file);
  };
  if (typeof context.getModuleIds !== "function" || typeof context.getModuleInfo !== "function") throw new Error("affected map requires a completed build module graph");
  const ids = [...context.getModuleIds()];
  const ignored = new Set();
  const modules = [];
  for (const id of ids) {
    const file = inRepository(id);
    if (!file) { ignored.add(id); continue; }
    const info = context.getModuleInfo(id);
    if (!info) throw new Error(`affected map could not inspect module ${file}`);
    const imports = [...(info.importedIds ?? []), ...(info.dynamicallyImportedIds ?? [])].flatMap((dependency) => {
      const imported = inRepository(dependency);
      if (!imported) { ignored.add(dependency); return []; }
      return [imported];
    });
    modules.push({ file, imports });
  }
  const convertDeclarations = (entries) => entries.map((entry) => ({ ...entry, file: relative(path.resolve(appRoot, entry.file)) }));
  const testsByJourney = {};
  const testDigests = new Map();
  for (const journey of manifest?.journeys ?? []) {
    const configured = config.testsByJourney?.[journey.name] ?? [defaultTestFile];
    if (!Array.isArray(configured)) throw new Error(`affected map journey ${journey.name} test association must be an array`);
    testsByJourney[journey.name] = [];
    for (const test of configured) {
      repositoryPath(test);
      const absolute = path.resolve(appRoot, test);
      const real = await fs.realpath(absolute);
      const file = relative(real);
      if (!(await fs.stat(real)).isFile()) throw new Error(`affected map test target is not a file: ${file}`);
      testsByJourney[journey.name].push(file);
      testDigests.set(file, createHash("sha256").update(await fs.readFile(real)).digest("hex"));
    }
  }
  const result = buildAffectedMap({
    modules,
    registry: { ...registry, entries: convertDeclarations(registry.entries), patterns: convertDeclarations(registry.patterns) },
    manifest,
    testsByJourney,
  });
  const sourceDigests = [];
  for (const file of [...new Set(modules.map((module) => module.file))].sort()) {
    const real = await fs.realpath(path.join(repositoryRoot, file));
    relative(real);
    sourceDigests.push({ file, sha256: createHash("sha256").update(await fs.readFile(real)).digest("hex") });
  }
  result.evidence.sourceDigests = sourceDigests;
  result.evidence.testDigests = [...testDigests].sort(([a], [b]) => a.localeCompare(b)).map(([file, sha256]) => ({ file, sha256 }));
  result.evidence.manifestDigest = `sha256:${createHash("sha256").update(JSON.stringify(manifest)).digest("hex")}`;
  result.evidence.ignoredModuleCount = ignored.size;
  result.evidence.ignoredModulePolicy = "Virtual, external, and dependency-package modules are outside the emitted source scope; their changes are not proven safe by this map.";
  const fileName = repositoryPath(config.fileName ?? "affected-map.json");
  const evidenceName = fileName.replace(/\.json$/u, "") + ".evidence.json";
  if (fileName === "testid-registry.json" || evidenceName === "testid-registry.json") throw new Error("affected map cannot overwrite the registry artifact");
  return [
    { type: "asset", fileName, source: JSON.stringify(result.map, null, 2) + "\n" },
    { type: "asset", fileName: evidenceName, source: JSON.stringify(result.evidence, null, 2) + "\n" },
  ];
}
