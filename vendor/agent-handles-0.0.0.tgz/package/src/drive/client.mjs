// The page executor, served as a dev-only virtual module by the Vite plugin.
// It long-polls the drive middleware for commands, executes them against the
// live DOM by data-testid, and posts results back. This file must NEVER be
// reachable from a production build; the plugin injects it only under
// `serve`, and the L4 acceptance test asserts the built bundle carries none
// of it.

const PREFIX = "/__agent-handles";

// Every page load is its own executor. The id lets the server route a
// journey's commands to one page even when several tabs have the app open
// (two tabs both polling used to split one journey across two DOMs).
const EXECUTOR_ID = `x-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;

function byTestId(testId) {
  return document.querySelector(`[data-testid="${CSS.escape(testId)}"]`);
}

function isVisible(element) {
  if (!element) return false;
  const rect = element.getBoundingClientRect();
  const style = getComputedStyle(element);
  return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
}

function describe(element) {
  if (!element) return "not found";
  return `<${element.tagName.toLowerCase()}> text=${JSON.stringify((element.textContent ?? "").trim().slice(0, 80))}`;
}

async function waitFor(predicate, timeoutMs) {
  const deadline = Date.now() + (timeoutMs ?? 5000);
  for (;;) {
    const verdict = predicate();
    if (verdict.done) return verdict;
    if (Date.now() > deadline) return { ...verdict, timedOut: true };
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
}

function fire(element, Ctor, type, init = {}) {
  element.dispatchEvent(new Ctor(type, { bubbles: true, cancelable: true, composed: true, ...init }));
}

// Synthetic events carry isTrusted: false; frameworks (React included) handle
// them fine, but browser-native behaviors (real focus rings, OS context
// menus) do not fire. The compiled Playwright specs use trusted CDP input,
// so a journey recorded here replays with the real thing.
function hoverElement(element) {
  const init = { pointerId: 1, pointerType: "mouse", isPrimary: true };
  fire(element, PointerEvent, "pointerover", init);
  fire(element, PointerEvent, "pointerenter", { ...init, bubbles: false });
  fire(element, MouseEvent, "mouseover");
  fire(element, MouseEvent, "mouseenter", { bubbles: false });
  fire(element, PointerEvent, "pointermove", init);
  fire(element, MouseEvent, "mousemove");
}

// A bare element.click() never reaches components that listen on pointer
// events (Radix triggers/items open on pointerdown and select on pointerup),
// so click is the full primary-button sequence. The press and the release
// are split across two tasks, the way a real mouse always is: Radix Select
// opens on the trigger's pointerdown and, once its content commits, arms a
// one-shot document pointerup guard meant for that same press. Fired in one
// task, the release lands before the guard exists, the guard then eats the
// *next* pointerup (the option the agent clicks), and nothing is selected.
// Found 2026-09-03 on Fathom's rebalance dropdown: unpaced or paced, the
// synthetic open + synthetic select never changed the trigger.
function nextTask() {
  return new Promise((resolve) => setTimeout(resolve, 0));
}

async function clickElement(element) {
  const pointer = { pointerId: 1, pointerType: "mouse", isPrimary: true, button: 0 };
  fire(element, PointerEvent, "pointerdown", { ...pointer, buttons: 1 });
  fire(element, MouseEvent, "mousedown", { button: 0, buttons: 1, detail: 1 });
  element.focus?.();
  await nextTask();
  fire(element, PointerEvent, "pointerup", pointer);
  fire(element, MouseEvent, "mouseup", { button: 0, detail: 1 });
  element.click();
}

function rightClickElement(element) {
  const pointer = { pointerId: 1, pointerType: "mouse", isPrimary: true, button: 2, buttons: 2 };
  fire(element, PointerEvent, "pointerdown", pointer);
  fire(element, MouseEvent, "mousedown", { button: 2, buttons: 2 });
  fire(element, PointerEvent, "pointerup", { ...pointer, buttons: 0 });
  fire(element, MouseEvent, "mouseup", { button: 2 });
  fire(element, MouseEvent, "contextmenu", { button: 2 });
}

function setNativeValue(element, next) {
  const proto = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype
    : element instanceof HTMLSelectElement ? HTMLSelectElement.prototype
    : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
  if (setter) setter.call(element, next);
  else element.value = next;
}

function pressKey(element, key, modifiers = {}) {
  element.focus?.();
  fire(element, KeyboardEvent, "keydown", { key, ...modifiers });
  fire(element, KeyboardEvent, "keyup", { key, ...modifiers });
}

// Letter by letter, the way a user reaches an autocomplete: each character
// gets its own keydown / value-append / input / keyup, so per-keystroke
// handlers (highlighting, suggestion queries) run once per character.
async function typeInto(element, text, perCharMs = 0) {
  element.focus?.();
  for (const ch of text) {
    fire(element, KeyboardEvent, "keydown", { key: ch });
    fire(element, KeyboardEvent, "keypress", { key: ch });
    setNativeValue(element, (element.value ?? "") + ch);
    fire(element, InputEvent, "input", { data: ch, inputType: "insertText" });
    fire(element, KeyboardEvent, "keyup", { key: ch });
    if (perCharMs > 0) await new Promise((resolve) => setTimeout(resolve, perCharMs));
  }
}

// The visible cursor: a small emerald glow that glides to whatever element
// the drive session touches next, so a human can watch an agent (or a
// journey replay) work the app. Pure rendering of drive activity; it changes
// nothing about execution, and like the rest of this file it exists only in
// dev serve. paceMs on the command sets the glide time (0 = instant flash,
// the default for agent sessions, so agents lose nothing).
const cursor = (() => {
  const IDLE_FADE_MS = 4000;
  let dot = null;
  let idleTimer = null;

  function ensure() {
    if (dot?.isConnected) return dot;
    dot = document.createElement("div");
    dot.id = "__agent-handles-cursor";
    dot.style.cssText = [
      "position:fixed", "left:0", "top:0", "width:14px", "height:14px",
      "border-radius:50%", "pointer-events:none", "z-index:2147483647",
      "background:#34d399", "opacity:0",
      "box-shadow:0 0 6px 2px rgba(52,211,153,0.9), 0 0 22px 8px rgba(52,211,153,0.35)",
      "transform:translate(-20px,-20px)",
      "transition:opacity 200ms ease",
    ].join(";");
    document.body.appendChild(dot);
    return dot;
  }

  function wake() {
    ensure().style.opacity = "1";
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => { if (dot) dot.style.opacity = "0"; }, IDLE_FADE_MS);
  }

  function centerOf(element) {
    const rect = element.getBoundingClientRect();
    return { x: rect.left + rect.width / 2 - 7, y: rect.top + rect.height / 2 - 7 };
  }

  async function glideTo(element, paceMs = 0) {
    if (!element) return;
    const point = centerOf(element);
    const node = ensure();
    wake();
    node.style.transition = `opacity 200ms ease, transform ${Math.max(paceMs, 0)}ms cubic-bezier(0.3, 0.8, 0.3, 1)`;
    node.style.transform = `translate(${point.x}px, ${point.y}px)`;
    if (paceMs > 0) await new Promise((resolve) => setTimeout(resolve, paceMs));
  }

  function ripple(element, color = "rgba(52,211,153,0.7)") {
    if (!element) return;
    const point = centerOf(element);
    const ring = document.createElement("div");
    ring.style.cssText = [
      "position:fixed", `left:${point.x - 4}px`, `top:${point.y - 4}px`,
      "width:22px", "height:22px", "border-radius:50%", "pointer-events:none",
      "z-index:2147483646", `border:2px solid ${color}`,
    ].join(";");
    document.body.appendChild(ring);
    ring.animate(
      [{ transform: "scale(0.4)", opacity: 1 }, { transform: "scale(2.2)", opacity: 0 }],
      { duration: 450, easing: "ease-out" },
    ).finished.then(() => ring.remove()).catch(() => ring.remove());
  }

  // Expects highlight their target instead of moving the cursor: asking is
  // not touching. Emerald outline on pass, red on fail.
  function outline(element, ok) {
    if (!element) return;
    const rect = element.getBoundingClientRect();
    const box = document.createElement("div");
    box.style.cssText = [
      "position:fixed", `left:${rect.left - 3}px`, `top:${rect.top - 3}px`,
      `width:${rect.width + 6}px`, `height:${rect.height + 6}px`,
      "pointer-events:none", "z-index:2147483646", "border-radius:4px",
      `border:1px solid ${ok ? "rgba(52,211,153,0.9)" : "rgba(248,113,113,0.9)"}`,
      `box-shadow:0 0 10px 2px ${ok ? "rgba(52,211,153,0.4)" : "rgba(248,113,113,0.4)"}`,
    ].join(";");
    document.body.appendChild(box);
    box.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 900, easing: "ease-in" })
      .finished.then(() => box.remove()).catch(() => box.remove());
    wake();
  }

  return { glideTo, ripple, outline };
})();

// Receipts echo resulting state, because the agent has no eyes: after a
// type, the box's ACTUAL value is the truth (typing appends like real
// keystrokes, so typing "TXRH" into a box already holding "TXRH" leaves
// "TXRH TXRH"), and a validation error the app just raised is invisible
// without surfacing live regions.
function visibleAlerts() {
  return [...document.querySelectorAll('[role="alert"], [aria-live="assertive"]')]
    .filter(isVisible)
    .map((node) => (node.textContent ?? "").trim())
    .filter(Boolean)
    .slice(0, 3);
}

function stateEcho(element) {
  const state = { url: window.location.pathname + window.location.search };
  // Only true form fields: buttons technically carry .value too, and echoing
  // their empty string is noise.
  if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement || element instanceof HTMLSelectElement) {
    state.value = element.value.slice(0, 200);
  }
  const alerts = visibleAlerts();
  if (alerts.length) state.alerts = alerts;
  return state;
}

function visibleInteractiveElements() {
  return [...document.querySelectorAll(RUNTIME_INTERACTIVE_SELECTOR)]
    .filter(isRuntimeObservationCandidate);
}

function captureObservation(includeUnidentified = false) {
  const elements = [...document.querySelectorAll("[data-testid]")]
    .filter((element) => !element.closest("[data-agent-handles-overlay]"))
    .filter(isVisible)
    .slice(0, 150)
    .map((element) => {
      const entry = { testId: element.getAttribute("data-testid"), tag: element.tagName.toLowerCase() };
      if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement || element instanceof HTMLSelectElement) {
        entry.value = element.value.slice(0, 80);
      } else {
        const text = (element.textContent ?? "").trim();
        if (text) entry.text = text.slice(0, 80);
      }
      if (element.disabled) entry.disabled = true;
      const checked = element.checked ?? (element.getAttribute("aria-checked") === "true" ? true : undefined);
      if (checked !== undefined) entry.checked = checked;
      return entry;
    });
  const interactiveCandidates = includeUnidentified
    ? visibleInteractiveElements().slice(0, 250).map((element) => ({
      testId: element.getAttribute("data-testid"),
      tag: element.tagName.toLowerCase(),
      role: element.getAttribute("role") || undefined,
      text: (element.textContent ?? "").trim().replace(/\s+/g, " ").slice(0, 80) || undefined,
    }))
    : undefined;
  const duplicateTestIds = interactiveCandidates
    ? [...new Set(interactiveCandidates
      .map((entry) => entry.testId)
      .filter((testId, index, all) => testId && all.indexOf(testId) !== index))]
    : undefined;
  return {
    url: window.location.pathname + window.location.search,
    title: document.title,
    alerts: visibleAlerts(),
    elements,
    ...(interactiveCandidates && {
      interactiveCandidates,
      unidentifiedInteractive: interactiveCandidates.filter((entry) => !entry.testId),
      duplicateTestIds,
    }),
  };
}

function liveRegistryMatch(testId, registry) {
  const literal = (registry.entries ?? []).find((entry) => entry.id === testId);
  if (literal) return { kind: "literal", declaration: literal, name: literal.id };
  const pattern = (registry.patterns ?? []).find((entry) => entry.pattern.endsWith("*") && testId.startsWith(entry.pattern.slice(0, -1)));
  return pattern ? { kind: "pattern", declaration: pattern, name: pattern.pattern } : undefined;
}

function isDefiniteControl(element) {
  const tag = element.tagName.toLowerCase();
  return ["button", "input", "select", "textarea", "summary"].includes(tag)
    || (tag === "a" && element.hasAttribute("href"))
    || (element.hasAttribute("contenteditable") && element.getAttribute("contenteditable") !== "false");
}

// Dev-only visual review. It projects the registry over the current DOM;
// nothing it renders enters observations, registry counts, or app state.
const coverageOverlay = (() => {
  let host;
  let shadow;
  let registry;
  let reviewContext = { records: [], surfaces: [] };
  let enabled = false;
  let scheduled = false;
  let observer;
  let view = "issues";
  let selectedIndex = -1;
  let stateLabel = "";
  let saveMessage = "";
  let lastRoute = "";
  let selectedSurfaceId = "";

  const colors = {
    identified: "#34d399",
    "review-required": "#fbbf24",
    unidentified: "#fb923c",
    unknown: "#f87171",
    duplicate: "#ef4444",
  };

  function ensure() {
    if (host?.isConnected) return;
    host = document.createElement("div");
    host.setAttribute("data-agent-handles-overlay", "true");
    host.style.cssText = "position:fixed;inset:0;z-index:2147483640;pointer-events:none;font-family:system-ui,sans-serif";
    shadow = host.attachShadow({ mode: "open" });
    document.body.appendChild(host);
  }

  function snapshot() {
    const controls = visibleInteractiveElements().slice(0, 400);
    const counts = new Map();
    for (const element of controls) {
      const testId = element.getAttribute("data-testid");
      if (testId) counts.set(testId, (counts.get(testId) ?? 0) + 1);
    }
    return controls.map((element, index) => {
      const testId = element.getAttribute("data-testid");
      const match = testId ? liveRegistryMatch(testId, registry) : undefined;
      const status = testId && (counts.get(testId) ?? 0) > 1
        ? "duplicate"
        : testId && !match
          ? "unknown"
          : testId
            ? "identified"
            : isDefiniteControl(element)
              ? "unidentified"
              : "review-required";
      const journeyNames = (reviewContext.records ?? [])
        .filter((record) => testId && record.observedTestIds?.includes(testId) && record.journeyName)
        .map((record) => record.journeyName);
      return { index, element, testId, match, status, count: testId ? counts.get(testId) : undefined, journeyNames };
    });
  }

  function itemTitle(item) {
    const text = (item.element.textContent ?? "").trim().replace(/\s+/g, " ").slice(0, 52);
    if (text) return text;
    const role = item.element.getAttribute("aria-label") || item.element.getAttribute("role");
    return role ? `${role} control` : `${item.element.tagName.toLowerCase()} control`;
  }

  function identityNameWarnings(testId) {
    if (!testId) return [];
    const warnings = [];
    const element = testId.split(".")[2] ?? "";
    if (testId.length > 72) warnings.push("Identity exceeds 72 characters.");
    if (element.split("-").filter(Boolean).length >= 7) warnings.push("Element name reads like copied interface text.");
    if (/-[2-9]\d*$/u.test(element)) warnings.push("Numbered suffix looks mechanical.");
    return warnings;
  }

  function details(item) {
    const text = (item.element.textContent ?? "").trim().replace(/\s+/g, " ").slice(0, 120);
    const declaration = item.match?.declaration;
    return [
      `<h3>${escapeHtml(itemTitle(item))}</h3>`,
      `<strong>${item.testId ? escapeHtml(item.testId) : "No identity"}</strong>`,
      `<span>${escapeHtml(item.status.replace("-", " "))} · &lt;${item.element.tagName.toLowerCase()}&gt;</span>`,
      text ? `<span>Visible text: ${escapeHtml(text)}</span>` : "",
      declaration ? `<span>Source: ${escapeHtml(declaration.file ?? "unknown")}:${declaration.line ?? "?"}</span>` : "",
      item.match?.kind === "pattern" ? `<span>Pattern: ${escapeHtml(item.match.name)}</span>` : "",
      item.count > 1 ? `<span>${item.count} visible instances share this identity.</span>` : "",
      item.journeyNames.length > 0 ? `<span>Seen in: ${escapeHtml(item.journeyNames.join(", "))}</span>` : `<span>No recorded journey has observed this identity yet.</span>`,
      ...identityNameWarnings(item.testId).map((warning) => `<span>Name check: ${escapeHtml(warning)}</span>`),
      !item.testId ? `<span>Live DOM evidence has no source address. Run adopt/scan to resolve the source candidate.</span>` : "",
      item.status === "unknown" ? `<span>This value is absent from the committed registry.</span>` : "",
    ].filter(Boolean).join("");
  }

  function escapeHtml(value) {
    return String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
  }

  function render() {
    scheduled = false;
    if (!enabled) return;
    // A few dev shells replace <body> wholesale during hot reload. Reattach
    // the projection instead of silently losing visual review mid-state.
    ensure();
    const items = snapshot();
    const counts = items.reduce((totals, item) => {
      totals[item.status] = (totals[item.status] ?? 0) + 1;
      return totals;
    }, {});
    const issues = items.filter((item) => item.status !== "identified");
    const listed = view === "issues"
      ? issues
      : view === "journeys"
        ? items.filter((item) => item.journeyNames.length === 0)
        : view === "names"
          ? items.filter((item) => identityNameWarnings(item.testId).length > 0)
          : items;
    const listRows = [...listed.reduce((groups, item) => {
      const family = item.match?.kind === "pattern" ? item.match.name : item.testId;
      const key = `${item.status}:${family ?? `missing-${item.index}`}`;
      const row = groups.get(key) ?? { item, count: 0 };
      row.count += 1;
      groups.set(key, row);
      return groups;
    }, new Map()).values()];
    const selected = items[selectedIndex];
    const route = location.pathname + location.search;
    const routeSurfaces = (reviewContext.surfaces ?? []).filter((surface) => surface.route === route || surface.route === location.pathname);
    if (route !== lastRoute) {
      lastRoute = route;
      selectedSurfaceId = routeSurfaces[0]?.id ?? "";
      stateLabel = routeSurfaces[0]?.label ?? document.title ?? route;
      selectedIndex = -1;
      saveMessage = "";
    }
    const activeSurface = routeSurfaces.find((surface) => surface.id === selectedSurfaceId) ?? routeSurfaces[0];
    if (!stateLabel) stateLabel = activeSurface?.label ?? document.title ?? route;
    const reviewedSurfaceIds = new Set((reviewContext.records ?? []).map((record) => record.surfaceId ?? record.id));
    const reviewedRoutes = new Set((reviewContext.records ?? []).map((record) => record.route));
    const surfaceTotal = reviewContext.surfaces?.length ?? 0;
    const surfaceReviewed = surfaceTotal > 0
      ? reviewContext.surfaces.filter((surface) => reviewedSurfaceIds.has(surface.id)).length
      : reviewedRoutes.size;
    shadow.innerHTML = `<style>
      *{box-sizing:border-box} button,input{font:inherit}.box{position:fixed;border:1px solid;pointer-events:none;border-radius:6px;box-shadow:0 0 0 1px rgba(0,0,0,.3)}
      .box.identified{opacity:.24}.box.selected{opacity:1;border-width:2px;box-shadow:0 0 0 2px rgba(0,0,0,.45)}
      .dot{position:fixed;width:6px;height:6px;border-radius:50%;background:#5d8f74;box-shadow:0 0 0 2px rgba(8,13,10,.75);pointer-events:none}
      .badge{position:absolute;left:-2px;top:-25px;max-width:240px;padding:3px 7px;border:1px solid;border-radius:5px;background:#09100c;color:#eef7f1;font:11px/16px ui-monospace,monospace;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .rail{position:fixed;right:12px;top:12px;bottom:12px;width:min(370px,calc(100vw - 24px));display:flex;flex-direction:column;border:1px solid #26372d;border-radius:12px;background:rgba(8,13,10,.97);color:#edf6ef;box-shadow:0 18px 55px rgba(0,0,0,.5);pointer-events:auto;overflow:hidden}
      .rail header{padding:13px 14px 11px;border-bottom:1px solid #213028}.rail h2{font-size:15px;margin:0}.rail p{font-size:12px;color:#9fb0a4;margin:4px 0 0}.close{float:right;background:none;border:0;color:#829488;cursor:pointer;font-size:18px;padding:0 2px}
      .stats{display:flex;gap:12px;margin-top:10px;font:12px ui-monospace,monospace}.stats b{color:#75ad8b}.stats .bad{color:#f49b82}
      .tabs{display:grid;grid-template-columns:repeat(4,1fr);gap:3px;padding:8px;border-bottom:1px solid #213028}.tabs button{border:0;border-radius:6px;background:transparent;color:#8fa095;padding:6px 3px;font-size:11px;cursor:pointer}.tabs button.active{background:#17251d;color:#dff0e4}
      .list{padding:6px 8px;overflow:auto;min-height:90px;scrollbar-width:none}.list::-webkit-scrollbar{display:none}.item{width:100%;display:grid;grid-template-columns:9px 1fr auto;gap:8px;text-align:left;border:0;border-radius:7px;background:transparent;color:#dce9df;padding:7px 8px;cursor:pointer}.item:hover,.item.active{background:#142019}.swatch{width:7px;height:7px;border-radius:50%;margin-top:5px}.item span{min-width:0}.item b{display:block;font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.item small{display:block;color:#829488;font:10.5px ui-monospace,monospace;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.item em{font-style:normal;color:#829488;font-size:11px}.empty{padding:18px 8px;text-align:center;color:#789083;font-size:12px}
      .details{border-top:1px solid #213028;padding:11px 14px;max-height:180px;overflow:auto;scrollbar-width:none}.details:empty{display:none}.details h3{font-size:13px;margin:0 0 4px}.details strong,.details span{display:block}.details strong{font:11px ui-monospace,monospace;color:#75ad8b;overflow-wrap:anywhere}.details span{font-size:11.5px;color:#9fb0a4;margin-top:4px}
      .record{margin-top:auto;border-top:1px solid #213028;padding:11px 14px}.record label{display:block;color:#9fb0a4;font-size:11px;margin-bottom:5px}.record .row{display:flex;gap:6px}.record input,.record select{min-width:0;flex:1;border:1px solid #2b3d32;border-radius:6px;background:#0d1611;color:#e8f2eb;padding:7px 8px;font-size:12px}.record select{width:100%;margin-bottom:7px}.record button{border:1px solid #416b52;border-radius:6px;background:#173021;color:#bfe4ca;padding:7px 10px;font-size:12px;cursor:pointer}.record button:disabled{opacity:.5;cursor:default}.save-status{min-height:16px;color:#8fa095;font-size:11px;margin-top:5px}.foot{color:#708076;font-size:10.5px;line-height:1.35;margin-top:5px}
    </style>
    ${items.map((item) => {
      const rect = item.element.getBoundingClientRect();
      const color = colors[item.status];
      if (view === "issues" && item.status === "identified") {
        return `<span class="dot" style="left:${rect.left - 2}px;top:${rect.top - 2}px"></span>`;
      }
      if (view === "journeys" && item.journeyNames.length > 0) return "";
      const selectedClass = selectedIndex === item.index ? " selected" : "";
      const label = selectedClass ? `<span class="badge" style="border-color:${color}">${escapeHtml(itemTitle(item))}</span>` : "";
      return `<div class="box ${item.status}${selectedClass}" style="left:${rect.left - 2}px;top:${rect.top - 2}px;width:${rect.width + 4}px;height:${rect.height + 4}px;border-color:${color}">${label}</div>`;
    }).join("")}
    <aside class="rail">
      <header><button class="close" title="Hide visual review">×</button><h2>Page and state review</h2>
        <p>${escapeHtml(route)} · ${items.length} visible controls in this state</p>
        <div class="stats"><span><b>${counts.identified ?? 0}</b> identified</span><span class="${issues.length ? "bad" : ""}"><b>${issues.length}</b> issues</span><span><b>${surfaceReviewed}</b>/${surfaceTotal || "?"} states reviewed</span></div>
      </header>
      <nav class="tabs">
        ${[["issues", "Issues"], ["all", "All"], ["names", "Names"], ["journeys", "Not in journeys"]].map(([key, label]) => `<button data-view="${key}" class="${view === key ? "active" : ""}">${label}</button>`).join("")}
      </nav>
      <div class="list">
        ${listRows.length === 0 ? `<div class="empty">${view === "issues" ? "No visible identity issues in this state." : view === "names" ? "No visible mechanical identity names." : "Nothing matches this view."}</div>` : listRows.slice(0, 160).map(({ item, count }) => `<button class="item ${selectedIndex === item.index ? "active" : ""}" data-index="${item.index}">
          <i class="swatch" style="background:${colors[item.status]}"></i><span><b>${escapeHtml(item.match?.kind === "pattern" && count > 1 ? `${count} related ${item.element.tagName.toLowerCase()} controls` : itemTitle(item))}</b><small>${escapeHtml(item.match?.kind === "pattern" ? item.match.name : item.testId ?? "No identity")}</small></span><em>${count > 1 ? `${count} × ` : ""}${escapeHtml(item.status.replace("-", " "))}</em>
        </button>`).join("")}
      </div>
      <div class="details">${selected ? details(selected) : ""}</div>
      <div class="record">${routeSurfaces.length > 0 ? `<label>Declared state</label><select>${routeSurfaces.map((surface) => `<option value="${escapeHtml(surface.id)}" ${surface.id === activeSurface?.id ? "selected" : ""}>${escapeHtml(surface.label)}</option>`).join("")}</select>` : ""}<label>Evidence label for this exact state</label><div class="row"><input maxlength="120" value="${escapeHtml(stateLabel)}"><button class="save">Save evidence</button></div><div class="save-status">${escapeHtml(saveMessage)}</div><div class="foot">This records only the page and state you can see. Compiled journeys save durable final-state screenshots.</div></div>
    </aside>`;
    shadow.querySelector(".close").addEventListener("click", hide);
    for (const tab of shadow.querySelectorAll("[data-view]")) tab.addEventListener("click", () => { view = tab.dataset.view; selectedIndex = -1; render(); });
    for (const row of shadow.querySelectorAll(".item")) row.addEventListener("click", () => {
      selectedIndex = Number(row.dataset.index);
      items[selectedIndex]?.element.scrollIntoView?.({ block: "center", behavior: "smooth" });
      render();
    });
    const input = shadow.querySelector(".record input");
    input.addEventListener("input", () => { stateLabel = input.value; });
    const surfaceSelect = shadow.querySelector(".record select");
    surfaceSelect?.addEventListener("change", () => {
      selectedSurfaceId = surfaceSelect.value;
      stateLabel = routeSurfaces.find((surface) => surface.id === selectedSurfaceId)?.label ?? stateLabel;
      saveMessage = "";
      render();
    });
    shadow.querySelector(".save").addEventListener("click", async () => {
      const button = shadow.querySelector(".save");
      const status = shadow.querySelector(".save-status");
      button.disabled = true;
      status.textContent = "Saving measured page/state evidence...";
      try {
        const response = await fetch(`${PREFIX}/visual-reviews`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            surfaceId: activeSurface?.id,
            route,
            label: stateLabel,
            title: document.title,
            visibleControls: items.length,
            identifiedControls: counts.identified ?? 0,
            issues: {
              unidentified: counts.unidentified ?? 0,
              unknown: counts.unknown ?? 0,
              duplicate: counts.duplicate ?? 0,
              reviewRequired: counts["review-required"] ?? 0,
            },
            observedTestIds: items.map((item) => item.testId).filter(Boolean),
          }),
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error ?? `save failed (${response.status})`);
        reviewContext = await fetch(`${PREFIX}/visual-reviews`).then((next) => next.json());
        saveMessage = issues.length === 0 ? "Saved clean page/state evidence." : `Saved with ${issues.length} issue(s) still visible.`;
        render();
      } catch (error) {
        saveMessage = String(error.message ?? error);
        status.textContent = saveMessage;
      } finally {
        button.disabled = false;
      }
    });
  }

  function schedule() {
    if (!enabled || scheduled) return;
    scheduled = true;
    requestAnimationFrame(render);
  }

  async function show() {
    [registry, reviewContext] = await Promise.all([
      fetch(`${PREFIX}/registry`).then((response) => {
        if (!response.ok) throw new Error(`registry request failed (${response.status})`);
        return response.json();
      }),
      fetch(`${PREFIX}/visual-reviews`).then((response) => response.ok ? response.json() : ({ records: [], surfaces: [] })),
    ]);
    ensure();
    enabled = true;
    observer ??= new MutationObserver(schedule);
    observer.observe(document.documentElement, { subtree: true, childList: true, attributes: true });
    window.addEventListener("scroll", schedule, true);
    window.addEventListener("resize", schedule);
    render();
    const items = snapshot();
    return { visibleControls: items.length, statuses: items.reduce((totals, item) => ({ ...totals, [item.status]: (totals[item.status] ?? 0) + 1 }), {}) };
  }

  function hide() {
    enabled = false;
    observer?.disconnect();
    window.removeEventListener("scroll", schedule, true);
    window.removeEventListener("resize", schedule);
    host?.remove();
  }

  async function set(mode) {
    if (mode === "hide" || (mode === "toggle" && enabled)) {
      hide();
      return { visible: false };
    }
    return { visible: true, ...(await show()) };
  }

  return { set };
})();

// The app's framework usually applies the consequences of an event a beat
// after the event itself; echo state after that beat, not before it.
async function echoAfter(element) {
  await new Promise((resolve) => setTimeout(resolve, 60));
  return stateEcho(element);
}

async function execute(command) {
  const { action, testId, path, value, key, keyValue, modifiers, predicate, timeoutMs, mode } = command;

  // observe: a compact structured snapshot of what is on screen right now,
  // anchored to registry ids. The agent's cheap alternative to a screenshot.
  if (action === "observe") {
    return {
      ok: true,
      detail: JSON.stringify(captureObservation(command.includeUnidentified === true)),
    };
  }

  if (action === "overlay") {
    const result = await coverageOverlay.set(mode ?? "toggle");
    return { ok: true, detail: JSON.stringify(result) };
  }

  if (action === "navigate") {
    // The result must reach the server before the page unloads, so the
    // navigation itself runs in `after` (the loop posts, then invokes it).
    return {
      ok: true,
      detail: `navigating to ${path}`,
      after: () => window.location.assign(path),
    };
  }

  const INTERACTIONS = ["click", "fill", "type", "press", "hover", "right-click", "select"];
  if (INTERACTIONS.includes(action)) {
    const found = await waitFor(() => {
      const element = byTestId(testId);
      return { done: Boolean(element), element };
    }, timeoutMs);
    const element = found.element;
    if (!element) return { ok: false, detail: `no element with data-testid ${JSON.stringify(testId)}` };
    element.scrollIntoView?.({ block: "center", behavior: command.paceMs > 0 ? "smooth" : "instant" });
    await cursor.glideTo(element, command.paceMs ?? 0);
    if (action === "click") {
      cursor.ripple(element);
      await clickElement(element);
      return { ok: true, detail: `clicked ${describe(element)}`, state: await echoAfter(element) };
    }
    if (action === "hover") {
      hoverElement(element);
      return { ok: true, detail: `hovered ${describe(element)}`, state: await echoAfter(element) };
    }
    if (action === "right-click") {
      cursor.ripple(element);
      rightClickElement(element);
      return { ok: true, detail: `right-clicked ${describe(element)}`, state: await echoAfter(element) };
    }
    if (action === "press") {
      pressKey(element, keyValue ?? key, modifiers);
      return { ok: true, detail: `pressed ${JSON.stringify(key)} on ${describe(element)}`, state: await echoAfter(element) };
    }
    if (action === "type") {
      // Paced sessions type at a watchable ~45ms per keystroke.
      await typeInto(element, value ?? "", command.paceMs > 0 ? 45 : 0);
      return { ok: true, detail: `typed ${JSON.stringify(value ?? "")} into ${describe(element)}`, state: await echoAfter(element) };
    }
    if (action === "select") {
      if (!(element instanceof HTMLSelectElement)) {
        return { ok: false, detail: `select needs a <select>; ${JSON.stringify(testId)} is ${describe(element)}. Custom dropdowns are click journeys: click the trigger, then click the option's own testid.` };
      }
      const option = [...element.options].find((o) => o.value === value || o.label === value || o.text === value);
      if (!option) return { ok: false, detail: `no option ${JSON.stringify(value)} in ${describe(element)}` };
      setNativeValue(element, option.value);
      element.dispatchEvent(new Event("input", { bubbles: true }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
      return { ok: true, detail: `selected ${JSON.stringify(option.value)} in ${describe(element)}`, state: await echoAfter(element) };
    }
    // fill: one-shot value set (no per-key events; use type for those).
    setNativeValue(element, value ?? "");
    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.dispatchEvent(new Event("change", { bubbles: true }));
    return { ok: true, detail: `filled ${describe(element)} with ${JSON.stringify(value ?? "")}`, state: await echoAfter(element) };
  }

  if (action === "read") {
    const element = byTestId(testId);
    if (!element) return { ok: false, detail: `no element with data-testid ${JSON.stringify(testId)}` };
    return {
      ok: true,
      detail: JSON.stringify({
        text: (element.textContent ?? "").trim(),
        value: "value" in element ? element.value : undefined,
        visible: isVisible(element),
        disabled: "disabled" in element ? element.disabled : undefined,
      }),
    };
  }

  if (action === "expect") {
    const verdict = await waitFor(() => {
      const element = byTestId(testId);
      if (!element) return { done: false, detail: "not found" };
      if (predicate === "visible") return { done: isVisible(element), detail: describe(element) };
      if (predicate === "enabled") return { done: !element.disabled, detail: describe(element) };
      if (predicate === "disabled") return { done: Boolean(element.disabled), detail: describe(element) };
      if (predicate === "contains-text") {
        return { done: (element.textContent ?? "").includes(command.value ?? ""), detail: describe(element) };
      }
      // Native inputs carry .checked; ARIA widgets (Radix Switch/Checkbox
      // render buttons) carry aria-checked.
      const checkedState = element.checked ?? (element.getAttribute("aria-checked") === "true");
      if (predicate === "checked") return { done: checkedState === true, detail: describe(element) };
      if (predicate === "unchecked") return { done: checkedState === false, detail: describe(element) };
      return { done: false, detail: `unknown predicate ${JSON.stringify(predicate)}` };
    }, timeoutMs);
    cursor.outline(byTestId(testId), !verdict.timedOut);
    if (verdict.timedOut) {
      return { ok: false, detail: `expect ${predicate} on ${JSON.stringify(testId)} timed out: ${verdict.detail}` };
    }
    return { ok: true, detail: `${predicate} confirmed: ${verdict.detail}`, state: stateEcho(byTestId(testId)) };
  }

  return { ok: false, detail: `unknown action ${JSON.stringify(action)}` };
}

// A page that is navigated away from (or frozen into the back/forward
// cache) must stop competing for commands: a ghost executor on a hidden page
// would win the long-poll race and swallow commands meant for the live one.
// pagehide aborts the in-flight poll and ends the loop; the next page load
// starts a fresh executor.
let stopped = false;
const abort = new AbortController();
window.addEventListener("pagehide", () => {
  stopped = true;
  abort.abort();
});

async function loop() {
  while (!stopped) {
    try {
      const response = await fetch(`${PREFIX}/next-command?executor=${EXECUTOR_ID}`, { signal: abort.signal });
      if (response.status !== 200) continue;
      const command = await response.json();
      console.debug("[agent-handles] executing", command.id, command.action, command.testId ?? command.path ?? "");
      const { after, ...result } = await execute(command);
      await fetch(`${PREFIX}/result`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ id: command.id, ...result }),
      });
      if (after) after();
    } catch (error) {
      if (stopped) return;
      console.error("[agent-handles] executor error:", error);
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
  }
}

loop();
