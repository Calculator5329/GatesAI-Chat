// The headless page host. Drive commands execute in a page, so headless work
// needs someone to hold one open; before this, adopters hand-wrote that
// Playwright script inside their own project.
//
// Not re-exported from ./drive/index.mjs on purpose: that module is imported
// by the Vite plugin, and a Playwright require does not belong on a path the
// app's own config walks. Only bin/agent-handles.mjs imports this.
import path from "node:path";
import process from "node:process";
import { createRequire } from "node:module";
import { DRIVE_PREFIX } from "./middleware.mjs";

export const DEFAULT_DRIVE_HOST_URL = "http://localhost:5173";
export const DEFAULT_READY_TIMEOUT_MS = 30_000;

const NEXT_COMMAND_PATH = `${DRIVE_PREFIX}/next-command`;
// Exact hostnames: a prefix or substring test admits 127.0.0.1.evil.example.
const LOOPBACK_HOSTS = new Set(["localhost", "127.0.0.1", "[::1]"]);

/** @returns {{ href: string, origin: string }} */
export function assertDriveHostUrl(url) {
  const refuse = (reason) => {
    throw new Error(`drive host refuses ${JSON.stringify(String(url))}: ${reason}. The drive endpoint is dev-server and test only; pass --url http://localhost:<dev-server-port>.`);
  };
  if (typeof url !== "string" || url.trim() === "") refuse("not a URL string");
  let parsed;
  try { parsed = new URL(url); }
  catch { refuse("not a parseable absolute URL"); }
  // Before the host check: "http://127.0.0.1@evil.example/" parses with
  // username 127.0.0.1 and host evil.example.
  if (parsed.username !== "" || parsed.password !== "") refuse("URL carries credentials");
  if (parsed.protocol !== "http:") refuse(`protocol ${parsed.protocol} is not http:`);
  if (!LOOPBACK_HOSTS.has(parsed.hostname)) refuse(`host ${JSON.stringify(parsed.hostname)} is not loopback`);
  return { href: parsed.href, origin: parsed.origin };
}

function sameOrigin(candidate, origin) {
  try { return new URL(candidate).origin === origin; }
  catch { return false; }
}

/**
 * Which command ids the drive server handed to *this* page, and in which
 * document generation. A delivery from a document that has since been replaced
 * proves nothing about the page as it is now.
 */
export function createDeliveryLedger() {
  let generation = 0;
  const delivered = new Map();
  return {
    generation: () => generation,
    navigated: () => { generation += 1; },
    record: (id, gen) => { delivered.set(id, gen); },
    provenNow: (id) => delivered.get(id) === generation,
  };
}

/**
 * Playwright belongs to the app being driven; this package declares no
 * dependency on it and invents no peer metadata for one.
 * @returns {{ chromium: object, from: string }}
 */
export function resolvePlaywright(root) {
  const require = createRequire(path.join(path.resolve(root), "package.json"));
  const tried = ["playwright", "@playwright/test"];
  for (const name of tried) {
    let loaded;
    try {
      loaded = require(name);
    } catch (error) {
      // MODULE_NOT_FOUND from *inside* an installed Playwright is a broken
      // install, not an absence; fail closed rather than misreport it.
      if (error?.code === "MODULE_NOT_FOUND" && String(error.message).includes(`'${name}'`)) continue;
      throw error;
    }
    if (loaded?.chromium?.launch) return { chromium: loaded.chromium, from: name };
    throw new Error(`${name} resolved from ${root} but exposes no chromium.launch.`);
  }
  throw new Error(`drive host needs Playwright, resolved from the app root ${root}, and found neither ${tried.join(" nor ")} there. Install one in the app (npm i -D @playwright/test) and download the browser (npx playwright install chromium).`);
}

async function launchChromium(root, headless) {
  const { chromium, from } = resolvePlaywright(root);
  try {
    return await chromium.launch({ headless });
  } catch (error) {
    // No substituting some other browser found on the machine.
    throw new Error(`drive host could not launch Chromium from the ${from} installed at ${root}: ${error?.message ?? error}. If the browser is not downloaded, run: npx playwright install chromium`, { cause: error });
  }
}

async function postJson(url, body, signal) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
    // Never follow: a redirect would take the probe off the origin the guard
    // approved, and a followed redirect answering 200 would read as ready.
    redirect: "manual",
    signal,
  });
  let payload;
  try { payload = await response.json(); }
  catch { payload = undefined; }
  return { status: response.status, payload };
}

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function settles(predicate, deadline) {
  const stop = Math.min(deadline, Date.now() + 2000);
  for (;;) {
    if (predicate()) return true;
    if (Date.now() >= stop) return false;
    await wait(25);
  }
}

/**
 * Readiness. A drive receipt on its own proves only that *some* executor at
 * this origin answered — an unrelated tab open on the same dev server will
 * answer an unpinned command perfectly well, which would let a host whose own
 * page has no executor report ready. So the receipt must be tied back to the
 * `next-command` payload this page was actually handed, in the document
 * generation it is in now. That link comes from Playwright's own view of the
 * page's traffic; the protocol is unchanged and no flag is planted in the page.
 */
async function proveDriveable({ origin, href, page, ledger, offOrigin, deadline, readyTimeoutMs }) {
  const signal = () => AbortSignal.timeout(Math.max(deadline - Date.now(), 1));
  const timedOut = (error) => ["TimeoutError", "AbortError"].includes(error?.name)
    || ["TimeoutError", "AbortError"].includes(error?.cause?.name);

  let reason = `nothing answered within ${readyTimeoutMs}ms`;
  let proven = false;
  while (!proven && Date.now() < deadline) {
    let session;
    try {
      session = await postJson(`${origin}${DRIVE_PREFIX}/session`, { paceMs: 0 }, signal());
    } catch (error) {
      throw new Error(`drive host could not reach ${origin}${DRIVE_PREFIX}/session: ${error?.message ?? error}`, { cause: error });
    }
    if (session.status !== 201 || typeof session.payload?.token !== "string") {
      throw new Error(`${origin} answered HTTP ${session.status} instead of opening a drive session. Is the agent-handles adapter and drive middleware in this dev server's config?`);
    }
    const token = session.payload.token;
  

    let probe;
    try {
      // The server queues the command and hands it over the moment an executor
      // polls, so a live page answers immediately.
      probe = await postJson(`${origin}${DRIVE_PREFIX}/command`, { token, command: { action: "observe" } }, signal());
    } catch (error) {
      if (timedOut(error)) break;
      throw new Error(`drive host got no answer to its readiness command at ${origin}: ${error?.message ?? error}`, { cause: error });
    }
    if (probe.status !== 200 || probe.payload?.ok !== true) {
      reason = probe.payload?.detail || probe.payload?.error || `HTTP ${probe.status}`;
      break;
    }
    proven = await settles(() => ledger.provenNow(probe.payload.id), deadline);
    // A command another tab's executor won is a lost race, not a verdict:
    // this page is polling too, so try again while time remains.
    if (!proven) {
      reason = "another executor at this origin answered it, and this page was never handed the command";
      await wait(50);
    }
  }
  if (!proven) {
    throw new Error(`the page at ${href} is not driveable: ${reason}. The executor requires the agent-handles Vite dev adapter or the Webpack plugin with development mode and drive:true; check the adapter and middleware are configured, that ${origin} is that dev server, and close other tabs on it if they are competing.`);
  }

  if (offOrigin.length > 0) {
    throw new Error(`drive host refuses ${href}: the page navigated off ${origin} to ${offOrigin[0]} during startup.`);
  }
  if (!sameOrigin(page.url(), origin)) {
    throw new Error(`drive host refuses ${href}: the page is at ${page.url()}, which is not ${origin}.`);
  }
}

/**
 * Open a browser page against a running dev server and hold it until closed.
 *
 * `readyTimeoutMs` bounds navigation and the readiness proof. It does not
 * bound launching the browser, which Playwright times out on its own terms.
 *
 * @returns {Promise<{ page: object, close: () => Promise<void> }>}
 */
export async function openDriveHost({
  url = DEFAULT_DRIVE_HOST_URL,
  root = process.cwd(),
  headless = true,
  readyTimeoutMs = DEFAULT_READY_TIMEOUT_MS,
} = {}) {
  const { href, origin } = assertDriveHostUrl(url);
  if (typeof readyTimeoutMs !== "number" || !Number.isFinite(readyTimeoutMs) || readyTimeoutMs <= 0) {
    throw new Error(`drive host needs a finite positive readyTimeoutMs, got ${JSON.stringify(readyTimeoutMs)}.`);
  }

  const browser = await launchChromium(root, headless);
  let closing;
  const close = () => (closing ??= (async () => { await browser.close(); })());

  try {
    const page = await browser.newPage();
    const ledger = createDeliveryLedger();
    const offOrigin = [];
    const requestGenerations = new WeakMap();

    const onNavigation = (frame) => {
      if (frame !== page.mainFrame()) return;
      ledger.navigated();
      const at = frame.url();
      // A fresh page starts at about:blank; that is the browser, not a remote
      // document. Resting there is still refused by the final URL check.
      if (at !== "about:blank" && !sameOrigin(at, origin)) offOrigin.push(at);
    };
    const onRequest = (request) => {
      try { if (request.frame() === page.mainFrame()) requestGenerations.set(request, ledger.generation()); }
      catch {}
    };
    const onResponse = (response) => {
      try { if (response.request().frame() !== page.mainFrame()) return; }
      catch { return; }
      if (response.status() !== 200) return;
      let at;
      try { at = new URL(response.url()); }
      catch { return; }
      if (at.origin !== origin || at.pathname !== NEXT_COMMAND_PATH) return;
      // A late response must keep the document identity of its request.
      const gen = requestGenerations.get(response.request());
      if (gen === undefined) return;
      response.json().then(
        (command) => { if (typeof command?.id === "string") ledger.record(command.id, gen); },
        () => {},
      );
    };
    page.on("framenavigated", onNavigation);
    page.on("request", onRequest);
    page.on("response", onResponse);
    const deadline = Date.now() + readyTimeoutMs;
    try {
      await page.goto(href, { waitUntil: "domcontentloaded", timeout: Math.max(deadline - Date.now(), 1) });
      await proveDriveable({ origin, href, page, ledger, offOrigin, deadline, readyTimeoutMs });
    } finally {
      page.off("framenavigated", onNavigation);
      page.off("request", onRequest);
      page.off("response", onResponse);
    }
    return { page, close };
  } catch (error) {
    await close().catch(() => {});
    throw error;
  }
}
