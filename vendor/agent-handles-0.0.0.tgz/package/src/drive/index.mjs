// Public surface of the ./drive subpath: the middleware (dev-server side of
// the protocol) and the path to the page executor source, which the Vite
// plugin serves as a dev-only virtual module. The executor itself is plain
// browser JS with no exports; it is shipped as text, never imported here, so
// nothing in a Node context ever evaluates it.
import { fileURLToPath } from "node:url";

export { createDriveMiddleware, createDriveState, DRIVE_PREFIX } from "./middleware.mjs";
export { normalizePressKey } from "./keyboard.mjs";
export { reconcileRuntimeObservation, registryIdentityMatch } from "./reconcile.mjs";

export const DRIVE_CLIENT_PATH = fileURLToPath(new URL("./client.mjs", import.meta.url));
