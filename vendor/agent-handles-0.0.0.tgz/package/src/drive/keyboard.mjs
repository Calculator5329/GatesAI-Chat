const MODIFIER_ALIASES = new Map([
  ["alt", "altKey"],
  ["option", "altKey"],
  ["control", "ctrlKey"],
  ["ctrl", "ctrlKey"],
  ["meta", "metaKey"],
  ["command", "metaKey"],
  ["cmd", "metaKey"],
  ["shift", "shiftKey"],
]);

/**
 * Turn Playwright-style key text (Control+Shift+k) into the browser event
 * fields used by the dev executor. The original chord remains in receipts;
 * this normalized form is transport-only.
 */
export function normalizePressKey(chord) {
  if (typeof chord !== "string" || chord.trim() === "") {
    throw new Error("press needs a non-empty key or chord (for example Enter or Control+k)");
  }
  const tokens = chord.split("+").map((token) => token.trim());
  if (tokens.some((token) => token === "")) throw new Error(`invalid key chord ${JSON.stringify(chord)}: empty chord segment`);
  const modifiers = {};
  const keys = [];
  for (const token of tokens) {
    const modifier = MODIFIER_ALIASES.get(token.toLowerCase());
    if (!modifier) {
      keys.push(token);
      continue;
    }
    if (modifiers[modifier]) throw new Error(`invalid key chord ${JSON.stringify(chord)}: duplicate modifier ${token}`);
    modifiers[modifier] = true;
  }
  if (keys.length !== 1) {
    throw new Error(`invalid key chord ${JSON.stringify(chord)}: declare exactly one non-modifier key`);
  }
  return { keyValue: keys[0], modifiers };
}
