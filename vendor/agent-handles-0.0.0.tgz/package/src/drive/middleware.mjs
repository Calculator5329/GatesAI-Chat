// Drive protocol, dev-server side (G2: internal in v1). Transport is
// connect-style middleware on the dev server; execution happens in the page
// via the injected client (client.mjs), which long-polls for commands and
// posts results back. An agent with nothing but curl can drive the app.
//
// Security, ruled 2026-08-24: loopback-only plus a per-session token, even in
// dev. Production builds carry no executor (the plugin injects only under
// `serve`; tested absent in the build output).
//
// Every command returns a receipt; a journey is a replayable receipt log.
import { randomBytes } from "node:crypto";
import { initializeJourneyRoute, journeyStartingPath } from "../journeys/starting-route.mjs";
import { renderJourneyMap } from "../journeys/map.mjs";
import { normalizePressKey } from "./keyboard.mjs";
import { reconcileRuntimeObservation } from "./reconcile.mjs";

const PREFIX = "/__agent-handles";
const COMMAND_TIMEOUT_MS = 15_000;
// A paced session glides the visible cursor; clamp so a typo can't freeze a
// replay for minutes per step.
const MAX_PACE_MS = 2000;
const DEFAULT_RUN_PACE_MS = 350;

// The interaction vocabulary (v2, 2026-08-25): fill sets a value in one
// shot; type is letter-by-letter with per-keystroke events; press is one
// key or modifier chord (Enter, Control+k...); select is native <select>
// only, custom dropdowns are click journeys against their options' own ids.
export const ADDRESSED_ACTIONS = ["click", "fill", "type", "press", "hover", "right-click", "select", "expect", "read"];
export const UNADDRESSED_ACTIONS = ["observe", "overlay"];

function isLoopback(req) {
  const address = req.socket?.remoteAddress ?? "";
  return address === "127.0.0.1" || address === "::1" || address === "::ffff:127.0.0.1";
}

function json(res, status, body) {
  res.statusCode = status;
  res.setHeader("content-type", "application/json");
  res.end(`${JSON.stringify(body, null, 2)}\n`);
}

async function readBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const text = Buffer.concat(chunks).toString("utf8");
  return text ? JSON.parse(text) : {};
}

export function createDriveState() {
  return {
    sessions: new Map(),      // token -> { id, startedAt, seq, receipts: [], paceMs, pin }
    pending: [],              // { command, pin } waiting for a page executor
    inFlight: new Map(),      // commandId -> { resolve, timer, executorId }
    waiters: [],              // { executorId, deliver } parked long-polls, oldest first
    executorsSeen: new Map(), // executorId -> last poll timestamp
    lastPollAt: 0,            // when any page executor last long-polled (liveness)
  };
}

// Deliver a command to a page executor. `pin` routes it to one specific
// executor (one page); unpinned commands go to the freshest poller, which in
// a multi-tab world is the closest thing to "the live tab". Resolves with
// the executor that actually answered, so callers can pin follow-ups.
function dispatchToPage(state, command, pin) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      state.inFlight.delete(command.id);
      const index = state.pending.findIndex((entry) => entry.command.id === command.id);
      if (index >= 0) state.pending.splice(index, 1);
      resolve({ ok: false, detail: `no page executor answered within ${COMMAND_TIMEOUT_MS}ms; is the app open in a browser?` });
    }, COMMAND_TIMEOUT_MS);
    const flight = {
      timer,
      executorId: undefined,
      resolve: (result) => resolve({ ...result, executorId: flight.executorId }),
    };
    state.inFlight.set(command.id, flight);
    for (let index = state.waiters.length - 1; index >= 0; index -= 1) {
      const waiter = state.waiters[index];
      if (pin && waiter.executorId !== pin) continue;
      state.waiters.splice(index, 1);
      flight.executorId = waiter.executorId;
      waiter.deliver(command);
      return;
    }
    state.pending.push({ command, pin });
  });
}

// After a full-page navigation the old executor dies (pagehide) and the new
// document starts polling under a brand-new id. Watch for the first id this
// run has never seen; that page is where the journey continues.
function waitForNewExecutor(state, knownIds, timeoutMs = 10_000) {
  const deadline = Date.now() + timeoutMs;
  return new Promise((resolve) => {
    const look = () => {
      for (const id of state.executorsSeen.keys()) {
        if (!knownIds.has(id)) return resolve(id);
      }
      if (Date.now() > deadline) return resolve(null);
      setTimeout(look, 100);
    };
    look();
  });
}

/**
 * @param {object} options
 * @param {() => Promise<string>} options.renderRegistry renders current registry JSON
 * @param {() => Promise<object|null>} [options.loadMapContext] fresh
 *   { manifest, unreachable, appLabel } for the live map + journey replay;
 *   both routes 404 when absent (tests, non-plugin embedders)
 * @param {(input: object) => Promise<object>} [options.recordVisualReview]
 * @param {() => Promise<object>} [options.loadVisualReviews]
 * @param {object} [options.state] injectable for tests
 */
export function createDriveMiddleware({
  renderRegistry,
  loadMapContext,
  recordVisualReview,
  loadVisualReviews,
  state = createDriveState(),
}) {
  const middleware = async (req, res, next) => {
    if (!req.url?.startsWith(`${PREFIX}/`)) return next();
    if (!isLoopback(req)) return json(res, 403, { error: "drive is loopback-only" });
    const url = new URL(req.url, "http://localhost");
    const route = url.pathname.slice(PREFIX.length);

    try {
      if (route === "/registry" && req.method === "GET") {
        res.statusCode = 200;
        res.setHeader("content-type", "application/json");
        return res.end(await renderRegistry());
      }

      if (route === "/session" && req.method === "POST") {
        const body = await readBody(req);
        const token = randomBytes(16).toString("hex");
        // paceMs > 0 makes the session visible: the page cursor glides to
        // each target over that many ms. 0 (the default) costs agents nothing.
        const paceMs = Math.min(Math.max(Number(body.paceMs) || 0, 0), MAX_PACE_MS);
        const session = { id: `drive-${Date.now().toString(36)}`, startedAt: new Date().toISOString(), seq: 0, receipts: [], paceMs };
        state.sessions.set(token, session);
        return json(res, 201, { token, sessionId: session.id, paceMs, commands: [...ADDRESSED_ACTIONS, "navigate", ...UNADDRESSED_ACTIONS] });
      }

      // Page executor long-poll: hand out the next command. Each page load
      // polls under its own executor id; pinned commands only ever go to
      // their pinned page, so a second open tab can't steal a journey step.
      if (route === "/next-command" && req.method === "GET") {
        const executorId = url.searchParams.get("executor") ?? "anonymous";
        state.lastPollAt = Date.now();
        state.executorsSeen.set(executorId, state.lastPollAt);
        const index = state.pending.findIndex((entry) => !entry.pin || entry.pin === executorId);
        if (index >= 0) {
          const [queued] = state.pending.splice(index, 1);
          const flight = state.inFlight.get(queued.command.id);
          if (flight) flight.executorId = executorId;
          return json(res, 200, queued.command);
        }
        return new Promise((resolve) => {
          const waiter = { executorId, deliver: (command) => { json(res, 200, command); resolve(); } };
          state.waiters.push(waiter);
          const drop = (respond) => {
            const at = state.waiters.indexOf(waiter);
            if (at >= 0) {
              state.waiters.splice(at, 1);
              if (respond) { res.statusCode = 204; res.end(); }
              resolve();
            }
          };
          // A poller whose page went away (tab closed, navigation) must not
          // stay in the waiter list: dispatching to its dead socket would
          // silently swallow the command and time the whole step out.
          res.on("close", () => drop(false));
          setTimeout(() => drop(true), 10_000);
        });
      }

      // Page executor posts a command's result back.
      if (route === "/result" && req.method === "POST") {
        const body = await readBody(req);
        const flight = state.inFlight.get(body.id);
        if (!flight) return json(res, 410, { error: "unknown or timed-out command id" });
        clearTimeout(flight.timer);
        state.inFlight.delete(body.id);
        flight.resolve({ ok: body.ok === true, detail: body.detail ?? "", state: body.state });
        return json(res, 200, {});
      }

      if (route === "/command" && req.method === "POST") {
        const body = await readBody(req);
        const session = state.sessions.get(body.token);
        if (!session) return json(res, 401, { error: "unknown session token; POST /__agent-handles/session first" });
        const { action, testId, path, value, key, predicate, timeoutMs, includeUnidentified, mode } = body.command ?? {};
        const addressed = ADDRESSED_ACTIONS.includes(action) && typeof testId === "string";
        const navigation = action === "navigate" && typeof path === "string" && path.startsWith("/");
        // observe takes no address: it snapshots whatever identified elements
        // are visible right now.
        const observation = action === "observe";
        const overlay = action === "overlay" && [undefined, "toggle", "show", "hide"].includes(mode);
        // A press with no target is the one shape agents actually send by
        // mistake (the key feels like the whole command). Name the missing
        // piece instead of reciting the whole grammar.
        if (action === "press" && (typeof testId !== "string" || testId.trim() === "")) {
          return json(res, 400, { error: "press is an addressed action: it needs a non-empty testId naming the element that receives the key (for example {action: press, testId: \"ui.picker.search\", key: \"Enter\"})" });
        }
        if (!addressed && !navigation && !observation && !overlay) {
          return json(res, 400, { error: `command must be {action: ${ADDRESSED_ACTIONS.join("|")}, testId, ...}, {action: navigate, path: "/..."}, {action: observe}, or {action: overlay, mode: toggle|show|hide}` });
        }
        let normalizedPress;
        if (action === "press") {
          try { normalizedPress = normalizePressKey(key); }
          catch (error) { return json(res, 400, { error: error.message }); }
        }
        if ((action === "fill" || action === "type" || action === "select") && typeof value !== "string") {
          return json(res, 400, { error: `${action} needs a string value` });
        }
        session.seq += 1;
        const id = `${session.id}-${session.seq}`;
        const started = Date.now();
        const knownBefore = new Set(state.executorsSeen.keys());
        let result = await dispatchToPage(state, { id, action, testId, path, value, key, ...normalizedPress, predicate, timeoutMs, includeUnidentified, mode, paceMs: session.paceMs }, session.pin);
        if (result.ok && action === "observe") {
          try {
            const observation = reconcileRuntimeObservation(JSON.parse(result.detail ?? "{}"), JSON.parse(await renderRegistry()));
            result = { ...result, detail: JSON.stringify(observation) };
          } catch (error) {
            result = { ...result, ok: false, detail: `runtime observation reconciliation failed: ${error.message}` };
          }
        }
        if (result.ok) {
          if (action === "navigate") {
            // The old page (and its executor) died with the navigation; the
            // session follows the new document that starts polling.
            session.pin = await waitForNewExecutor(state, knownBefore) ?? undefined;
          } else if (!session.pin) {
            session.pin = result.executorId;
          }
        }
        const receipt = {
          id,
          seq: session.seq,
          command: { action, ...(testId !== undefined && { testId }), ...(path !== undefined && { path }), ...(value !== undefined && { value }), ...(key !== undefined && { key }), ...(predicate !== undefined && { predicate }), ...(timeoutMs !== undefined && { timeoutMs }), ...(includeUnidentified !== undefined && { includeUnidentified: includeUnidentified === true }), ...(mode !== undefined && { mode }) },
          ok: result.ok,
          detail: result.detail,
          ...(result.state !== undefined && { state: result.state }),
          durationMs: Date.now() - started,
          at: new Date().toISOString(),
        };
        session.receipts.push(receipt);
        return json(res, result.ok ? 200 : 422, receipt);
      }

      // The live map: the static `journeys map` page plus a Run button per
      // journey, served fresh from the manifest + registry on every load.
      if (route === "/map" && req.method === "GET") {
        const context = await loadMapContext?.();
        if (!context?.manifest) return json(res, 404, { error: "no journey manifest available to map" });
        res.statusCode = 200;
        res.setHeader("content-type", "text/html; charset=utf-8");
        return res.end(renderJourneyMap({
          ...context,
          registry: JSON.parse(await renderRegistry()),
          live: true,
        }));
      }

      if (route === "/visual-reviews" && req.method === "GET") {
        const context = await loadMapContext?.();
        const summary = await loadVisualReviews?.() ?? {
          records: [], pageStatesReviewed: 0, routesReviewed: [], issueTotals: {}, clean: true,
        };
        return json(res, 200, {
          ...summary,
          surfaces: context?.reviewSurfaces ?? [],
        });
      }

      if (route === "/visual-reviews" && req.method === "POST") {
        if (!recordVisualReview) return json(res, 404, { error: "visual review persistence is not configured" });
        const body = await readBody(req);
        const receipt = await recordVisualReview(body);
        return json(res, 201, receipt);
      }

      // The live map's visual-review button toggles the projection in the app
      // tab. It is loopback-only and dev-only, like journey replay.
      if (route === "/overlay" && req.method === "POST") {
        if (Date.now() - state.lastPollAt > 12_000) {
          return json(res, 409, { error: "no page executor is polling; open the app in a browser tab first" });
        }
        const body = await readBody(req);
        const mode = ["show", "hide", "toggle"].includes(body.mode) ? body.mode : "toggle";
        const result = await dispatchToPage(state, {
          id: `overlay-${Date.now().toString(36)}`,
          action: "overlay",
          mode,
          paceMs: 0,
        });
        return json(res, result.ok ? 200 : 422, result);
      }

      // Journey replay: plays a manifest journey through the page executor,
      // streaming one NDJSON receipt per step so the map can light chips up
      // live. Loopback-only like everything here; the paced cursor makes the
      // run watchable in the app tab.
      if (route === "/run" && req.method === "POST") {
        const body = await readBody(req);
        const context = await loadMapContext?.();
        const journey = context?.manifest?.journeys?.find((candidate) => candidate.name === body.name);
        if (!journey) return json(res, 404, { error: `no journey named ${JSON.stringify(body.name ?? "")}` });
        try { journeyStartingPath(journey); }
        catch (error) { return json(res, 400, { error: error.message }); }
        if (Date.now() - state.lastPollAt > 12_000) {
          return json(res, 409, { error: "no page executor is polling; open the app in a browser tab first" });
        }
        const paceMs = Math.min(Math.max(Number(body.paceMs) || DEFAULT_RUN_PACE_MS, 0), MAX_PACE_MS);
        const runId = `replay-${Date.now().toString(36)}`;
        let seq = 0;
        let pin;
        let initializationSeq = 0;
        try {
          await initializeJourneyRoute(journey, async (command) => {
            const knownBefore = new Set(state.executorsSeen.keys());
            const result = await dispatchToPage(state, { ...command, id: `${runId}-initialize-${++initializationSeq}`, paceMs }, pin);
            if (result.ok) {
              if (command.action === "navigate") pin = await waitForNewExecutor(state, knownBefore) ?? undefined;
              else if (!pin) pin = result.executorId;
            }
            return result;
          });
        } catch (error) {
          return json(res, 422, { error: error.message });
        }
        res.statusCode = 200;
        res.setHeader("content-type", "application/x-ndjson");
        for (const step of journey.steps ?? []) {
          seq += 1;
          const started = Date.now();
          const knownBefore = new Set(state.executorsSeen.keys());
          let pageStep = step;
          try {
            pageStep = step.action === "press" ? { ...step, ...normalizePressKey(step.key) } : step;
          } catch (error) {
            res.write(`${JSON.stringify({ id: `${runId}-${seq}`, seq, command: step, ok: false, detail: error.message, durationMs: 0, at: new Date().toISOString() })}\n`);
            break;
          }
          const result = await dispatchToPage(state, { ...pageStep, id: `${runId}-${seq}`, paceMs }, pin);
          if (result.ok) {
            if (step.action === "navigate") pin = await waitForNewExecutor(state, knownBefore) ?? undefined;
            else if (!pin) pin = result.executorId;
          }
          let observation;
          let reconciled = result.ok;
          let detail = result.detail;
          if (result.ok) {
            const observed = await dispatchToPage(state, {
              id: `${runId}-observe-${seq}`,
              action: "observe",
              includeUnidentified: true,
              paceMs: 0,
            }, pin);
            try {
              observation = reconcileRuntimeObservation(
                JSON.parse(observed.detail ?? "{}"),
                JSON.parse(await renderRegistry()),
              );
            }
            catch { observation = { parseError: "observe returned non-JSON detail" }; }
            const unidentified = observation.unidentifiedInteractive ?? [];
            const duplicates = observation.duplicateTestIds ?? [];
            const unknown = observation.unknownTestIds ?? [];
            reconciled = observed.ok && unidentified.length === 0 && duplicates.length === 0 && unknown.length === 0;
            if (!reconciled) {
              detail = [
                detail,
                unidentified.length > 0 ? `${unidentified.length} visible interactive control(s) had no data-testid` : "",
                duplicates.length > 0 ? `duplicate visible data-testid values: ${duplicates.join(", ")}` : "",
                unknown.length > 0 ? `visible controls used ${unknown.length} identity value(s) absent from the registry` : "",
                !observed.ok ? `runtime observation failed: ${observed.detail}` : "",
              ].filter(Boolean).join("; ");
            }
          }
          res.write(`${JSON.stringify({
            id: `${runId}-${seq}`,
            seq,
            command: step,
            ok: reconciled,
            detail,
            ...(result.state !== undefined && { state: result.state }),
            ...(observation && { observation }),
            durationMs: Date.now() - started,
            at: new Date().toISOString(),
          })}\n`);
          if (!reconciled) break;
        }
        return res.end();
      }

      if (route === "/receipts" && req.method === "GET") {
        const session = state.sessions.get(url.searchParams.get("token"));
        if (!session) return json(res, 401, { error: "unknown session token" });
        return json(res, 200, { sessionId: session.id, startedAt: session.startedAt, receipts: session.receipts });
      }

      return json(res, 404, { error: `unknown drive route ${route}` });
    } catch (error) {
      return json(res, 500, { error: String(error?.message ?? error) });
    }
  };
  middleware.state = state;
  return middleware;
}

export { PREFIX as DRIVE_PREFIX };
