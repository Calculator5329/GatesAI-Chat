function patternPrefix(pattern) {
  return pattern.endsWith("*") ? pattern.slice(0, -1) : undefined;
}

export function registryIdentityMatch(testId, registry) {
  const literal = (registry?.entries ?? []).find((entry) => entry.id === testId);
  if (literal) return { kind: "literal", declaration: literal };
  const pattern = (registry?.patterns ?? []).find((entry) => {
    const prefix = patternPrefix(entry.pattern);
    return prefix !== undefined && testId.startsWith(prefix);
  });
  return pattern ? { kind: "pattern", declaration: pattern } : undefined;
}

/** Reconcile concrete visible DOM instances with the measured source registry. */
export function reconcileRuntimeObservation(observation, registry) {
  const controls = observation?.interactiveCandidates ?? observation?.controls ?? [];
  const counts = new Map();
  const matches = [];
  const unknown = [];
  for (const control of controls) {
    if (!control.testId) continue;
    counts.set(control.testId, (counts.get(control.testId) ?? 0) + 1);
    const match = registryIdentityMatch(control.testId, registry);
    if (match) {
      matches.push({
        testId: control.testId,
        kind: match.kind,
        file: match.declaration.file,
        line: match.declaration.line,
        declaration: match.declaration.id ?? match.declaration.pattern,
      });
    } else {
      unknown.push({ testId: control.testId, tag: control.tag, role: control.role, text: control.text });
    }
  }
  const duplicateInstances = [...counts.entries()]
    .filter(([, count]) => count > 1)
    .map(([testId, count]) => ({ testId, count }))
    .sort((left, right) => left.testId.localeCompare(right.testId));
  return {
    ...observation,
    registryMatches: matches,
    unknownTestIds: unknown,
    duplicateInstances,
    duplicateTestIds: duplicateInstances.map((instance) => instance.testId),
    instanceCounts: [...counts.entries()]
      .map(([testId, count]) => ({ testId, count }))
      .sort((left, right) => left.testId.localeCompare(right.testId)),
  };
}
