// Journeys are tests-as-data: steps of {action, testId, predicate?, value?,
// timeoutMs?} referencing registry identities. Two rulings shape this module
// (2026-08-24): a journey is a replayable receipt log (recording is the
// primary authoring path), and journeys COMPILE TO PLAYWRIGHT for execution,
// so trace viewer, CI, and reports stay on standard tooling.
//
// The step shape is byte-for-byte forge-shell/journey-manifest/v1's; only the
// namespace differs, and forge-shell's `surface`/`fixture` fields live in an
// adapter-supplied `context` block.
import { normalizePressKey } from "../drive/keyboard.mjs";
import { digest, renderArtifactWriter } from "../runtime/artifacts.mjs";
import { renderRuntimeObservationPredicate } from "../runtime/observation.mjs";

export const JOURNEY_SCHEMA = "agent-handles/journey/v1";

// Ethan's 2026-08-25 ruling: URL-only tests would not catch control bugs, so
// journeys carry their path kind and coverage counts them separately. A
// journey that reaches state through any navigate step is url-path; one that
// gets everywhere through controls is control-path (the entry context.path
// does not count against it; every test enters somewhere).
export function journeyKind(journey) {
  if (journey.kind !== undefined) return journey.kind;
  return journey.steps?.some((step) => step?.action === "navigate") ? "url-path" : "control-path";
}

const ACTIONS = new Set(["click", "fill", "type", "press", "hover", "right-click", "select", "expect", "navigate"]);
const PREDICATES = new Set(["visible", "enabled", "disabled", "contains-text", "checked", "unchecked"]);

export function validateJourney(journey) {
  if (typeof journey?.name !== "string" || !Array.isArray(journey.steps) || journey.steps.length === 0) {
    throw new Error("a journey needs a name and a non-empty steps array");
  }
  if (journey.kind !== undefined && !["control-path", "url-path"].includes(journey.kind)) {
    throw new Error(`${journey.name}: kind must be control-path or url-path`);
  }
  journey.steps.forEach((step, index) => {
    const where = `${journey.name} step ${index + 1}`;
    if (!ACTIONS.has(step?.action)) throw new Error(`${where}: unknown action ${JSON.stringify(step?.action)}`);
    if (step.action === "navigate") {
      if (typeof step.path !== "string" || !step.path.startsWith("/")) {
        throw new Error(`${where}: navigate needs a path starting with /`);
      }
    } else if (typeof step.testId !== "string") throw new Error(`${where}: missing testId`);
    if (step.action === "expect" && !PREDICATES.has(step.predicate)) {
      throw new Error(`${where}: expect needs a predicate in [${[...PREDICATES].join(", ")}]`);
    }
    if (step.action === "press" && typeof step.key !== "string") {
      throw new Error(`${where}: press needs a key (e.g. "Enter", "ArrowDown")`);
    }
    if (step.action === "press") {
      try { normalizePressKey(step.key); }
      catch (error) { throw new Error(`${where}: ${error.message}`); }
    }
    if ((step.action === "fill" || step.action === "type" || step.action === "select") && typeof step.value !== "string") {
      throw new Error(`${where}: ${step.action} needs a string value`);
    }
  });
  return journey;
}

/** A recorded drive session replays as a journey: successful receipts become steps. */
export function receiptsToJourney({ name, description, receipts, context }) {
  const steps = receipts
    .filter((receipt) => receipt.ok && receipt.command.action !== "read")
    .map((receipt) => ({ ...receipt.command }));
  const journey = {
    name,
    ...(description && { description }),
    ...(context && { context }),
    steps,
  };
  return validateJourney({ ...journey, kind: journeyKind(journey) });
}

const esc = (value) => JSON.stringify(value ?? "");

function stepToPlaywright(step, journeyName, stepNumber) {
  const locator = `page.getByTestId(${esc(step.testId)})`;
  const timeout = step.timeoutMs ? `, { timeout: ${step.timeoutMs} }` : "";
  let action;
  switch (step.action) {
    case "navigate": action = `  await page.goto(${esc(step.path)});`; break;
    case "click": action = `  await ${locator}.click();`; break;
    case "right-click": action = `  await ${locator}.click({ button: "right" });`; break;
    case "hover": action = `  await ${locator}.hover();`; break;
    case "press": action = `  await ${locator}.press(${esc(step.key)});`; break;
    case "type": action = `  await ${locator}.pressSequentially(${esc(step.value)});`; break;
    case "select": action = `  await ${locator}.selectOption(${esc(step.value)});`; break;
    case "fill": action = `  await ${locator}.fill(${esc(step.value)});`; break;
    case "expect":
      switch (step.predicate) {
        case "visible": action = `  await expect(${locator}).toBeVisible(${timeout ? timeout.slice(2) : ""});`; break;
        case "enabled": action = `  await expect(${locator}).toBeEnabled(${timeout ? timeout.slice(2) : ""});`; break;
        case "disabled": action = `  await expect(${locator}).toBeDisabled(${timeout ? timeout.slice(2) : ""});`; break;
        case "checked": action = `  await expect(${locator}).toBeChecked(${timeout ? timeout.slice(2) : ""});`; break;
        case "unchecked": action = `  await expect(${locator}).not.toBeChecked(${timeout ? timeout.slice(2) : ""});`; break;
        case "contains-text": action = `  await expect(${locator}).toContainText(${esc(step.value)}${timeout});`; break;
        default: throw new Error(`unknown predicate ${step.predicate}`);
      }
      break;
    default: throw new Error(`unknown action ${step.action}`);
  }
  return `${action}\n  await reconcileRuntime(page, ${esc(journeyName)}, ${stepNumber}, testInfo);`;
}

const PLAYWRIGHT_RUNTIME_HELPER = String.raw`
const runtimeObserved = new Map<string, Set<string>>();
const pendingRuntimeReceipts = new Map<string, object>();
const runtimeRegistryPath = path.resolve(process.cwd(), __AGENT_HANDLES_REGISTRY_PATH__);
type RuntimeRegistry = { entries?: Array<{ id: string }>; patterns?: Array<{ pattern: string }> };
let runtimeRegistryPromise: Promise<RuntimeRegistry> | undefined;

function loadRuntimeRegistry() {
  runtimeRegistryPromise ??= fs.readFile(runtimeRegistryPath, "utf8").then((text) => JSON.parse(text));
  return runtimeRegistryPromise;
}

function registryKnows(testId: string, registry: RuntimeRegistry) {
  if ((registry.entries ?? []).some((entry) => entry.id === testId)) return true;
  return (registry.patterns ?? []).some((entry) => entry.pattern.endsWith("*") && testId.startsWith(entry.pattern.slice(0, -1)));
}


async function captureRuntimeObservation(page: import("@playwright/test").Page) {
  let lastError: unknown;
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      return await page.evaluate(async () => {
        await new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
        __AGENT_HANDLES_RUNTIME_OBSERVATION_PREDICATE__
        const controls = Array.from(document.querySelectorAll(RUNTIME_INTERACTIVE_SELECTOR))
          .filter(isRuntimeObservationCandidate)
          .map((element) => ({
            testId: element.getAttribute("data-testid"),
            tag: element.tagName.toLowerCase(),
            role: element.getAttribute("role"),
            text: (element.textContent ?? "").trim().replace(/\s+/g, " ").slice(0, 120),
          }));
        const allIds = Array.from(document.querySelectorAll("[data-testid]"))
          .filter(isRuntimeObservationCandidate)
          .map((element) => element.getAttribute("data-testid"))
          .filter((value): value is string => Boolean(value));
        const duplicateTestIds = [...new Set(allIds.filter((value, index) => allIds.indexOf(value) !== index))].sort();
        return {
          url: location.href,
          controls,
          unidentified: controls.filter((control) => !control.testId),
          duplicateTestIds,
        };
      });
    } catch (error) {
      lastError = error;
      const navigationRace = /execution context was destroyed|most likely because of a navigation/iu.test(String(error));
      if (!navigationRace || attempt === 3) throw error;
      await page.waitForLoadState("domcontentloaded");
    }
  }
  throw lastError;
}

async function reconcileRuntime(page: import("@playwright/test").Page, journeyName: string, step: number, testInfo: import("@playwright/test").TestInfo) {
  const observation = await captureRuntimeObservation(page);
  const registry = await loadRuntimeRegistry();
  const unknownTestIds = observation.controls.filter((control) => control.testId && !registryKnows(control.testId, registry));
  const observed = runtimeObserved.get(testInfo.testId) ?? new Set<string>();
  for (const control of observation.controls) if (control.testId) observed.add(control.testId);
  runtimeObserved.set(testInfo.testId, observed);
  const receipt = {
    schema: "agent-handles/runtime-journey-observation/v1",
    measuredAt: new Date().toISOString(),
    journeyName,
    lastStep: step,
    pageUrl: observation.url,
    observedTestIds: [...observed].sort(),
    unidentified: observation.unidentified,
    unknownTestIds,
    duplicateTestIds: observation.duplicateTestIds,
    statement:
      [...observed].length +
      " controls observed during this journey; runtime evidence is path-bound, and unvisited states remain uncovered.",
  };
  pendingRuntimeReceipts.set(testInfo.testId, receipt);
  expect(observation.unidentified, "visible interactive controls without data-testid after step " + step).toEqual([]);
  expect(unknownTestIds, "visible controls with identity values absent from the registry after step " + step).toEqual([]);
  expect(observation.duplicateTestIds, "duplicate visible data-testid values after step " + step).toEqual([]);
}

async function recordFinalPageState(page: import("@playwright/test").Page, journeyName: string, testInfo: import("@playwright/test").TestInfo) {
  const observation = await captureRuntimeObservation(page);
  const registry = await loadRuntimeRegistry();
  const unknownTestIds = observation.controls.filter((control) => control.testId && !registryKnows(control.testId, registry));
  const directory = artifactDirectory(testInfo);
  const file = journeyName.replace(/[^a-z0-9._-]+/gi, "-").replace(/^-+|-+$/g, "") || "journey";
  const screenshotPath = path.join(directory, "final.png");
  await fs.mkdir(directory, { recursive: true });
  await page.screenshot({ path: screenshotPath, fullPage: true });
  const observedTestIds = [...new Set(observation.controls.map((control) => control.testId).filter(Boolean))].sort();
  const receipt = {
    schema: "agent-handles/page-state-review/v1",
    id: "journey-" + file,
    measuredAt: new Date().toISOString(),
    route: new URL(observation.url).pathname + new URL(observation.url).search,
    label: journeyName + " final state",
    title: await page.title(),
    evidenceKind: "compiled-journey-final",
    journeyName,
    visibleControls: observation.controls.length,
    identifiedControls: observation.controls.filter((control) => control.testId).length,
    issues: {
      unidentified: observation.unidentified.length,
      unknown: unknownTestIds.length,
      duplicate: observation.duplicateTestIds.length,
      reviewRequired: 0,
    },
    observedTestIds,
    screenshot: sha256(JSON.stringify(artifactIdentity(testInfo))) + "/final.png",
    statement:
      observation.controls.length +
      " controls observed in the final state of " +
      journeyName +
      "; this is page/state evidence, and unvisited states remain uncovered.",
  };
  pendingVisualReceipts.set(testInfo.testId, receipt);
}
`;

/**
 * Compile a journey manifest into one Playwright spec file (text).
 * @param {object} manifest {schema, journeys}
 * @param {object} [options] {baseUrl} baked into a page.goto per journey
 */
export function compileToPlaywright(manifest, options = {}) {
  if (manifest?.schema !== JOURNEY_SCHEMA || !Array.isArray(manifest.journeys)) {
    throw new Error(`manifest must use ${JOURNEY_SCHEMA} with a journeys array`);
  }
  const tests = manifest.journeys.map((journey) => {
    validateJourney(journey);
    const goto = options.baseUrl || journey.context?.path
      ? `  await page.goto(${esc(journey.context?.path ?? "/")});\n`
      : "";
    const body = journey.steps.map((step, index) => stepToPlaywright(step, journey.name, index + 1)).join("\n");
    const title = journey.description ? `${journey.name}: ${journey.description}` : journey.name;
    const inlineOpening = `test(${esc(title)}, async ({ page }, testInfo) => {`;
    const opening = inlineOpening.length <= 140
      ? inlineOpening
      : `test(${esc(title)}, async ({\n  page,\n}, testInfo) => {`;
    return `${opening}\n${goto}${body}\n  await recordFinalPageState(page, ${esc(journey.name)}, testInfo);\n});`;
  });
  return [
    `// Generated by agent-handles from ${JOURNEY_SCHEMA} journeys. Do not edit;`,
    `// edit the journey manifest and recompile (npx agent-handles journeys compile).`,
    `import fs from "node:fs/promises";`,
    `import { createHash } from "node:crypto";`,
    `import path from "node:path";`,
    `import { expect, test } from "@playwright/test";`,
    "",
    PLAYWRIGHT_RUNTIME_HELPER
      .replace("__AGENT_HANDLES_REGISTRY_PATH__", esc(options.registryPath ?? "testid-registry.json"))
      .replace(
        "__AGENT_HANDLES_RUNTIME_OBSERVATION_PREDICATE__",
        renderRuntimeObservationPredicate({ typescript: true }).replaceAll("\n", "\n        "),
      )
      .trim(),
    "",
    renderArtifactWriter().replace("__AGENT_HANDLES_MANIFEST_DIGEST__", esc(digest(JSON.stringify(manifest)))),
    tests.join("\n\n"),
    "",
  ].join("\n");
}
