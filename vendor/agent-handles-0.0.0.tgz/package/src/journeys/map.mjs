// The journey map: one self-contained HTML page showing every journey as a
// lane of steps, plus per-area coverage and the surfaces a project has
// declared unreachable (fathom's auth wall was the first). Generated from
// the same artifacts agents read (journeys manifest + registry), so the page
// is a projection, never a second source of truth.
import { journeyKind } from "./index.mjs";

const esc = (text) => String(text)
  .replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;");

// Action classes drive the chip colors: doing (mutates state), asking
// (assertions), and jumping (navigate, the url-path marker).
const ACTION_CLASS = {
  click: "do", fill: "do", type: "do", press: "do", hover: "do",
  "right-click": "do", select: "do",
  expect: "ask", read: "ask",
  navigate: "jump",
};

function stepPayload(step) {
  if (step.action === "navigate") return step.path;
  if (step.action === "press") return step.key;
  if (step.action === "expect") {
    return [step.predicate, step.value].filter(Boolean).join(" ");
  }
  return step.value;
}

function areaOf(id) {
  return id.split(".")[0];
}

export function renderJourneyMap({
  manifest,
  registry,
  unreachable,
  reviewSurfaces = [],
  visualReviews = { records: [], routesReviewed: [], issueTotals: {} },
  appLabel = "app",
  live = false,
}) {
  const journeys = (manifest?.journeys ?? []).map((journey) => ({ ...journey, kind: journeyKind(journey) }));
  const walledIds = new Set(unreachable?.testIds ?? []);

  const touched = new Set();
  for (const journey of journeys) {
    for (const step of journey.steps ?? []) if (typeof step.testId === "string") touched.add(step.testId);
  }

  // Per-area rollup from the registry: how many identities exist, how many a
  // journey exercises. Pattern-covered ids (ui.ticker-picker.option-TXRH)
  // credit their pattern's area.
  const entries = registry?.entries ?? [];
  const patterns = (registry?.patterns ?? []).map((entry) => entry.pattern);
  const areas = new Map();
  const area = (name) => {
    if (!areas.has(name)) areas.set(name, { ids: 0, patterns: 0, touched: 0, walled: 0 });
    return areas.get(name);
  };
  for (const entry of entries) {
    const record = area(areaOf(entry.id));
    record.ids += 1;
    if (touched.has(entry.id)) record.touched += 1;
    if (walledIds.has(entry.id)) record.walled += 1;
  }
  for (const pattern of patterns) {
    const record = area(areaOf(pattern));
    record.patterns += 1;
    if ([...touched].some((id) => id.startsWith(pattern.slice(0, -1)))) record.touched += 1;
  }

  const kindCount = (kind) => journeys.filter((journey) => journey.kind === kind).length;

  const lane = (journey) => {
    const chips = (journey.steps ?? []).map((step) => {
      const payload = stepPayload(step);
      const cls = ACTION_CLASS[step.action] ?? "ask";
      const idAttr = typeof step.testId === "string" ? ` data-id="${esc(step.testId)}"` : "";
      return `<span class="chip ${cls}"${idAttr}>`
        + `<b>${esc(step.action)}</b>`
        + (step.testId ? `<i>${esc(step.testId)}</i>` : "")
        + (payload ? `<u>${esc(payload)}</u>` : "")
        + `</span>`;
    }).join(`<span class="arr">&rarr;</span>`);
    return `<section class="journey" data-journey="${esc(journey.name)}">
      <header>
        <h2>${esc(journey.name)}</h2>
        <span class="kind ${journey.kind}">${esc(journey.kind)}</span>
        <span class="n">${journey.steps?.length ?? 0} steps</span>
        ${journey.context?.path ? `<span class="n">enters at <i>${esc(journey.context.path)}</i></span>` : ""}
        ${live ? `<button class="run" data-name="${esc(journey.name)}">&#9654; run</button><span class="run-status n"></span>` : ""}
      </header>
      ${journey.description ? `<p>${esc(journey.description)}</p>` : ""}
      <div class="lane">${chips}</div>
    </section>`;
  };

  const areaRows = [...areas.entries()]
    .sort((left, right) => (right[1].ids + right[1].patterns) - (left[1].ids + left[1].patterns))
    .map(([name, record]) => {
      const total = record.ids + record.patterns;
      const pct = total === 0 ? 0 : Math.round((record.touched / total) * 100);
      const walled = record.walled > 0 ? `<span class="wall">auth wall</span>` : "";
      return `<tr>
        <td class="mono">${esc(name)}</td>
        <td class="num">${record.ids}${record.patterns ? ` <span class="dim">+${record.patterns} patterns</span>` : ""}</td>
        <td class="num">${record.touched}</td>
        <td class="barcell"><div class="bar"><div style="width:${pct}%"></div></div><span class="num dim">${pct}%</span></td>
        <td>${walled}</td>
      </tr>`;
    }).join("\n");

  const wallSection = walledIds.size === 0 ? "" : `<section class="walled">
    <h2>Behind the auth wall</h2>
    <p>${esc(unreachable?.note ?? "Declared unreachable; journeys never automate credentials.")}</p>
    <div class="lane">${[...walledIds].map((id) => `<span class="chip wall-chip"><i>${esc(id)}</i></span>`).join("")}</div>
  </section>`;

  const recordedBySurface = new Map((visualReviews.records ?? []).map((record) => [record.surfaceId ?? record.id, record]));
  const recordedRoutes = new Set((visualReviews.records ?? []).map((record) => record.route));
  const reviewRows = reviewSurfaces.length > 0
    ? reviewSurfaces.map((surface) => {
      const record = recordedBySurface.get(surface.id);
      const issueCount = record ? Object.values(record.issues ?? {}).reduce((total, count) => total + Number(count || 0), 0) : 0;
      const status = !record ? "unreviewed" : issueCount > 0 ? `${issueCount} issue${issueCount === 1 ? "" : "s"}` : "reviewed clean";
      return `<tr><td>${esc(surface.label ?? surface.id)}</td><td class="mono">${esc(surface.route)}</td><td class="${record && issueCount === 0 ? "review-ok" : "review-open"}">${esc(status)}</td><td class="dim">${record?.screenshot ? "screenshot saved" : record ? "receipt saved" : ""}</td></tr>`;
    }).join("\n")
    : (visualReviews.records ?? []).map((record) => {
      const issueCount = Object.values(record.issues ?? {}).reduce((total, count) => total + Number(count || 0), 0);
      return `<tr><td>${esc(record.label)}</td><td class="mono">${esc(record.route)}</td><td class="${issueCount === 0 ? "review-ok" : "review-open"}">${issueCount === 0 ? "reviewed clean" : `${issueCount} issue${issueCount === 1 ? "" : "s"}`}</td><td class="dim">${record.screenshot ? "screenshot saved" : "receipt saved"}</td></tr>`;
    }).join("\n");
  const reviewTotal = reviewSurfaces.length || recordedRoutes.size;
  const reviewDone = reviewSurfaces.length > 0
    ? reviewSurfaces.filter((surface) => recordedBySurface.has(surface.id)).length
    : recordedRoutes.size;
  const reviewSection = `<section class="journey review">
    <h2 style="font-family:system-ui,sans-serif">Page and state evidence</h2>
    <p><b>${reviewDone}</b> of <b>${reviewTotal || "?"}</b> declared states have evidence. This is path-bound: unvisited routes and hidden states remain uncovered.</p>
    ${reviewRows ? `<table><tr><th>state</th><th>route</th><th>status</th><th>artifact</th></tr>${reviewRows}</table>` : `<p class="review-open">No page/state evidence recorded yet.</p>`}
  </section>`;

  const coverage = registry?.coverage ?? {};
  return `<!doctype html>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(appLabel)} journey map</title>
<style>
  :root {
    --bg: #0b0f0d; --surface: #12171400; --line: #222b25; --text: #d8ded9;
    --muted: #7d877f; --accent: #34d399; --ask: #8a958c; --jump: #fbbf24;
    --wall: #f87171;
  }
  * { box-sizing: border-box; }
  body { margin: 0; padding: 28px 32px 60px; background: var(--bg); color: var(--text);
    font: 15px/1.45 system-ui, sans-serif; }
  .mono, i, u, b { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-style: normal; }
  h1 { font-size: 20px; margin: 0; letter-spacing: -0.01em; }
  .meta { color: var(--muted); margin: 6px 0 26px; }
  .meta b { color: var(--text); font-weight: 600; }
  section.journey, section.walled { border-top: 1px solid var(--line); padding: 14px 0 18px; }
  section header { display: flex; align-items: baseline; gap: 12px; }
  h2 { font-size: 15px; margin: 0; font-family: ui-monospace, Menlo, monospace; }
  .kind { font-size: 12px; padding: 1px 7px; border: 1px solid var(--line); }
  .kind.control-path { color: var(--accent); border-color: color-mix(in srgb, var(--accent) 40%, transparent); }
  .kind.url-path { color: var(--jump); border-color: color-mix(in srgb, var(--jump) 40%, transparent); }
  .n { color: var(--muted); font-size: 13px; }
  section p { color: var(--muted); font-size: 13px; margin: 6px 0 10px; max-width: 88ch; }
  .lane { display: flex; flex-wrap: wrap; align-items: center; gap: 6px 4px; }
  .chip { display: inline-flex; gap: 7px; align-items: baseline; border: 1px solid var(--line);
    padding: 3px 8px; font-size: 12.5px; background: rgba(255,255,255,0.015); cursor: default; }
  .chip b { font-weight: 600; }
  .chip.do b { color: var(--accent); }
  .chip.ask b { color: var(--ask); }
  .chip.jump b { color: var(--jump); }
  .chip i { color: var(--text); }
  .chip u { color: var(--muted); text-decoration: none; }
  .chip u::before { content: '"'; } .chip u::after { content: '"'; }
  .chip.hot { border-color: var(--accent); background: color-mix(in srgb, var(--accent) 10%, transparent); }
  .arr { color: var(--muted); font-size: 12px; padding: 0 1px; }
  table { border-collapse: collapse; width: 100%; max-width: 720px; margin-top: 8px; }
  th { text-align: left; color: var(--muted); font-weight: 500; font-size: 13px;
    border-bottom: 1px solid var(--line); padding: 4px 14px 6px 0; }
  td { padding: 5px 14px 5px 0; border-bottom: 1px solid color-mix(in srgb, var(--line) 55%, transparent); font-size: 13.5px; }
  .num { font-family: ui-monospace, Menlo, monospace; font-variant-numeric: tabular-nums; }
  .dim { color: var(--muted); }
  .barcell { display: flex; align-items: center; gap: 8px; min-width: 160px; }
  .bar { flex: 1; height: 4px; background: var(--line); }
  .bar div { height: 100%; background: var(--accent); }
  .chip.ok { border-color: color-mix(in srgb, var(--accent) 65%, transparent); }
  .chip.fail { border-color: var(--wall); box-shadow: 0 0 8px 1px color-mix(in srgb, var(--wall) 35%, transparent); }
  button.run { margin-left: auto; background: none; border: 1px solid color-mix(in srgb, var(--accent) 45%, transparent);
    color: var(--accent); font: 12px ui-monospace, Menlo, monospace; padding: 2px 10px; cursor: pointer; }
  button.run:hover { background: color-mix(in srgb, var(--accent) 12%, transparent); }
  button.run:disabled { color: var(--muted); border-color: var(--line); cursor: default; }
  .overlay-row { margin: -14px 0 22px; display:flex; align-items:center; gap:10px; }
  button.overlay { background: color-mix(in srgb, var(--accent) 8%, transparent); border: 1px solid color-mix(in srgb, var(--accent) 45%, transparent);
    color: var(--accent); font: 12px ui-monospace, Menlo, monospace; padding: 5px 11px; cursor: pointer; border-radius: 5px; }
  .wall, .wall-chip i { color: var(--wall); }
  .review-ok { color: #75ad8b; }.review-open { color: #f0a27f; }
  .wall { font-size: 12px; border: 1px solid color-mix(in srgb, var(--wall) 40%, transparent); padding: 1px 7px; }
  .wall-chip { border-color: color-mix(in srgb, var(--wall) 35%, transparent); }
  section.walled h2 { color: var(--wall); font-family: system-ui, sans-serif; font-size: 14px; }
</style>
<h1>${esc(appLabel)} journey map</h1>
<p class="meta">
  <b>${journeys.length}</b> journeys (<b>${kindCount("control-path")}</b> control-path, <b>${kindCount("url-path")}</b> url-path)
  &middot; <b>${coverage.identifiedInteractive ?? "?"}</b>/<b>${coverage.interactiveElements ?? "?"}</b> interactive elements identified
  &middot; <b>${entries.length}</b> ids + <b>${patterns.length}</b> patterns
  &middot; hover a step to trace its id across journeys
</p>
${live ? `<div class="overlay-row"><button class="overlay">Review visible controls in app</button><span class="overlay-status n">Page/state evidence only</span></div>` : ""}
${journeys.map(lane).join("\n")}
${wallSection}
${reviewSection}
<section class="journey">
  <h2 style="font-family:system-ui,sans-serif">Journey evidence by area</h2>
  <table>
    <tr><th>area</th><th>ids</th><th>in journeys</th><th>exercised</th><th></th></tr>
    ${areaRows}
  </table>
</section>
<script>
  const chips = [...document.querySelectorAll(".chip[data-id]")];
  for (const chip of chips) {
    chip.addEventListener("mouseenter", () => {
      for (const other of chips) if (other.dataset.id === chip.dataset.id) other.classList.add("hot");
    });
    chip.addEventListener("mouseleave", () => {
      for (const other of chips) other.classList.remove("hot");
    });
  }
</script>
${live ? `<script>
  // Live mode (served from the dev middleware): each Run button replays its
  // journey through the page executor in the open app tab. Receipts stream
  // back as NDJSON; chips light up as their step lands.
  const overlayButton = document.querySelector("button.overlay");
  const overlayStatus = document.querySelector(".overlay-status");
  overlayButton.addEventListener("click", async () => {
    overlayButton.disabled = true;
    try {
      const response = await fetch("/__agent-handles/overlay", {
        method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ mode: "toggle" }),
      });
      const result = await response.json();
      if (!response.ok) overlayStatus.textContent = result.error ?? result.detail ?? "overlay failed";
      else {
        const detail = JSON.parse(result.detail ?? "{}");
        overlayStatus.textContent = detail.visible
          ? detail.visibleControls + " visible controls ready for page/state review in the app tab"
          : "overlay hidden";
      }
    } catch (error) { overlayStatus.textContent = String(error); }
    finally { overlayButton.disabled = false; }
  });
  for (const button of document.querySelectorAll("button.run")) {
    button.addEventListener("click", async () => {
      const section = button.closest("section");
      const stepChips = [...section.querySelectorAll(".chip")];
      const status = section.querySelector(".run-status");
      for (const chip of stepChips) chip.classList.remove("ok", "fail");
      button.disabled = true;
      status.textContent = "running...";
      try {
        const response = await fetch("/__agent-handles/run", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ name: button.dataset.name }),
        });
        if (response.status !== 200) {
          status.textContent = (await response.json()).error ?? ("run failed (" + response.status + ")");
          return;
        }
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffered = "";
        let index = 0;
        let failed = false;
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          buffered += decoder.decode(value, { stream: true });
          let newline;
          while ((newline = buffered.indexOf("\\n")) >= 0) {
            const line = buffered.slice(0, newline).trim();
            buffered = buffered.slice(newline + 1);
            if (!line) continue;
            const receipt = JSON.parse(line);
            stepChips[index]?.classList.add(receipt.ok ? "ok" : "fail");
            index += 1;
            if (!receipt.ok) { failed = true; status.textContent = receipt.detail; }
          }
        }
        if (!failed) status.textContent = index + "/" + stepChips.length + " ok";
      } catch (error) {
        status.textContent = String(error);
      } finally {
        button.disabled = false;
      }
    });
  }
</script>` : ""}`;
}
