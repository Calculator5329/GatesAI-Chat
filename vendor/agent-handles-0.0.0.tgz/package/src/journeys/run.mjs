// Journey replay over the drive protocol: the human-facing twin of the
// compiled Playwright spec. Same steps, same receipts, but executed in the
// user's own browser tab through the dev-server middleware, with the paced
// cursor making each step visible. Playwright stays the CI truth; this is
// the watchable one.
import { DRIVE_PREFIX } from "../drive/index.mjs";

/**
 * @param {object} options
 * @param {string} options.baseUrl dev server origin, e.g. http://localhost:5199
 * @param {object} options.journey a manifest journey ({ name, steps })
 * @param {number} [options.paceMs] cursor glide per step; 0 replays at agent speed
 * @param {(receipt: object) => void} [options.onReceipt] called as each step lands
 * @param {typeof fetch} [options.fetchImpl]
 * @returns {Promise<object[]>} one receipt per executed step (stops at first failure)
 */
export async function runJourney({ baseUrl, journey, paceMs = 350, onReceipt = () => {}, fetchImpl = fetch }) {
  const origin = baseUrl.replace(/\/$/, "");
  const opened = await fetchImpl(`${origin}${DRIVE_PREFIX}/session`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ paceMs }),
  });
  if (opened.status !== 201) {
    throw new Error(`could not open a drive session at ${origin} (HTTP ${opened.status}); is the dev server running with the agent-handles plugin?`);
  }
  const { token } = await opened.json();

  const receipts = [];
  for (const step of journey.steps ?? []) {
    const response = await fetchImpl(`${origin}${DRIVE_PREFIX}/command`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ token, command: step }),
    });
    const receipt = await response.json();
    if (receipt.ok) {
      const observedResponse = await fetchImpl(`${origin}${DRIVE_PREFIX}/command`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ token, command: { action: "observe", includeUnidentified: true } }),
      });
      const observedReceipt = await observedResponse.json();
      let observation;
      try { observation = JSON.parse(observedReceipt.detail ?? "{}"); }
      catch { observation = { parseError: "observe returned non-JSON detail" }; }
      receipt.observation = observation;
      const unidentified = observation.unidentifiedInteractive ?? [];
      const duplicates = observation.duplicateTestIds ?? [];
      const unknown = observation.unknownTestIds ?? [];
      if (!observedReceipt.ok || unidentified.length > 0 || duplicates.length > 0 || unknown.length > 0) {
        receipt.ok = false;
        receipt.detail = [
          receipt.detail,
          unidentified.length > 0 ? `${unidentified.length} visible interactive control(s) had no data-testid` : "",
          duplicates.length > 0 ? `duplicate visible data-testid values: ${duplicates.join(", ")}` : "",
          unknown.length > 0 ? `visible controls used ${unknown.length} identity value(s) absent from the registry` : "",
          !observedReceipt.ok ? `runtime observation failed: ${observedReceipt.detail}` : "",
        ].filter(Boolean).join("; ");
      }
    }
    const journeySeq = receipts.length + 1;
    if (receipt.seq !== journeySeq) {
      receipt.driveSeq = receipt.seq;
      receipt.seq = journeySeq;
    }
    receipts.push(receipt);
    onReceipt(receipt);
    if (!receipt.ok) break;
  }
  return receipts;
}
