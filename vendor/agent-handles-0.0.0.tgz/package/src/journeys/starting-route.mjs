// Entry navigation is initialization, not an authored journey control step.
// All three execution surfaces validate the same optional adapter path.
export function journeyStartingPath(journey) {
  const context = journey.context;
  if (context == null) return undefined;
  if (typeof context !== 'object' || Array.isArray(context)) {
    throw new Error(`${journey.name}: context must be an object when provided`);
  }
  if (!Object.hasOwn(context, 'path')) return undefined;
  const path = context.path;
  if (typeof path !== 'string' || !path.startsWith('/') || path.startsWith('//') || /[\\\u0000-\u001f\u007f]/u.test(path)) {
    throw new Error(`${journey.name}: context.path must be a root-relative path without a host, backslash or control character`);
  }
  return path;
}

/** sendCommand returns an explicit successful receipt, or throws on transport failure. */
export async function initializeJourneyRoute(journey, sendCommand) {
  const path = journeyStartingPath(journey);
  if (path === undefined) return;
  try {
    for (const command of [{action: 'navigate', path}, {action: 'observe', includeUnidentified: true}]) {
      const receipt = await sendCommand(command);
      if (receipt?.ok !== true) {
        throw new Error(`${command.action} failed: ${receipt?.detail ?? 'no successful executor receipt'}`, {cause: receipt});
      }
    }
  } catch (error) {
    throw new Error(`could not initialize journey ${journey.name} at ${path}: ${error.message}`, {cause: error});
  }
}
