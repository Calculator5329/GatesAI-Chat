// The coverage ratchet, done right this time (G1 + the 2026-08-24 refinement
// rulings). The origin's single high-water mark rewrote itself to the current
// count on every regenerate (forge-shell testid-registry.mjs:144), so it
// could never be crossed and never had to be improved. This one:
//   - keeps a PER-FILE floor of allowed unidentified interactive elements;
//   - moves a floor DOWN automatically when coverage improves;
//   - never raises a floor: a count above its floor is a refusal, and raising
//     is a deliberate hand edit that must carry a `raised` note;
//   - records the detection predicate's version, so changing what "counts as
//     interactive" cannot silently re-baseline every floor.
// G1: block regression, warn on stagnation. Both halves tested.

// v1: intrinsic button/input/select/textarea only. v2 (2026-08-25): plus
// configured component wrappers. v3: definite + review-required source
// candidates across TSX/JSX, with interaction-removal fingerprints. v4 carries
// invalid/legacy identities as adoption evidence instead of aborting before
// the prompt. Floors do not carry across predicate versions; upgrading requires a deliberate
// `ratchet rebaseline`, committed as its own reviewed change.
export const DETECTION_PREDICATE_VERSION = 4;

export const RATCHET_SCHEMA = "agent-handles/ratchet/v2";

export function emptyRatchet() {
  return { schema: RATCHET_SCHEMA, predicateVersion: DETECTION_PREDICATE_VERSION, floors: {}, interactionSites: [] };
}

const allowedFloor = (floor) => typeof floor === "object" ? floor.allowed : floor;

/** Cross-check the mutable ratchet file against the last verified seal. */
export function assertRatchetNotRaised(ratchet, sealedRatchet) {
  if (!sealedRatchet) return;
  for (const [file, sealedFloor] of Object.entries(sealedRatchet.floors ?? {})) {
    const currentFloor = ratchet.floors?.[file];
    if (currentFloor === undefined) {
      throw new Error(`sealed ratchet integrity failure: floor for ${file} was removed.`);
    }
    if (allowedFloor(currentFloor) > allowedFloor(sealedFloor)) {
      throw new Error(
        `sealed ratchet integrity failure: ${file} floor was raised from ${allowedFloor(sealedFloor)} to ${allowedFloor(currentFloor)}.`,
      );
    }
  }
  const currentSites = new Set(ratchet.interactionSites ?? []);
  const removedSites = (sealedRatchet.interactionSites ?? []).filter((site) => !currentSites.has(site));
  if (removedSites.length > 0) {
    throw new Error(
      `sealed ratchet integrity failure: ${removedSites.length} sealed interaction site(s) were removed from the ratchet.`,
    );
  }
}

function perFileCounts(registry) {
  const counts = {};
  for (const entry of registry.unidentifiedInteractive ?? []) {
    counts[entry.file] = (counts[entry.file] ?? 0) + 1;
  }
  return counts;
}

/**
 * Evaluate the current registry against the ratchet state.
 * Returns { verdict: "ok" | "improved" | "stagnant", nextRatchet, warnings }
 * or throws on regression / predicate mismatch / hand-raised floor without a note.
 */
export function evaluateRatchet(registry, ratchet, { mode = "sealed" } = {}) {
  if (!['sealed', 'adoption'].includes(mode)) throw new Error(`unknown ratchet mode ${JSON.stringify(mode)}.`);
  const state = ratchet ?? emptyRatchet();
  if (state.schema !== RATCHET_SCHEMA) {
    throw new Error(`ratchet state must use schema ${RATCHET_SCHEMA}; got ${JSON.stringify(state.schema)}.`);
  }
  if (state.predicateVersion !== DETECTION_PREDICATE_VERSION) {
    throw new Error(
      `ratchet floors were measured under detection predicate v${state.predicateVersion}, `
      + `but this scanner is v${DETECTION_PREDICATE_VERSION}. Floors do not carry across predicates; `
      + "re-baseline deliberately with `ratchet rebaseline` and commit the result as its own reviewed change.",
    );
  }
  const currentSites = new Set(registry?.interactionFingerprint?.sites ?? []);
  const priorSites = new Set(state.interactionSites ?? []);
  const removed = [...priorSites].filter((site) => !currentSites.has(site)).sort();
  if (removed.length > 0) {
    throw new Error(
      `interaction fingerprint regression: ${removed.length} previously measured control candidate(s) disappeared `
      + `(${removed.slice(0, 5).join(", ")}${removed.length > 5 ? ", ..." : ""}). `
      + "Restore the interaction or record and receive an owner verdict for the source removal before re-baselining.",
    );
  }

  const counts = perFileCounts(registry);
  const floors = state.floors ?? {};
  const regressions = [];
  const nextFloors = {};
  let improved = false;
  if ([...currentSites].some((site) => !priorSites.has(site))) improved = true;

  for (const [file, count] of Object.entries(counts)) {
    const floor = floors[file];
    if (floor === undefined) {
      if (mode === "sealed" && count > 0) {
        regressions.push({ file, allowed: 0, count });
        nextFloors[file] = 0;
      } else {
        // Adoption may start a new file where it is. Once sealed, every new
        // file starts at zero and must arrive identified.
        nextFloors[file] = count;
      }
      continue;
    }
    const allowed = allowedFloor(floor);
    if (count > allowed) {
      regressions.push({ file, allowed, count });
      nextFloors[file] = floor; // adoption never raises a committed floor
    } else if (count < allowed) {
      improved = true;
      nextFloors[file] = count; // down-only, automatic
    } else {
      nextFloors[file] = floor; // unchanged (preserves a raised-note object)
    }
  }
  // A file with a floor but no current unidentified elements: floor drops to 0.
  for (const [file, floor] of Object.entries(floors)) {
    if (counts[file] === undefined) {
      const allowed = allowedFloor(floor);
      if (allowed > 0) improved = true;
      nextFloors[file] = 0;
    }
  }

  if (regressions.length > 0 && mode === "sealed") {
    const detail = regressions
      .map(({ file, allowed, count }) => `${file}: ${count} unidentified (floor ${allowed})`)
      .join("; ");
    throw new Error(
      `coverage regression: ${detail}. Add stable ids instead of raising the floor; `
      + "raising is a deliberate hand edit to the ratchet file carrying a `raised: {by, why}` note.",
    );
  }

  const totalUnidentified = Object.values(counts).reduce((total, count) => total + count, 0);
  const warnings = [];
  let verdict = "ok";
  if (regressions.length > 0) {
    verdict = "in_progress";
    warnings.push(
      `adoption still has ${regressions.reduce((total, entry) => total + Math.max(entry.count - entry.allowed, 0), 0)} `
      + "new or increased unidentified candidate(s). They remain unresolved; the committed floor was not raised.",
    );
  } else if (improved) {
    verdict = "improved";
  } else if (totalUnidentified > 0 && Object.keys(floors).length > 0) {
    verdict = "stagnant";
    warnings.push(
      `no identities added: ${totalUnidentified} interactive elements remain unidentified. `
      + "The floor holds, but it only ever holds; it does not improve on its own.",
    );
  }

  return {
    verdict,
    warnings,
    regressions,
    nextRatchet: {
      schema: RATCHET_SCHEMA,
      predicateVersion: DETECTION_PREDICATE_VERSION,
      floors: nextFloors,
      interactionSites: [...currentSites].sort(),
    },
  };
}

/** Deliberate re-baseline under the current predicate. Its own reviewed change. */
export function rebaseline(registry) {
  return {
    schema: RATCHET_SCHEMA,
    predicateVersion: DETECTION_PREDICATE_VERSION,
    floors: perFileCounts(registry),
    interactionSites: [...new Set(registry?.interactionFingerprint?.sites ?? [])].sort(),
  };
}
