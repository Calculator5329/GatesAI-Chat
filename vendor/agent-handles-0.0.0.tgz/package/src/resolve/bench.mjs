// Benchmark: hand-written English for Fathom steps whose handles we already
// know. Scores handle and action accuracy, records truth rows into the reflex
// ledger, and prints accuracy at each confidence threshold (the policy input).
//   node src/resolve/bench.mjs --registry ../../finance/fathom/app/testid-registry.json \
//        --bench test/fixtures/resolve/fathom-bench.json [--ledger path] [--cap 0.05] [--dry-run]
// The reflex kit is loaded from REFLEX_KIT (default: the local-ai-lab lab).
import { readFileSync } from "node:fs";
import { homedir } from "node:os";
import path from "node:path";
import { resolveStep, controlsFromRegistry, NO_MATCH } from "./index.mjs";

export function scoreBench(results) {
  const scored = results.filter((r) => !r.error);
  const want = (r) => (r.expected.testId === NO_MATCH ? null : r.expected.testId);
  const handleRight = scored.filter((r) => r.step.testId === want(r)).length;
  const actionRight = scored.filter((r) => r.step.action === r.expected.action).length;
  const full = scored.filter((r) => r.step.testId === want(r) && r.step.action === r.expected.action && (r.expected.value === undefined || r.step.value === r.expected.value) && (r.expected.predicate === undefined || r.step.predicate === r.expected.predicate) && (r.expected.key === undefined || r.step.key === r.expected.key)).length;
  return { n: scored.length, errors: results.length - scored.length, handleAccuracy: scored.length ? handleRight / scored.length : null, actionAccuracy: scored.length ? actionRight / scored.length : null, fullStepAccuracy: scored.length ? full / scored.length : null };
}

export async function runBench({ registry, bench, ask, ledger = null }) {
  const known = new Set([...controlsFromRegistry(registry).map((c) => c.id), NO_MATCH]);
  const cases = bench.filter((c) => known.has(c.expected.testId));
  const results = [];
  for (const c of cases) {
    try {
      const { step, confidence, receipt, ledgerIds } = await resolveStep({ instruction: c.instruction, registry, ask, area: c.area });
      if (ledger && ledgerIds) {
        ledger.recordTruth(ledgerIds.handle, c.expected.testId, "fathom-bench");
        ledger.recordTruth(ledgerIds.action, c.expected.action, "fathom-bench");
        if (c.expected.predicate && ledgerIds.predicate) ledger.recordTruth(ledgerIds.predicate, c.expected.predicate, "fathom-bench");
      }
      results.push({ instruction: c.instruction, expected: c.expected, step, confidence, alternatives: receipt.alternatives });
    } catch (error) {
      results.push({ instruction: c.instruction, expected: c.expected, error: error.message });
    }
  }
  return { skipped: bench.length - cases.length, results, score: scoreBench(results) };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const args = Object.fromEntries(process.argv.slice(2).map((a, i, all) => (a.startsWith("--") ? [a.slice(2), all[i + 1]?.startsWith("--") || all[i + 1] === undefined ? true : all[i + 1]] : [])).filter((x) => x.length));
  const registry = JSON.parse(readFileSync(args.registry, "utf8"));
  const bench = JSON.parse(readFileSync(args.bench, "utf8"));
  const kitPath = process.env.REFLEX_KIT ?? path.join(homedir(), "projects/ai/local-ai-lab/labs/reflex/src/index.mjs");
  const kit = await import(kitPath);
  const known = new Set([...controlsFromRegistry(registry).map((c) => c.id), NO_MATCH]);
  const usable = bench.filter((c) => known.has(c.expected.testId)).length;
  const tokens = usable * kit.estimateTokens({ instruction: "x".repeat(60), controls: controlsFromRegistry(registry) }) + usable * 400;
  console.log(`${usable}/${bench.length} bench cases have their handle in the registry; ~${tokens} tokens, ~$${kit.usd(tokens).toFixed(4)}`);
  if (args["dry-run"]) process.exit(0);
  const ledger = kit.openLedger(args.ledger ?? path.join(homedir(), ".cache/reflex/resolve-bench", `${new Date().toISOString().slice(0, 19).replace(/[:T]/gu, "-")}.jsonl`));
  const reflex = kit.createReflex({ ledger, budget: kit.budget({ capUsd: Number(args.cap ?? 0.05) }) });
  const out = await runBench({ registry, bench, ask: reflex.ask, ledger });
  console.log(JSON.stringify(out.score));
  for (const r of out.results) if (r.error || r.step.testId !== (r.expected.testId === NO_MATCH ? null : r.expected.testId)) console.log(`  ${r.error ? "ERR " : "MISS"} ${JSON.stringify(r.instruction)} -> ${r.error ?? `${r.step.testId} (${r.confidence.toFixed(2)}) expected ${r.expected.testId}`}`);
  const cal = kit.byQuestion(ledger.joined());
  for (const q of ["handle", "action"]) {
    console.log(`${q}: accuracy ${(cal[q].reliability.accuracy * 100).toFixed(1)}% n=${cal[q].reliability.n} ECE ${cal[q].reliability.ece.toFixed(3)}`);
    for (const t of cal[q].thresholds) console.log(`  conf>=${t.threshold}: coverage ${(t.coverage * 100).toFixed(0)}% accuracy ${t.accuracy === null ? "n/a" : (t.accuracy * 100).toFixed(1) + "%"} (n=${t.n})`);
  }
  console.log(`ledger: ${ledger.path}`);
}
