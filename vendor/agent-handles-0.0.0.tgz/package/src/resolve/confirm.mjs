// Confirm surfaces for the 0.6 to 0.9 band. `driveInstruction` asks a confirm
// hook with the instruction, the proposal, its confidence and the ranked
// alternatives, and expects back a step to run (the proposal or a corrected
// one), null to reject, or undefined to leave it unexecuted. Two surfaces:
//
//   flagConfirm({ yes, pick })  answers from the command line, for an agent
//                               that already knows what it wants
//   promptConfirm({ input, output })  one question on a terminal, for a person
//
// Both carry the context a decision needs (what was said, what was proposed,
// how sure, what else it could be), because a bare "y/n" is a quiz.

/** Answer the confirm band from flags. `pick` names a registry id to run instead of the proposal; `yes` runs the proposal as is. */
export function flagConfirm({ yes = false, pick = null } = {}) {
  if (typeof pick === "string" && pick.trim()) {
    const testId = pick.trim();
    return async () => ({ testId });
  }
  if (yes) return async (proposal) => ({ testId: proposal.step.testId });
  return undefined;
}

/** Render the proposal the way both surfaces show it: instruction, step, confidence, numbered alternatives. */
export function renderProposal({ instruction, step, confidence, alternatives = [] }) {
  const lines = [
    `confirm?  "${instruction}"`,
    `  proposed: ${step.action} ${step.testId}${step.value !== undefined ? ` ${JSON.stringify(step.value)}` : ""}${step.key ? ` ${step.key}` : ""}${step.predicate ? ` ${step.predicate}` : ""}  (confidence ${Number(confidence).toFixed(2)})`,
  ];
  alternatives.forEach((alt, index) => {
    const mark = alt.id === step.testId ? "*" : " ";
    lines.push(`  ${mark} [${index + 1}] ${Number(alt.p).toFixed(2)}  ${alt.id}`);
  });
  lines.push("  Enter or y runs the proposal, a number runs that alternative, n rejects, anything else leaves it.");
  return lines.join("\n");
}

/** Turn one typed line into a confirm answer against the proposal it answers. */
export function parseConfirmAnswer(line, proposal) {
  const text = String(line ?? "").trim().toLowerCase();
  if (text === "" || text === "y" || text === "yes") return { testId: proposal.step.testId };
  if (text === "n" || text === "no") return null;
  if (/^\d+$/u.test(text)) {
    const alt = proposal.alternatives?.[Number(text) - 1];
    return alt ? { testId: alt.id } : undefined;
  }
  return undefined;
}

/** A confirm hook that prints the proposal to `output` and reads one line from `input`. EOF leaves the step unexecuted. */
export function promptConfirm({ input, output }) {
  return async (proposal) => {
    output.write(`${renderProposal(proposal)}\n> `);
    const line = await readLine(input);
    if (line === null) { output.write("\n"); return undefined; }
    return parseConfirmAnswer(line, proposal);
  };
}

function readLine(input) {
  return new Promise((resolve) => {
    let buffer = "";
    const done = (value) => { cleanup(); resolve(value); };
    const onData = (chunk) => {
      buffer += String(chunk);
      const newline = buffer.indexOf("\n");
      if (newline !== -1) done(buffer.slice(0, newline));
    };
    const onEnd = () => done(buffer.length ? buffer : null);
    const cleanup = () => { input.off("data", onData); input.off("end", onEnd); if (typeof input.pause === "function") input.pause(); };
    input.on("data", onData);
    input.on("end", onEnd);
    if (typeof input.resume === "function") input.resume();
  });
}
