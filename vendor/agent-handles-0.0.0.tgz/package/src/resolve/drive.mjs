// resolve behind the drive: English in, a drive receipt out, with the cut
// measured on the Fathom bench between them. `driveInstruction` resolves,
// decides act / confirm / escalate, executes only on act (or on a confirmed
// proposal), and feeds what the drive actually did back into the reflex
// ledger as a truth row. The drive receipt is the ground truth; the model's
// confidence is only the gate.
import { resolveStep, NO_MATCH } from "./index.mjs";
import { DRIVE_PREFIX } from "../drive/index.mjs";

/**
 * The cut, as data with provenance. Numbers come from the live Fathom bench
 * (58 cases, 2026-09-18): 100% handle accuracy at confidence >= 0.9 with 72
 * to 74% coverage, every miss below 0.6. A different registry earns a
 * different cut; re-run `src/resolve/bench.mjs` and replace this record.
 */
export const DRIVE_CUT = Object.freeze({ act: 0.9, confirm: 0.6, derivedFrom: "test/fixtures/resolve/fathom-bench.json, live 2026-09-18, ledgers ~/.cache/reflex/resolve-bench/" });

/** act | confirm | escalate for one resolution. A no-match proposal always escalates: there is nothing to act on or confirm. */
export function cutDecision({ step, confidence }, policy = DRIVE_CUT) {
  if (!(policy.act > policy.confirm)) throw new Error("drive cut needs act > confirm");
  if (!step || step.testId === null) return "escalate";
  if (confidence >= policy.act) return "act";
  if (confidence >= policy.confirm) return "confirm";
  return "escalate";
}

/**
 * Truth from what happened. A receipt that says ok confirms the handle and
 * the action. A refused receipt says the handle was wrong without saying
 * which was right, so the truth row is `not:<id>`: it counts as a miss in
 * calibration (the answer never equals it) and names what was rejected.
 * A confirmed or corrected step from a person or agent is truth outright.
 */
export function recordDriveTruth(ledger, ledgerIds, { step, executed, receipt, correction, source }) {
  if (!ledger || !ledgerIds) return [];
  const rows = [];
  const put = (id, truth) => { if (id) { ledger.recordTruth(id, truth, source); rows.push({ answerId: id, truth, source }); } };
  if (correction) {
    put(ledgerIds.handle, correction.testId ?? NO_MATCH);
    if (correction.action) put(ledgerIds.action, correction.action);
    if (correction.predicate) put(ledgerIds.predicate, correction.predicate);
    return rows;
  }
  if (!executed || !receipt) return rows;
  if (receipt.ok) {
    put(ledgerIds.handle, step.testId);
    put(ledgerIds.action, step.action);
    if (step.action === "expect" && step.predicate) put(ledgerIds.predicate, step.predicate);
  } else {
    put(ledgerIds.handle, `not:${step.testId}`);
  }
  return rows;
}

/**
 * Drive one English instruction.
 * @param {object} input
 * @param {string} input.instruction
 * @param {object|Array} input.registry
 * @param {Function} input.ask reflex-shaped ask
 * @param {(step: object) => Promise<object>} input.execute runs a drive command, returns the drive receipt ({ok, detail, ...}); see httpExecutor
 * @param {(proposal: object) => Promise<object|null|undefined>} [input.confirm] asked in the confirm band: return a step to run (the proposal or a corrected one), null to reject, undefined to leave it unexecuted
 * @param {object} [input.policy] the cut; defaults to DRIVE_CUT
 * @param {string} [input.area]
 * @param {object} [input.ledger] reflex ledger for truth rows
 * @returns {Promise<{decision: string, executed: boolean, step: object, confidence: number, receipt: object|null, resolution: object, truth: object[]}>}
 */
export async function driveInstruction({ instruction, registry, ask, execute, confirm, policy = DRIVE_CUT, area, ledger = null }) {
  if (typeof execute !== "function") throw new Error("driveInstruction needs an execute function (see httpExecutor)");
  const resolved = await resolveStep({ instruction, registry, ask, area });
  const decision = cutDecision(resolved, policy);
  const out = { decision, executed: false, step: resolved.step, confidence: resolved.confidence, receipt: null, resolution: resolved.receipt, alternatives: resolved.receipt.alternatives, truth: [] };
  if (decision === "act") {
    out.receipt = await execute(resolved.step);
    out.executed = true;
    out.truth = recordDriveTruth(ledger, resolved.ledgerIds, { step: resolved.step, executed: true, receipt: out.receipt, source: "drive-receipt" });
    return out;
  }
  if (decision === "confirm" && typeof confirm === "function") {
    const answer = await confirm({ instruction, step: resolved.step, confidence: resolved.confidence, alternatives: resolved.receipt.alternatives });
    if (answer === null) {
      out.decision = "rejected";
      out.truth = recordDriveTruth(ledger, resolved.ledgerIds, { correction: { testId: null }, source: "confirm" });
      return out;
    }
    if (answer && typeof answer === "object") {
      const step = { ...resolved.step, ...answer };
      const corrected = step.testId !== resolved.step.testId || step.action !== resolved.step.action;
      out.step = step;
      out.receipt = await execute(step);
      out.executed = true;
      out.decision = corrected ? "corrected" : "confirmed";
      out.truth = corrected
        ? recordDriveTruth(ledger, resolved.ledgerIds, { correction: step, source: "confirm" })
        : recordDriveTruth(ledger, resolved.ledgerIds, { step, executed: true, receipt: out.receipt, source: "confirm" });
    }
  }
  return out;
}

/** An execute function over the drive middleware: opens one session lazily, posts each step as a command, returns the receipt. */
export function httpExecutor({ baseUrl, paceMs = 0, fetchImpl = fetch }) {
  const origin = String(baseUrl).replace(/\/$/u, "");
  let token = null;
  const post = async (route, body) => {
    const response = await fetchImpl(`${origin}${DRIVE_PREFIX}${route}`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    return { status: response.status, body: await response.json().catch(() => ({})) };
  };
  const execute = async (step) => {
    if (!token) {
      const opened = await post("/session", { paceMs });
      if (opened.status !== 201) throw new Error(`could not open a drive session at ${origin} (HTTP ${opened.status})`);
      token = opened.body.token;
    }
    const { status, body } = await post("/command", { token, command: step });
    if (status === 401 || status === 400) throw new Error(`drive refused the command (HTTP ${status}): ${body.error ?? body.detail ?? ""}`);
    return body;
  };
  execute.session = () => token;
  return execute;
}
