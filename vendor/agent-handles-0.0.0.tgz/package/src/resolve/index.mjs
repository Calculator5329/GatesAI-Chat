// resolve: an English step in, a registry identity out, with confidence and a
// receipt. The judgment is a Choice over the registry's ids answered by a
// System One model (TypeSafe Jev) through an injected `ask` function, so this
// module never talks to the network itself and tests run on a fake. Values
// and keys are extracted in code (the model does not generate text); the
// model only chooses: which handle, which action, which predicate.
//
// Scope wall: resolve returns a proposal step. Executing it is the drive's
// job, and the drive receipt is the ground truth the caller feeds back.

const ACTIONS = {
  click: "press or tap the control",
  fill: "replace the control's text with a value",
  type: "type characters into the control one by one",
  press: "press a keyboard key while the control is focused",
  hover: "move the pointer over the control without clicking",
  expect: "check something about the control without touching it",
};
const PREDICATES = {
  visible: "the control is showing",
  enabled: "the control can be used",
  disabled: "the control cannot be used",
  "contains-text": "the control's text includes a given phrase",
  checked: "the toggle or box is on",
  unchecked: "the toggle or box is off",
};
const KEYS = ["Enter", "Escape", "Tab", "Backspace", "Delete", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space"];
export const MAX_CHOICE = 255;
/** The no-match option every handle Choice carries (TypeSafe guidance: include a no-match outcome when nothing may fit). */
export const NO_MATCH = "none-of-these";

/** Registry entries -> compact control list for the model: id plus its grammar parts. */
export function controlsFromRegistry(registry, { area } = {}) {
  const entries = Array.isArray(registry) ? registry : registry?.entries ?? [];
  return entries
    .map((e) => (typeof e === "string" ? e : e.id))
    .filter((id) => typeof id === "string" && (!area || id.startsWith(`${area}.`)))
    .map((id) => {
      const [a, component, ...rest] = id.split(".");
      return { id, area: a, component, element: rest.join(".") };
    });
}

/** Pull the literal value a fill/type/contains-text step needs. Quotes first, then a number, then a ticker-like token, then the word after "type"/"typing". */
export function extractValue(instruction) {
  const quoted = instruction.match(/["“']([^"”']+)["”']/u);
  if (quoted) return quoted[1];
  const number = instruction.match(/(?<![\w.])(\d[\d,.]*)(?![\w.])/u);
  if (number) return number[1].replace(/,/gu, "");
  const ticker = instruction.match(/\b([A-Z]{2,5})\b/u);
  if (ticker) return ticker[1];
  const afterType = instruction.match(/\b(?:typ(?:e|ing)|enter(?:ing)?)\s+(\S+)/iu);
  if (afterType && !/^(in|into|the|a|an)$/iu.test(afterType[1])) return afterType[1];
  return null;
}

/** The phrase an "expect ... contains-text" step is looking for: quoted, or the word after says/shows/reads/displays. */
export function extractPhrase(instruction) {
  const quoted = instruction.match(/["“']([^"”']+)["”']/u);
  if (quoted) return quoted[1];
  const after = instruction.match(/\b(?:says|shows|reads|displays|showing)\s+([A-Za-z0-9]+)/u);
  return after ? after[1] : extractValue(instruction);
}

export function extractKey(instruction) {
  const lower = instruction.toLowerCase();
  for (const key of KEYS) if (new RegExp(`\\b${key.toLowerCase()}\\b`, "u").test(lower)) return key;
  return null;
}

/**
 * Resolve one English instruction against a registry.
 * @param {object} input
 * @param {string} input.instruction  what the person or agent wants done
 * @param {object|Array} input.registry  agent-handles registry (or a list of ids)
 * @param {(state: unknown, questions: object, opts?: object) => Promise<{answers: object, requestId?: string|null, ids?: object|null}>} input.ask  reflex-style ask
 * @param {string} [input.area]  restrict the candidate ids to one grammar area
 * @returns {Promise<{step: object, confidence: number, receipt: object, ledgerIds: object|null}>}
 */
export async function resolveStep({ instruction, registry, ask, area }) {
  if (typeof instruction !== "string" || !instruction.trim()) throw new Error("resolve needs a non-empty instruction");
  if (typeof ask !== "function") throw new Error("resolve needs an ask function (see reflex)");
  const controls = controlsFromRegistry(registry, { area });
  if (controls.length < 2) throw new Error(`resolve needs at least two candidate controls (got ${controls.length}${area ? ` in area ${area}` : ""})`);
  if (controls.length + 1 > MAX_CHOICE) throw new Error(`resolve: ${controls.length} candidate controls plus the no-match option exceed the ${MAX_CHOICE}-option limit; pass an area to narrow them`);

  const state = { instruction, controls };
  const questions = {
    handle: { type: "choice", instructions: "Which control id does the instruction refer to? Ids read area.component.element. Answer none-of-these when no listed control fits the instruction.", criteria: { ...Object.fromEntries(controls.map((c) => [c.id, null])), [NO_MATCH]: "no listed control matches the instruction" } },
    action: { type: "choice", instructions: "Which kind of step is the instruction asking for?", criteria: ACTIONS },
    predicate: { type: "choice", instructions: "If the instruction is a check rather than an action, what is being checked? Answer visible when it is not a check.", criteria: PREDICATES },
  };
  const { answers, requestId = null, ids = null } = await ask(state, questions, { stateRef: `resolve:${digest(instruction)}`, tag: "resolve", meta: { area: area ?? null, candidates: controls.length } });

  const step = { action: answers.action.choice, testId: answers.handle.choice === NO_MATCH ? null : answers.handle.choice };
  if (step.testId === null) {
    // No proposal: the caller gets the alternatives and the confidence in "nothing fits", never a forced pick.
  } else if (step.action === "expect") {
    step.predicate = answers.predicate.choice;
    if (step.predicate === "contains-text") step.value = extractPhrase(instruction);
  } else if (step.action === "fill" || step.action === "type") {
    step.value = extractValue(instruction);
  } else if (step.action === "press") {
    step.key = extractKey(instruction) ?? "Enter";
  }

  const ranked = Object.entries(answers.handle.probabilities ?? {}).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([id, p]) => ({ id, p }));
  const receipt = { kind: "resolve", instruction, step, confidence: answers.handle.confidence, actionConfidence: answers.action.confidence, alternatives: ranked, candidates: controls.length, area: area ?? null, requestId };
  return { step, confidence: answers.handle.confidence, receipt, ledgerIds: ids };
}

function digest(text) {
  let h = 0;
  for (const ch of text) h = (h * 31 + ch.codePointAt(0)) >>> 0;
  return h.toString(16);
}

export { ACTIONS, PREDICATES };
