import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { createHash, randomUUID } from 'node:crypto';

export const RUN_CONTEXT_ENV = 'AGENT_HANDLES_OBSERVATION_RUN';
export const digest = (bytes) => createHash('sha256').update(bytes).digest('hex');
const schema = 'agent-handles/observation-run/v1';

export async function createObservationRun({ manifest, registryText, artifactRoot = path.join(os.homedir(), '.cache', 'tmp', 'agent-handles-runs') }) {
  await fs.mkdir(artifactRoot, { recursive: true });
  const directory = await fs.mkdtemp(path.join(artifactRoot, 'run-'));
  const run = { schema, directory: await fs.realpath(directory), runId: randomUUID(),
    manifestDigest: digest(JSON.stringify(manifest)), registryDigest: digest(registryText) };
  await fs.writeFile(path.join(directory, 'run.json'), JSON.stringify(run, null, 2) + '\n', { flag: 'wx' });
  return run;
}

function assertContext(value, run) {
  for (const field of ['schema', 'runId', 'manifestDigest', 'registryDigest']) {
    if (typeof run[field] !== 'string' || value[field] !== run[field]) throw new Error(`observation run ${field} mismatch`);
  }
  if (run.schema !== schema) throw new Error('unsupported observation run schema');
}

async function regularFile(directory, relative) {
  if (typeof relative !== 'string' || !relative || relative.includes('\\') || path.isAbsolute(relative)
    || relative.split('/').some(part => !part || part === '.' || part === '..')) throw new Error('invalid observation artifact relative path');
  const pieces = relative.split('/');
  let candidate = directory;
  for (const [index, piece] of pieces.entries()) {
    candidate = path.join(candidate, piece);
    const stat = await fs.lstat(candidate);
    if (stat.isSymbolicLink() || (index < pieces.length - 1 ? !stat.isDirectory() : !stat.isFile())) {
      throw new Error('observation artifact must be a regular contained file');
    }
  }
  return fs.readFile(candidate);
}

function validateRuntime(receipt) {
  if (receipt.schema !== 'agent-handles/runtime-journey-observation/v1' || typeof receipt.journeyName !== 'string'
    || !Number.isInteger(receipt.lastStep) || receipt.lastStep < 1) throw new Error('invalid runtime observation receipt');
  for (const field of ['observedTestIds', 'unidentified', 'unknownTestIds', 'duplicateTestIds']) {
    if (!Array.isArray(receipt[field])) throw new Error(`invalid runtime observation ${field}`);
  }
  if (![...receipt.observedTestIds, ...receipt.duplicateTestIds].every(id => typeof id === 'string')
    || ![...receipt.unidentified, ...receipt.unknownTestIds].every(item => item && typeof item === 'object' && !Array.isArray(item))) {
    throw new Error('invalid runtime observation controls');
  }
}

/** Read only this explicitly selected run. Timestamps never establish provenance. */
export async function readObservationRun(run) {
  if (!run || typeof run.directory !== 'string' || !path.isAbsolute(run.directory)) throw new Error('missing observation run directory');
  const real = await fs.realpath(run.directory);
  if (real !== run.directory || (await fs.lstat(real)).isSymbolicLink()) throw new Error('observation run directory must be canonical');
  const context = JSON.parse(await regularFile(real, 'run.json'));
  assertContext(context, run);
  if (context.directory !== real) throw new Error('observation run directory mismatch');
  const runtime = [], visual = [], artifacts = [], identities = new Set();
  const entries = await fs.readdir(real, { withFileTypes: true });
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
    if (entry.name === 'run.json') continue;
    if (!entry.isDirectory() || !/^[a-f0-9]{64}$/.test(entry.name)) throw new Error('unexpected observation run entry');
    const receiptPath = `${entry.name}/receipt.json`;
    const receiptBytes = await regularFile(real, receiptPath);
    const envelope = JSON.parse(receiptBytes);
    assertContext(envelope.run, run);
    const identity = envelope.identity;
    if (!identity || typeof identity.testId !== 'string' || typeof identity.project !== 'string'
      || !Number.isInteger(identity.retry) || identity.retry < 0 || !Number.isInteger(identity.repeatEachIndex) || identity.repeatEachIndex < 0
      || typeof envelope.journeyName !== 'string') throw new Error('invalid observation attempt identity');
    const key = digest(JSON.stringify(identity));
    if (key !== entry.name || identities.has(key)) throw new Error('duplicate or mismatched observation attempt identity');
    identities.add(key);
    if (!['passed', 'failed', 'timedOut', 'skipped', 'interrupted'].includes(envelope.status)) throw new Error('invalid observation test status');
    if (!envelope.files || typeof envelope.files !== 'object' || Array.isArray(envelope.files)) throw new Error('invalid observation artifact index');
    artifacts.push({ path: receiptPath, sha256: digest(receiptBytes), identity, status: envelope.status });
    const contents = {};
    for (const [kind, file] of Object.entries(envelope.files)) {
      const expected = { runtime: 'runtime.json', visual: 'visual.json', screenshot: 'final.png' }[kind];
      if (!expected || file?.path !== `${entry.name}/${expected}` || !/^[a-f0-9]{64}$/.test(file.sha256)) throw new Error('invalid observation artifact reference');
      const bytes = await regularFile(real, file.path);
      if (digest(bytes) !== file.sha256) throw new Error('observation artifact hash mismatch');
      contents[kind] = kind === 'screenshot' ? bytes : JSON.parse(bytes);
      artifacts.push({ path: file.path, sha256: file.sha256 });
    }
    if (!contents.runtime || (envelope.status === 'passed' && (!contents.visual || !contents.screenshot))
      || Boolean(contents.visual) !== Boolean(contents.screenshot)) throw new Error('incomplete observation test evidence');
    const expectedFiles = ['receipt.json', ...Object.values(envelope.files).map(file => path.basename(file.path))].sort();
    const actualFiles = (await fs.readdir(path.join(real, entry.name))).sort();
    if (JSON.stringify(actualFiles) !== JSON.stringify(expectedFiles)) throw new Error('unindexed observation artifact');
    if (contents.runtime) {
      validateRuntime(contents.runtime);
      if (contents.runtime.journeyName !== envelope.journeyName) throw new Error('observation journey mismatch');
      runtime.push({ ...contents.runtime, identity, status: envelope.status, evidenceFile: envelope.files.runtime.path });
    }
    if (contents.visual) {
      const record = contents.visual;
      if (record.schema !== 'agent-handles/page-state-review/v1' || record.evidenceKind !== 'compiled-journey-final'
        || record.journeyName !== envelope.journeyName || !contents.screenshot || record.screenshot !== envelope.files.screenshot.path
        || !record.issues || !['unidentified', 'unknown', 'duplicate', 'reviewRequired'].every(field => Number.isInteger(record.issues[field]) && record.issues[field] >= 0)) {
        throw new Error('invalid compiled final-page evidence');
      }
      visual.push({ ...record, artifactDirectory: run.directory, identity, status: envelope.status, receiptPath: envelope.files.visual.path });
    }
  }
  // Preserve Playwright's existing retry contract: select the last attempt by
  // numeric retry identity, retaining every attempt's bytes and hashes above.
  const latest = new Map();
  for (const artifact of artifacts.filter(item => item.identity)) {
    const { retry, ...identity } = artifact.identity;
    const key = JSON.stringify(identity);
    latest.set(key, Math.max(latest.get(key) ?? -1, retry));
  }
  const isLatest = item => {
    const { retry, ...identity } = item.identity;
    return latest.get(JSON.stringify(identity)) === retry;
  };
  return { run, runtime: runtime.filter(isLatest), visual: visual.filter(isLatest), artifacts };
}

// Rendered into standalone specs: no new installed runtime dependency for adopters.
export function renderArtifactWriter() {
  return String.raw`
const observationRunText = process.env.AGENT_HANDLES_OBSERVATION_RUN;
const observationRun = observationRunText ? JSON.parse(observationRunText) : null;
const manifestDigest = __AGENT_HANDLES_MANIFEST_DIGEST__;
const sha256 = (bytes: string | Buffer) => createHash("sha256").update(bytes).digest("hex");
const artifactIdentity = (testInfo: import("@playwright/test").TestInfo) => ({
  testId: testInfo.testId, project: testInfo.project.name, retry: testInfo.retry, repeatEachIndex: testInfo.repeatEachIndex,
});
function artifactDirectory(testInfo: import("@playwright/test").TestInfo) {
  const key = sha256(JSON.stringify(artifactIdentity(testInfo)));
  if (!observationRun) return testInfo.outputPath("agent-handles", key);
  if (observationRun.schema !== "agent-handles/observation-run/v1" || !path.isAbsolute(observationRun.directory)
    || typeof observationRun.runId !== "string" || observationRun.manifestDigest !== manifestDigest) {
    throw new Error("invalid or mismatched observation run context; regenerate journey spec");
  }
  return path.join(observationRun.directory, key);
}
const pendingVisualReceipts = new Map<string, object>();
test.afterEach(async ({ page: _page }, testInfo) => {
  const runtime = pendingRuntimeReceipts.get(testInfo.testId) as { journeyName: string } | undefined;
  if (!runtime) return;
  const directory = artifactDirectory(testInfo);
  await fs.mkdir(directory, { recursive: true });
  const identity = artifactIdentity(testInfo);
  const key = sha256(JSON.stringify(identity));
  const files: Record<string, { path: string; sha256: string }> = {};
  const save = async (kind: string, name: string, bytes: string | Buffer, contentType: string) => {
    await fs.writeFile(path.join(directory, name), bytes, { flag: "wx" });
    files[kind] = { path: key + "/" + name, sha256: sha256(bytes) };
    await testInfo.attach("agent-handles-" + kind, { path: path.join(directory, name), contentType });
  };
  await save("runtime", "runtime.json", JSON.stringify(runtime, null, 2) + "\n", "application/json");
  const visual = pendingVisualReceipts.get(testInfo.testId);
  if (visual) {
    const screenshot = await fs.readFile(path.join(directory, "final.png"));
    files.screenshot = { path: key + "/final.png", sha256: sha256(screenshot) };
    await testInfo.attach("agent-handles-screenshot", { path: path.join(directory, "final.png"), contentType: "image/png" });
    await save("visual", "visual.json", JSON.stringify(visual, null, 2) + "\n", "application/json");
  }
  const registryDigest = sha256(await fs.readFile(runtimeRegistryPath));
  if (observationRun && observationRun.registryDigest !== registryDigest) throw new Error("observation registry digest mismatch");
  const envelope = { run: observationRun ?? { schema: "agent-handles/observation-run/v1", runId: "playwright-artifact", manifestDigest, registryDigest },
    identity, journeyName: runtime.journeyName, status: testInfo.status, files };
  await fs.writeFile(path.join(directory, "receipt.json"), JSON.stringify(envelope, null, 2) + "\n", { flag: "wx" });
  await testInfo.attach("agent-handles-receipt", { path: path.join(directory, "receipt.json"), contentType: "application/json" });
  pendingRuntimeReceipts.delete(testInfo.testId);
  pendingVisualReceipts.delete(testInfo.testId);
  runtimeObserved.delete(testInfo.testId);
});
`;
}
