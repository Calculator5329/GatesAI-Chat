// One runtime-control predicate feeds the live observer, visual overlay, and
// compiled Playwright reconciler. Keep the selector and eligibility rules in
// one source so a design-system exception cannot make those surfaces disagree.
export const RUNTIME_INTERACTIVE_SELECTOR = [
  "button",
  "input",
  "select",
  "textarea",
  "a[href]",
  "summary",
  "[contenteditable]:not([contenteditable='false'])",
  "[role='button']",
  "[role='checkbox']",
  "[role='combobox']",
  "[role='link']",
  "[role='menuitem']",
  "[role='menuitemcheckbox']",
  "[role='menuitemradio']",
  "[role='option']",
  "[role='radio']",
  "[role='slider']",
  "[role='spinbutton']",
  "[role='switch']",
  "[role='tab']",
  "[role='textbox']",
  "[role='treeitem']",
  "[tabindex]:not([tabindex='-1'])",
].join(",");

// Dev-mode devtools mount their own buttons into the app's document, and the
// reconciler counted them as the app's unidentified controls. Found 2026-09-04
// on shadcn-admin: the TanStack Router and TanStack Query devtools toggles made
// every journey stop at "3 visible interactive control(s) had no data-testid",
// and adoption only got through by running the dev server and the Playwright
// `webServer.command` with `--mode production`.
//
// This list is deliberately not per-project configurable. The live observer and
// the compiled Playwright reconciler render from this one constant, and an
// app-supplied list would reach only whichever surface loaded the config —
// which is exactly how the two disagree. An app whose devtools are not listed
// marks their root with `data-agent-handles-devtools` instead; that attribute
// works identically on both surfaces.
export const RUNTIME_DEVTOOLS_ROOT_SELECTOR = [
  "[data-agent-handles-devtools]",
  // TanStack Router devtools: panel shell and the floating toggle.
  "[class*='TanStackRouterDevtools']",
  "[id*='TanStackRouterDevtools']",
  "[id*='tanstack-router-devtools']",
  // TanStack Query devtools v5 (tsqd-*) and v4 (ReactQueryDevtools).
  "[class*='tsqd-']",
  "[class*='ReactQueryDevtools']",
  "[id*='react-query-devtools']",
  // Vite's own dev overlays are custom elements in the app document.
  "vite-error-overlay",
  "vite-plugin-checker-error-overlay",
].join(",");

const RUNTIME_CONTAINER_ROLE_SELECTOR = [
  "tablist",
  "tabpanel",
  "toolbar",
  "group",
  "region",
  "list",
  "listitem",
  "menubar",
  "presentation",
  "none",
];

/**
 * Render the browser-side eligibility helper for either JavaScript (the Vite
 * executor) or TypeScript (generated Playwright). `aria-hidden=true` is the
 * semantic boundary: Base UI focus guards and form mirrors are accessibility
 * plumbing, while merely offscreen/transparent controls still fail closed.
 * Dev-only devtools roots are excluded outright: they are not the app.
 */
export function renderRuntimeObservationPredicate({ typescript = false } = {}) {
  const parameter = typescript ? "element: Element" : "element";
  const declare = (name, value) => (typescript
    ? `const ${name} =\n  ${JSON.stringify(value)};`
    : `const ${name} = ${JSON.stringify(value)};`);
  return [
    declare("RUNTIME_INTERACTIVE_SELECTOR", RUNTIME_INTERACTIVE_SELECTOR),
    declare("RUNTIME_DEVTOOLS_ROOT_SELECTOR", RUNTIME_DEVTOOLS_ROOT_SELECTOR),
    declare("RUNTIME_CONTAINER_ROLE_SELECTOR", RUNTIME_CONTAINER_ROLE_SELECTOR),
    `function isRuntimeObservationCandidate(${parameter}) {`,
    `  if (element.closest("[data-agent-handles-overlay]")) return false;`,
    `  if (element.closest(RUNTIME_DEVTOOLS_ROOT_SELECTOR)) return false;`,
    `  if (element.closest('[aria-hidden="true"]')) return false;`,
    `  const role = element.getAttribute?.("role") ?? "";`,
    `  const nativeControl = element.matches?.('button,input,select,textarea,a[href],summary,[contenteditable]:not([contenteditable="false"])');`,
    `  if (RUNTIME_CONTAINER_ROLE_SELECTOR.includes(role) && !nativeControl) return false;`,
    `  const style = window.getComputedStyle(element);`,
    `  const rect = element.getBoundingClientRect();`,
    `  return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;`,
    `}`,
  ].join("\n");
}

/**
 * Render the browser-side actionability check that the live drive protocol was
 * missing. Found 2026-09-04 on shadcn-admin: `journeys run` reported
 * `ok click settings.appearance-form.theme-dark` while the compiled spec failed
 * the same step with Playwright's "subtree intercepts pointer events", because
 * the live executor dispatches a synthetic click on the located node and never
 * asks whether a user's pointer would have reached it.
 *
 * `runtimeActionabilityIssue` answers null when the element is actionable and a
 * human-readable reason otherwise, using Playwright's own rule: the hit target
 * at the element's centre must be the element or one of its descendants.
 * Rendered separately from the observation predicate so the generated
 * Playwright spec — which has Playwright's real actionability — does not carry
 * an unused helper into a consumer's lint.
 */
export function renderRuntimeActionabilityPredicate({ typescript = false } = {}) {
  const parameter = typescript ? "element: Element" : "element";
  return [
    `function runtimeActionabilityIssue(${parameter}) {`,
    `  const rect = element.getBoundingClientRect();`,
    `  if (rect.width <= 0 || rect.height <= 0) return "element has no layout box";`,
    `  const style = window.getComputedStyle(element);`,
    `  if (style.display === "none" || style.visibility === "hidden") return "element is not displayed";`,
    `  if (style.pointerEvents === "none") return "element has pointer-events: none";`,
    `  if (element.hasAttribute("disabled") || element.getAttribute("aria-disabled") === "true") return "element is disabled";`,
    `  const x = rect.left + rect.width / 2;`,
    `  const y = rect.top + rect.height / 2;`,
    `  if (x < 0 || y < 0 || x > window.innerWidth || y > window.innerHeight) return "element centre is outside the viewport";`,
    `  const hit = document.elementFromPoint(x, y);`,
    `  if (!hit) return "nothing is hit-testable at the element centre";`,
    `  if (hit === element || element.contains(hit)) return null;`,
    `  const tag = hit.tagName.toLowerCase();`,
    `  const testId = hit.getAttribute("data-testid");`,
    `  return "subtree intercepts pointer events: <" + tag + (testId ? " data-testid=" + JSON.stringify(testId) : "") + ">";`,
    `}`,
  ].join("\n");
}
