// One runtime-control predicate feeds the live observer, visual overlay, and
// compiled Playwright reconciler. Keep the selector and eligibility rules in
// one source so a design-system exception cannot make those surfaces disagree.
export const RUNTIME_INTERACTIVE_SELECTOR = [
  "button",
  "input",
  "select",
  "textarea",
  "a[href]",
  "summary",
  "[contenteditable]:not([contenteditable='false'])",
  "[role='button']",
  "[role='checkbox']",
  "[role='combobox']",
  "[role='link']",
  "[role='menuitem']",
  "[role='menuitemcheckbox']",
  "[role='menuitemradio']",
  "[role='option']",
  "[role='radio']",
  "[role='slider']",
  "[role='spinbutton']",
  "[role='switch']",
  "[role='tab']",
  "[role='textbox']",
  "[role='treeitem']",
  "[tabindex]:not([tabindex='-1'])",
].join(",");

/**
 * Render the browser-side eligibility helper for either JavaScript (the Vite
 * executor) or TypeScript (generated Playwright). `aria-hidden=true` is the
 * semantic boundary: Base UI focus guards and form mirrors are accessibility
 * plumbing, while merely offscreen/transparent controls still fail closed.
 */
export function renderRuntimeObservationPredicate({ typescript = false } = {}) {
  const parameter = typescript ? "element: Element" : "element";
  const selectorDeclaration = typescript
    ? `const RUNTIME_INTERACTIVE_SELECTOR =\n  ${JSON.stringify(RUNTIME_INTERACTIVE_SELECTOR)};`
    : `const RUNTIME_INTERACTIVE_SELECTOR = ${JSON.stringify(RUNTIME_INTERACTIVE_SELECTOR)};`;
  return [
    selectorDeclaration,
    `function isRuntimeObservationCandidate(${parameter}) {`,
    `  if (element.closest("[data-agent-handles-overlay]")) return false;`,
    `  if (element.closest('[aria-hidden="true"]')) return false;`,
    `  const role = element.getAttribute?.("role");`,
    `  const nativeControl = element.matches?.('button,input,select,textarea,a[href],summary,[contenteditable]:not([contenteditable="false"])');`,
    `  if ((role === "tablist" || role === "tabpanel") && !nativeControl) return false;`,
    `  const style = window.getComputedStyle(element);`,
    `  const rect = element.getBoundingClientRect();`,
    `  return style.display !== "none" && style.visibility !== "hidden" && rect.width > 0 && rect.height > 0;`,
    `}`,
  ].join("\n");
}
