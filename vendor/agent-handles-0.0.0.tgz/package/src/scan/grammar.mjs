// The identity grammar: area.component.element[.qualifier], kebab-case
// segments, three or more. Lifted from forge-shell testid-registry.mjs:19;
// stays mergeable against its origin (see CLAUDE.md, ported files).
export const TEST_ID_GRAMMAR = /^[a-z][a-z0-9-]*(?:\.[a-z][a-z0-9-]*){2,}$/u;

export function declaresTestId(name) {
  return name === "data-testid" || name === "testId" || name.endsWith("TestId");
}

export function validateStableId(value, location) {
  if (!TEST_ID_GRAMMAR.test(value)) {
    // Without the location this refusal named only the id, so a reader had to grep
    // for it across the app to act on it.
    throw new Error(
      `Invalid stable test id ${JSON.stringify(value)}${location ? ` at ${location}` : ""};`
      + " expected area.component.element with kebab-case segments.",
    );
  }
  return value;
}
