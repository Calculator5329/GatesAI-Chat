// Filesystem entry points around the pure scan/registry modules, plus the
// public re-exports for the ./scanner subpath.
import fs from "node:fs/promises";
import path from "node:path";
import { createRegistry, DEFAULT_CONFIG } from "./registry.mjs";
import { isRegistrySource } from "./scanner.mjs";

export { TEST_ID_GRAMMAR, declaresTestId, validateStableId } from "./grammar.mjs";
export {
  scanTsxText,
  isRegistrySource,
  INTERACTIVE_TAGS,
  INTERACTIVE_ROLES,
  DEFAULT_INTERACTIVE_COMPONENTS,
} from "./scanner.mjs";
export {
  createRegistry,
  manifestTestIds,
  DEFAULT_CONFIG,
  extendInteractiveComponents,
} from "./registry.mjs";

function posix(relativePath) {
  return relativePath.split(path.sep).join("/");
}

export const SOURCE_DIRECTORY_EXCLUSIONS = new Set(["node_modules", ".git", ".yarn", ".agent-handles", ".explorer", ".next", ".cache", "dist", "build", "coverage"]);

export async function sourceFiles(root) {
  const out = [];
  const walk = async (directory) => {
    const entries = await fs.readdir(directory, { withFileTypes: true });
    for (const entry of entries) {
      const absolute = path.join(directory, entry.name);
      if (entry.isDirectory() && !SOURCE_DIRECTORY_EXCLUSIONS.has(entry.name)) await walk(absolute);
      else if (entry.isFile() && isRegistrySource(entry.name)) out.push(absolute);
    }
  };
  const roots = Array.isArray(root) ? root : [root];
  if (!roots.length || roots.some((entry) => typeof entry !== "string" || !entry.trim())) throw new Error("sourceRoots must be a non-empty array of directory paths");
  for (const directory of roots) await walk(directory);
  return [...new Set(out)].sort();
}

async function readJson(file, fallback) {
  try { return JSON.parse(await fs.readFile(file, "utf8")); }
  catch (error) {
    if (error?.code === "ENOENT") return fallback;
    throw error;
  }
}

/**
 * Render a project's registry JSON (with trailing newline).
 * Paths are explicit: nothing here assumes forge-shell's layout.
 *
 * @param {object} options
 * @param {string} options.appRoot      registry-relative paths are relative to this
 * @param {string} options.sourceRoot   directory walked for .tsx sources
 * @param {string} options.registryPath previous registry (ratchet input), may not exist
 * @param {string} options.journeyManifestPath journeys manifest, may not exist
 * @param {object} [options.config]     schema names; DEFAULT_CONFIG when absent
 */
export async function renderRegistry({ appRoot, sourceRoot, sourceRoots, registryPath, journeyManifestPath, config = DEFAULT_CONFIG, previousRegistry: previousOverride }) {
  const files = await sourceFiles(sourceRoots ?? sourceRoot);
  const sources = await Promise.all(files.map(async (absolute) => ({
    file: posix(path.relative(appRoot, absolute)),
    text: await fs.readFile(absolute, "utf8"),
  })));
  // previousRegistry: the record the identity-history check compares against.
  // The committed file by default; the dev-server sync passes the file as it
  // stood at server start, so a half-typed id it wrote mid-session never
  // counts as a stable identity that later "disappeared".
  const [journeyManifest, previousRegistry] = await Promise.all([
    readJson(journeyManifestPath, { schema: config.journeyManifestSchemas[0], journeys: [] }),
    previousOverride === undefined ? readJson(registryPath, undefined) : previousOverride,
  ]);
  return `${JSON.stringify(createRegistry({ sources, journeyManifest, previousRegistry, config }), null, 2)}\n`;
}
