// Registry assembly, lifted from forge-shell testid-registry.mjs with every
// forge-shell constant turned into config so the origin registry regenerates
// byte-identically (the S2 acceptance gate) while new adopters get
// agent-handles/* schema names by default.
import { createHash } from "node:crypto";
import { scanTsxText, DEFAULT_INTERACTIVE_COMPONENTS } from "./scanner.mjs";
import { validateStableId } from "./grammar.mjs";
import { journeyKind } from "../journeys/index.mjs";

export const DEFAULT_CONFIG = {
  registrySchema: "agent-handles/testid-registry/v3",
  journeyManifestSchemas: ["agent-handles/journey/v1"],
  grammarLabel: "area.component.element[.qualifier]",
  generatedFrom: "src/**/*.{tsx,jsx} and journeys/manifest.json",
  interactiveComponents: DEFAULT_INTERACTIVE_COMPONENTS,
  controlJudgments: {},
  identityRenames: {},
  identityTombstones: {},
};

// agent-handles.json names only the wrappers peculiar to an adopter. Keep
// the learned defaults and append those names; replacing the defaults makes
// adding one wrapper hide every Button, Input, and NavLink from the scanner.
// An explicit low-level `config.interactiveComponents` still remains a full
// override for callers preserving predicate-v1 or another pinned contract.
export function extendInteractiveComponents(config, additions) {
  if (!Array.isArray(additions)) return config;
  return {
    ...config,
    interactiveComponents: [
      ...new Set([...(config.interactiveComponents ?? []), ...additions]),
    ],
  };
}

// forge-shell/journey-manifest/v1 step shape is byte-for-byte the package's
// journey step shape (ruled 2026-08-22); only the manifest namespace differs.
export function manifestTestIds(manifest, config = DEFAULT_CONFIG) {
  const accepted = config.journeyManifestSchemas;
  if (!accepted.includes(manifest?.schema) || !Array.isArray(manifest.journeys)) {
    throw new Error(
      `journeys manifest must use one of [${accepted.join(", ")}] with a journeys array.`,
    );
  }
  return [...new Set(manifest.journeys.flatMap((journey) => (
    Array.isArray(journey?.steps)
      ? journey.steps.map((step) => step?.testId).filter((value) => typeof value === "string")
      : []
  )))].sort();
}

function normalizedRenameTargets(value) {
  if (typeof value === "string") return [value];
  if (typeof value?.target === "string") return [value.target];
  return Array.isArray(value?.targets) ? value.targets : [];
}

function validateIdentityAddress(value, location) {
  if (typeof value !== "string") throw new Error(`${location} must be a string identity or identity pattern.`);
  return value.endsWith("*")
    ? validateStableId(`${value.slice(0, -1)}dynamic`, location)
    : validateStableId(value, location);
}

function identityHistory({ previousRegistry, entries, patterns, invalidIdentities, config }) {
  const currentIds = new Set([
    ...entries.map(({ id }) => id),
    ...patterns.map(({ pattern }) => pattern),
  ]);
  const currentLegacyIds = new Set(invalidIdentities.map(({ id }) => id));
  const renames = Object.entries(config.identityRenames ?? {}).map(([from, declaration]) => {
    const targets = normalizedRenameTargets(declaration);
    return {
      from,
      ...(targets.length === 1 ? { to: targets[0] } : { targets }),
      ...(typeof declaration === "object" && declaration?.reason && { reason: declaration.reason }),
    };
  });
  const tombstones = Object.entries(config.identityTombstones ?? {}).map(([id, declaration]) => ({
    id,
    removedAt: declaration?.removedAt,
    reason: declaration?.reason,
  }));
  const renamedFrom = new Set(renames.map(({ from }) => from));
  const tombstoned = new Set(tombstones.map(({ id }) => id));
  const renameTargets = new Set();
  for (const rename of renames) {
    const targets = rename.to ? [rename.to] : rename.targets;
    if (!Array.isArray(targets) || targets.length === 0) throw new Error(`identity rename ${JSON.stringify(rename.from)} must declare target or targets.`);
    if (tombstoned.has(rename.from)) throw new Error(`identity ${JSON.stringify(rename.from)} cannot be both renamed and tombstoned.`);
    for (const target of targets) {
      validateIdentityAddress(target, `identityRenames.${rename.from}`);
      if (rename.from === target) throw new Error(`identity rename ${JSON.stringify(rename.from)} cannot target itself.`);
      if (renamedFrom.has(target)) throw new Error(`identity rename chains are not allowed: ${rename.from} -> ${target}. Declare the final target directly.`);
      if (renameTargets.has(target)) throw new Error(`multiple identities cannot rename to the same target ${JSON.stringify(target)}.`);
      renameTargets.add(target);
    }
  }
  for (const tombstone of tombstones) {
    if (typeof tombstone.reason !== "string" || tombstone.reason.trim().length === 0) {
      throw new Error(`identity tombstone ${JSON.stringify(tombstone.id)} must include a non-empty reason.`);
    }
  }

  if (previousRegistry?.schema === config.registrySchema) {
    const previousIds = new Set([
      ...(previousRegistry.entries ?? []).map(({ id }) => id),
      ...(previousRegistry.patterns ?? []).map(({ pattern }) => pattern),
      ...(previousRegistry.invalidIdentities ?? []).map(({ id }) => id),
    ]);
    const historicalIds = new Set([
      ...(previousRegistry.identityHistory?.renames ?? []).map(({ from }) => from),
      ...(previousRegistry.identityHistory?.tombstones ?? []).map(({ id }) => id),
    ]);
    const removed = [...previousIds].filter((id) => !currentIds.has(id) && !currentLegacyIds.has(id)).sort();
    const unexplained = removed.filter((id) => !renamedFrom.has(id) && !tombstoned.has(id));
    if (unexplained.length > 0) {
      throw new Error(
        `stable identities disappeared without a declared rename or tombstone: ${unexplained.join(", ")}.`,
      );
    }
    for (const rename of renames) {
      const targets = rename.to ? [rename.to] : rename.targets;
      if (!previousIds.has(rename.from) && !historicalIds.has(rename.from)) {
        throw new Error(`identity rename source ${JSON.stringify(rename.from)} was not present in prior registry history.`);
      }
      if (currentIds.has(rename.from) || currentLegacyIds.has(rename.from)) {
        throw new Error(`renamed identity ${JSON.stringify(rename.from)} is still declared in source.`);
      }
      for (const target of targets) {
        if (!currentIds.has(target)) {
          throw new Error(`identity rename target ${JSON.stringify(target)} is not declared in current source.`);
        }
      }
    }
    for (const tombstone of tombstones) {
      if (!previousIds.has(tombstone.id) && !historicalIds.has(tombstone.id)) {
        throw new Error(`identity tombstone ${JSON.stringify(tombstone.id)} was not present in prior registry history.`);
      }
      if (currentIds.has(tombstone.id) || currentLegacyIds.has(tombstone.id)) {
        throw new Error(`tombstoned identity ${JSON.stringify(tombstone.id)} is still declared in source.`);
      }
    }
  }
  return { renames, tombstones };
}

export function createRegistry({ sources, journeyManifest, previousRegistry, config = DEFAULT_CONFIG }) {
  const candidateMode = config.registrySchema === "agent-handles/testid-registry/v3";
  const scans = sources.map(({ file, text }) => scanTsxText(file, text, {
    interactiveComponents: config.interactiveComponents,
    candidateMode,
  }));
  const entries = scans.flatMap((scan) => scan.declared)
    .sort((left, right) => left.id.localeCompare(right.id) || left.file.localeCompare(right.file) || left.line - right.line);
  const duplicateIds = entries
    .filter((entry, index) => index > 0 && entry.id === entries[index - 1].id)
    .map((entry) => entry.id);
  if (duplicateIds.length > 0) {
    throw new Error(`Stable test ids must be source-unique; duplicates: ${[...new Set(duplicateIds)].join(", ")}`);
  }
  const invalidIdentities = scans.flatMap((scan) => scan.invalidIdentities ?? [])
    .sort((left, right) => left.file.localeCompare(right.file) || left.line - right.line || left.id.localeCompare(right.id));
  // Candidate-mode registries: dynamic testids register their families as patterns, and a
  // journey may reference any id a pattern covers (that is how a recorded
  // session touching list rows becomes a committable journey).
  const v2 = config.interactiveComponents !== undefined;
  const patterns = v2
    ? [...new Map(scans.flatMap((scan) => scan.declaredPatterns ?? [])
        .map((entry) => [entry.pattern, entry])).values()]
        .sort((left, right) => left.pattern.localeCompare(right.pattern))
    : [];
  const coveredByPattern = (id) => patterns.some(({ pattern }) => id.startsWith(pattern.slice(0, -1)));
  const known = new Set(entries.map((entry) => entry.id));
  const history = candidateMode
    ? identityHistory({ previousRegistry, entries, patterns, invalidIdentities, config })
    : { renames: [], tombstones: [] };
  const renamedTarget = (id) => {
    const exact = history.renames.find(({ from }) => from === id);
    if (exact) return exact.to ? [exact.to] : exact.targets;
    const patterned = history.renames.find(({ from }) => from.endsWith("*") && id.startsWith(from.slice(0, -1)));
    if (!patterned) return undefined;
    return (patterned.to ? [patterned.to] : patterned.targets).map((target) => target.endsWith("*")
      ? `${target.slice(0, -1)}${id.slice(patterned.from.length - 1)}`
      : target);
  };
  const isTombstoned = (id) => history.tombstones.some(({ id: removed }) =>
    removed === id || (removed.endsWith("*") && id.startsWith(removed.slice(0, -1))));
  const journeyReferences = manifestTestIds(journeyManifest, config);
  const missingJourneyIds = journeyReferences.filter((id) => !known.has(id) && !coveredByPattern(id));
  if (missingJourneyIds.length > 0) {
    const detail = missingJourneyIds.map((id) => renamedTarget(id)
      ? renamedTarget(id).length === 1
        ? `${id} (renamed to ${renamedTarget(id)[0]})`
        : `${id} (split into ${renamedTarget(id).join(" | ")})`
      : isTombstoned(id)
        ? `${id} (removed; tombstone recorded)`
        : id);
    throw new Error(`Journey manifest references unregistered test ids: ${detail.join(", ")}`);
  }

  const unidentifiedInteractive = scans.flatMap((scan) => scan.unidentifiedInteractive)
    .sort((left, right) => left.file.localeCompare(right.file) || left.line - right.line);
  // Origin-compat guard, v1-mode only. In v2 mode (a component list is
  // configured) a predicate change legitimately raises the count during
  // regeneration; the real down-only enforcement is the ratchet module,
  // which refuses cross-predicate floors and requires a deliberate
  // rebaseline.
  const priorMaximum = Number(previousRegistry?.coverage?.maximumUnidentifiedInteractive);
  if (config.interactiveComponents === undefined
    && Number.isFinite(priorMaximum) && unidentifiedInteractive.length > priorMaximum) {
    throw new Error(
      `Unidentified interactive controls increased from ${priorMaximum} to ${unidentifiedInteractive.length}; `
      + "add a stable data-testid instead of raising the ratchet.",
    );
  }
  const interactiveElements = scans.reduce((total, scan) => total + scan.interactiveElements, 0);
  const identifiedInteractive = scans.reduce((total, scan) => total + scan.identifiedInteractive, 0);
  const sourceDigest = createHash("sha256");
  for (const source of sources) sourceDigest.update(`${source.file}\0${source.text}\0`);

  const journeys = (journeyManifest.journeys ?? []).map((journey) => journeyKind(journey));
  if (candidateMode) {
    const candidates = scans.flatMap((scan) => scan.candidates ?? [])
      .sort((left, right) => left.file.localeCompare(right.file) || left.line - right.line);
    if (sources.length === 0 || candidates.length === 0) {
      throw new Error(
        sources.length === 0
          ? "unsupported adoption scan: no .tsx or .jsx source files were found; refusing a green 0/0 registry."
          : "unsupported adoption scan: source files were found but no control candidates were detected; refusing a green 0/0 registry.",
      );
    }
    const judgments = config.controlJudgments ?? {};
    const resolvedCandidates = candidates.map((candidate) => {
      const judgment = judgments[candidate.id];
      const proposed = judgment?.classification;
      const validDisposition = proposed === "non-interactive" || proposed === "unreachable";
      const ownerDecision = judgment?.ownerDecision;
      const ownerApproved = validDisposition && ownerDecision?.selectedOption === proposed;
      const disposition = candidate.identified
        ? "identified"
        : ownerApproved
          ? proposed
          : "unresolved";
      return {
        ...candidate,
        disposition,
        ...(validDisposition && {
          judgment: {
            classification: proposed,
            judgment: judgment.judgment,
            evidence: Array.isArray(judgment.evidence) ? judgment.evidence : [],
            options: Array.isArray(judgment.options) ? judgment.options : [],
            proposal: judgment.proposal,
            ...(ownerDecision && { ownerDecision }),
          },
        }),
      };
    });
    const unresolvedCandidates = resolvedCandidates.filter((candidate) => candidate.disposition === "unresolved");
    const siteIds = resolvedCandidates.map((candidate) => candidate.id).sort();
    const fingerprint = createHash("sha256").update(siteIds.join("\n")).digest("hex");
    const count = (classification) => resolvedCandidates.filter((candidate) => candidate.classification === classification).length;
    const disposed = (disposition) => resolvedCandidates.filter((candidate) => candidate.disposition === disposition).length;
    return {
      schema: config.registrySchema,
      predicateVersion: 4,
      grammar: config.grammarLabel,
      generatedFrom: config.generatedFrom,
      sourceDigest: `sha256:${sourceDigest.digest("hex")}`,
      journeyCoverage: {
        controlPath: journeys.filter((kind) => kind === "control-path").length,
        urlPath: journeys.filter((kind) => kind === "url-path").length,
      },
      coverage: {
        controlCandidates: resolvedCandidates.length,
        definiteCandidates: count("definite"),
        reviewRequiredCandidates: count("review-required"),
        identifiedCandidates: disposed("identified"),
        nonInteractiveCandidates: disposed("non-interactive"),
        unreachableCandidates: disposed("unreachable"),
        unresolvedCandidates: unresolvedCandidates.length,
        invalidIdentityMigrations: invalidIdentities.length,
        // Compatibility aliases for existing dashboards. Their names remain,
        // but the schema and predicateVersion make the changed denominator explicit.
        interactiveElements: resolvedCandidates.length,
        identifiedInteractive: disposed("identified"),
        unidentifiedInteractive: unresolvedCandidates.length,
        maximumUnidentifiedInteractive: unresolvedCandidates.length,
      },
      interactionFingerprint: {
        algorithm: "candidate-site-sha256/v1",
        digest: `sha256:${fingerprint}`,
        sites: siteIds,
      },
      journeyReferences,
      entries,
      patterns,
      invalidIdentities,
      identityHistory: history,
      candidates: resolvedCandidates,
      unresolvedCandidates,
      // Compatibility alias consumed by the v1 ratchet module during migration.
      unidentifiedInteractive: unresolvedCandidates.map(({ file, line, element, id, classification, evidence }) => ({
        file, line, element, candidateId: id, classification, evidence,
      })),
    };
  }
  return {
    schema: config.registrySchema,
    grammar: config.grammarLabel,
    generatedFrom: config.generatedFrom,
    sourceDigest: `sha256:${sourceDigest.digest("hex")}`,
    ...(v2 && {
      journeyCoverage: {
        controlPath: journeys.filter((kind) => kind === "control-path").length,
        urlPath: journeys.filter((kind) => kind === "url-path").length,
      },
    }),
    coverage: {
      interactiveElements,
      identifiedInteractive,
      unidentifiedInteractive: unidentifiedInteractive.length,
      // Origin behavior preserved for byte-identical regeneration: the floor
      // rewrites to the current count. The real down-only ratchet is the
      // ratchet module's job (L5), layered on top of this record.
      maximumUnidentifiedInteractive: unidentifiedInteractive.length,
    },
    journeyReferences,
    entries,
    ...(v2 && { patterns }),
    unidentifiedInteractive,
  };
}
