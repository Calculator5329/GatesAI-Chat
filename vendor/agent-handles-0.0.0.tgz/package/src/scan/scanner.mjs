// TSX scanner over the TypeScript AST. Lifted from forge-shell
// testid-registry.mjs; framework assumptions removed, `typescript` resolved
// from this package's own pinned dependency (forge-shell's TS 7 is a native
// binary with no JS compiler API, which is why the origin resolved it from
// the repo root).
import { createRequire } from "node:module";
import { createHash } from "node:crypto";
import { declaresTestId, validateStableId } from "./grammar.mjs";

const ts = createRequire(import.meta.url)("typescript");

export const INTERACTIVE_TAGS = new Set(["button", "input", "select", "textarea"]);
export const INTERACTIVE_ROLES = new Set([
  "button", "checkbox", "combobox", "link", "menuitem", "menuitemcheckbox",
  "menuitemradio", "option", "radio", "slider", "spinbutton", "switch",
  "tab", "textbox", "treeitem",
]);
const INTERACTION_HANDLERS = new Set([
  "onClick", "onDoubleClick", "onKeyDown", "onKeyUp", "onKeyPress",
  "onPointerDown", "onPointerUp", "onMouseDown", "onMouseUp", "onSubmit",
]);

// Predicate v2 (2026-08-25): component wrappers count too. This is the
// default set — shadcn/radix interactive components plus react-router's
// links, learned the hard way when three live drive sessions found the nav,
// every Button, and the picker's search input invisible to predicate v1.
// Per-app additions go in agent-handles.json `interactiveComponents`; a
// static list can never know a new app's wrappers, which is what the
// LLM identity pass at init is for (roadmap).
export const DEFAULT_INTERACTIVE_COMPONENTS = [
  // Roots that render no DOM of their own (Select, RadioGroup, Tabs) are
  // deliberately absent: the trigger/item is the control a user touches,
  // and counting the root double-counts every dropdown.
  "Button", "Input", "Textarea", "Checkbox", "Switch", "Slider",
  "SelectTrigger", "SelectItem",
  "RadioGroupItem", "Toggle", "ToggleGroupItem", "TabsTrigger",
  "DropdownMenuTrigger", "DropdownMenuItem", "DropdownMenuCheckboxItem", "DropdownMenuRadioItem",
  "PopoverTrigger", "DialogTrigger", "AlertDialogTrigger", "AccordionTrigger",
  "ContextMenuTrigger", "ContextMenuItem", "MenubarTrigger", "MenubarItem",
  "HoverCardTrigger", "CommandInput", "CommandItem",
  "Link", "NavLink",
];

/** The literal string a testid attribute pins, or undefined when it is dynamic. */
function literalAttributeText(initializer) {
  if (initializer === undefined) return undefined;
  if (ts.isStringLiteral(initializer)) return initializer.text;
  if (ts.isJsxExpression(initializer) && initializer.expression !== undefined) {
    const inner = initializer.expression;
    if (ts.isStringLiteral(inner) || ts.isNoSubstitutionTemplateLiteral(inner)) return inner.text;
  }
  return undefined;
}

function attribute(node, name, sourceFile) {
  return node.attributes.properties.find((property) =>
    ts.isJsxAttribute(property) && property.name.getText(sourceFile) === name);
}

function hasAttribute(node, name, sourceFile) {
  return attribute(node, name, sourceFile) !== undefined;
}

function literalAttribute(node, name, sourceFile) {
  return literalAttributeText(attribute(node, name, sourceFile)?.initializer);
}

function candidateId({ file, tag, signature, occurrence }) {
  // Identity attributes are deliberately excluded: adding an id must resolve
  // a candidate, not manufacture a different candidate. The occurrence keeps
  // repeated identical controls in one file distinct without relying on line
  // numbers, which drift under unrelated edits. Interaction attributes are
  // excluded too: adding role/tabIndex must not look like removal plus a new
  // site, while actually removing the interaction still removes the candidate
  // from the measured set and trips the fingerprint gate.
  const digest = createHash("sha256")
    .update(JSON.stringify({ file, tag, signature, occurrence }))
    .digest("hex")
    .slice(0, 16);
  return `candidate:${digest}`;
}

function candidateSignature(node, sourceFile) {
  const ignored = new Set([
    ...INTERACTION_HANDLERS,
    "data-testid", "testId", "role", "tabIndex", "href", "contentEditable",
  ]);
  // Attribute values are intentionally absent. Changing a CSS class, event
  // body, label, role, or id does not create a new source site. Attribute
  // names that describe non-interaction structure remain as a light anchor;
  // repeated identical sites are disambiguated by occurrence below.
  return node.attributes.properties.map((property) => {
    if (ts.isJsxSpreadAttribute(property)) return "...spread";
    const name = property.name.getText(sourceFile);
    if (ignored.has(name) || declaresTestId(name)) return undefined;
    return name;
  }).filter(Boolean).sort().join(",");
}

// A dynamic testid still names an addressable family. A template literal's
// static head becomes a registry pattern (`ui.ticker-picker.option-${t}` ->
// "ui.ticker-picker.option-*"), and plain string literals inside the
// expression (defaults of `??`, ternary branches) are declared ids like any
// other. Patterns with no static head are ignored: an id the source cannot
// name is an id no journey can reference.
function dynamicAttributeIds(initializer) {
  const literals = [];
  const patterns = [];
  if (!(initializer !== undefined && ts.isJsxExpression(initializer) && initializer.expression !== undefined)) {
    return { literals, patterns };
  }
  const walk = (node) => {
    if (ts.isTemplateExpression(node)) {
      if (node.head.text.length > 0) patterns.push(`${node.head.text}*`);
      return; // never collect the literal chunks between substitutions
    }
    if (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) {
      if (node.text.length > 0) literals.push(node.text);
      return;
    }
    ts.forEachChild(node, walk);
  };
  walk(initializer.expression);
  return { literals, patterns };
}

function identityDeclarations(initializer, context, { tolerateInvalid = false, validatePatterns = true } = {}) {
  const literal = literalAttributeText(initializer);
  const dynamic = literal === undefined
    ? dynamicAttributeIds(initializer)
    : { literals: [literal], patterns: [] };
  const validIds = [];
  const validPatterns = [];
  const invalidIdentities = [];
  const validateOrRecord = (value, kind, validationValue = value) => {
    try {
      validateStableId(validationValue, context);
      if (kind === "literal") validIds.push(value);
      else validPatterns.push(value);
    } catch (error) {
      if (!tolerateInvalid) throw error;
      invalidIdentities.push({
        id: value,
        kind,
        reason: error instanceof Error ? error.message : String(error),
      });
    }
  };
  for (const value of dynamic.literals) validateOrRecord(value, "literal");
  for (const pattern of dynamic.patterns) {
    if (validatePatterns) validateOrRecord(pattern, "pattern", `${pattern.slice(0, -1)}dynamic`);
    else validPatterns.push(pattern);
  }
  return { validIds, validPatterns, invalidIdentities };
}

function identityStatus(node, sourceFile, context) {
  const declarations = node.attributes.properties
    .filter((property) => ts.isJsxAttribute(property)
      && declaresTestId(property.name.getText(sourceFile)))
    .map((property) => identityDeclarations(property.initializer, context, { tolerateInvalid: true }));
  return {
    identified: declarations.some(({ validIds, validPatterns }) => validIds.length + validPatterns.length > 0),
    invalidIdentities: declarations.flatMap((declaration) => declaration.invalidIdentities),
  };
}

// Base UI/Radix-style `render={<Button />}` composition gives the wrapper's
// behavior to the rendered child; it does not create a second DOM control.
// Suppress the wrapper only when the render prop visibly contains a child the
// scanner will count on its own. Dynamic render values and non-interactive
// children stay fail-closed: the configured wrapper is still counted.
function hasInteractiveRenderChild(node, interactiveComponents, sourceFile) {
  const render = node.attributes.properties.find((property) =>
    ts.isJsxAttribute(property) && property.name.getText(sourceFile) === "render");
  const expression = render?.initializer && ts.isJsxExpression(render.initializer)
    ? render.initializer.expression
    : undefined;
  const opening = expression && ts.isJsxElement(expression)
    ? expression.openingElement
    : expression && ts.isJsxSelfClosingElement(expression)
      ? expression
      : undefined;
  if (!opening) return false;
  const childTag = opening.tagName.getText(sourceFile);
  return INTERACTIVE_TAGS.has(childTag) || interactiveComponents.has(childTag);
}

// Parsing real TSX makes "attribute" and "element" mean what the compiler
// means; the parser is error-tolerant, so a fragment fixture scans the same
// as a full module.
export function scanTsxText(file, sourceText, options = {}) {
  // v1 semantics (intrinsic tags only) when no component list is given, so
  // the forge-shell byte-identical gate and any pinned config keep meaning
  // what they meant.
  const interactiveComponents = new Set(options.interactiveComponents ?? []);
  const sourceFile = ts.createSourceFile(file, sourceText, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  const declared = [];
  const declaredPatterns = [];
  const unidentifiedInteractive = [];
  const candidates = [];
  const invalidIdentities = [];
  const candidateOccurrences = new Map();
  let interactiveElements = 0;
  let identifiedInteractive = 0;
  const lineOf = (node) =>
    sourceFile.getLineAndCharacterOfPosition(node.getStart(sourceFile)).line + 1;

  const visit = (node) => {
    if (ts.isJsxAttribute(node)) {
      const name = node.name.getText(sourceFile);
      if (declaresTestId(name)) {
        const line = lineOf(node);
        const identity = identityDeclarations(node.initializer, `${file}:${line}`, {
          tolerateInvalid: options.candidateMode === true,
          validatePatterns: options.candidateMode === true,
        });
        for (const id of identity.validIds) {
          declared.push({ id, file, line, element: "jsx-prop", attribute: name });
        }
        for (const pattern of identity.validPatterns) {
          declaredPatterns.push({ pattern, file, line, attribute: name });
        }
        for (const invalid of identity.invalidIdentities) {
          invalidIdentities.push({ ...invalid, file, line, element: "jsx-prop", attribute: name });
        }
      }
    } else if (ts.isJsxOpeningElement(node) || ts.isJsxSelfClosingElement(node)) {
      const tag = node.tagName.getText(sourceFile);
      // An `asChild` wrapper (Radix Slot) renders no DOM node of its own —
      // its child is the control, counted separately, and with Slot's merge
      // the child's own data-testid wins. Counting the wrapper too demands a
      // phantom id no DOM node would ever carry.
      const asChild = node.attributes.properties.some((property) =>
        ts.isJsxAttribute(property) && property.name.getText(sourceFile) === "asChild");
      const composedWrapper = interactiveComponents.has(tag)
        && (asChild || hasInteractiveRenderChild(node, interactiveComponents, sourceFile));
      const nativeDefinite = INTERACTIVE_TAGS.has(tag)
        || (tag === "a" && hasAttribute(node, "href", sourceFile))
        || tag === "summary"
        || hasAttribute(node, "contentEditable", sourceFile);
      const wrapperDefinite = interactiveComponents.has(tag) && !composedWrapper;
      const measuredDefinite = options.candidateMode === true ? nativeDefinite : INTERACTIVE_TAGS.has(tag);
      if ((measuredDefinite || wrapperDefinite) && !composedWrapper) {
        interactiveElements += 1;
        const identified = node.attributes.properties.some((property) =>
          ts.isJsxAttribute(property) && property.name.getText(sourceFile) === "data-testid");
        if (identified) identifiedInteractive += 1;
        else unidentifiedInteractive.push({ file, line: lineOf(node), element: tag });
      }
      if (options.candidateMode === true && !composedWrapper) {
        const role = literalAttribute(node, "role", sourceFile);
        const handlers = node.attributes.properties
          .filter((property) => ts.isJsxAttribute(property)
            && INTERACTION_HANDLERS.has(property.name.getText(sourceFile)))
          .map((property) => property.name.getText(sourceFile))
          .sort();
        const evidence = [];
        let classification;
        if (nativeDefinite) {
          classification = "definite";
          evidence.push(tag === "a" ? "a[href]" : tag === "summary" ? "summary" : hasAttribute(node, "contentEditable", sourceFile) ? "contentEditable" : `native:${tag}`);
        } else if (wrapperDefinite) {
          classification = "definite";
          evidence.push(`configured-wrapper:${tag}`);
        } else {
          if (role && INTERACTIVE_ROLES.has(role)) evidence.push(`role:${role}`);
          if (hasAttribute(node, "tabIndex", sourceFile)) evidence.push("tabIndex");
          evidence.push(...handlers.map((name) => `handler:${name}`));
          if (evidence.length > 0) classification = "review-required";
        }
        if (classification) {
          const identity = identityStatus(node, sourceFile, `${file}:${lineOf(node)}`);
          if (identity.invalidIdentities.length > 0) {
            evidence.push(...identity.invalidIdentities.map(({ id }) => `legacy-id:${id}`));
          }
          const signature = candidateSignature(node, sourceFile);
          const occurrenceKey = JSON.stringify({ tag, signature });
          const occurrence = candidateOccurrences.get(occurrenceKey) ?? 0;
          candidateOccurrences.set(occurrenceKey, occurrence + 1);
          candidates.push({
            id: candidateId({ file, tag, signature, occurrence }),
            file,
            line: lineOf(node),
            element: tag,
            classification,
            evidence,
            identified: identity.identified,
            ...(identity.invalidIdentities.length > 0 && { legacyIdentities: identity.invalidIdentities }),
          });
        }
      }
    }
    ts.forEachChild(node, visit);
  };
  visit(sourceFile);
  return { declared, declaredPatterns, invalidIdentities, interactiveElements, identifiedInteractive, unidentifiedInteractive, candidates };
}

// A test that asserts on a rendered `data-testid="..."` string is not a second
// declaration of that id; scanning `*.test.tsx` inflates both the duplicate
// check and the unidentified-control ratchet.
export function isRegistrySource(file) {
  return (file.endsWith(".tsx") || file.endsWith(".jsx"))
    && !file.endsWith(".test.tsx")
    && !file.endsWith(".test.jsx");
}
