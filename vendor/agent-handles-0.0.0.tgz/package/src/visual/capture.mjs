import { createHash } from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";

export const REVIEW_VISUAL_API_PATH = "/__agent-handles/visual-reviews";
export const DEFAULT_REVIEW_CAPTURE_READY_TIMEOUT_MS = 20_000;

const SAFE_NAME = /[^a-z0-9._-]+/gu;

export const safeName = (value) => String(value)
  .toLowerCase()
  .replace(SAFE_NAME, "-")
  .replace(/^-+|-+$/gu, "")
  .slice(0, 80) || "state";

export function reviewId({ surfaceId, route, label }) {
  if (surfaceId) return safeName(surfaceId);
  const digest = createHash("sha256").update(`${route}\0${label}`).digest("hex").slice(0, 12);
  return `${safeName(label)}-${digest}`;
}

export function isReviewRouteReady(route) {
  const target = String(route ?? "");
  const at = `${location.pathname}${location.search}${location.hash}`;
  return at === target || at.startsWith(target) || location.pathname === target;
}

export function resolveReviewSurface(surface) {
  if (!surface || typeof surface !== "object") {
    throw new Error("adoption.reviewSurfaces entries must be objects.");
  }
  const id = String(surface.id ?? "").trim();
  if (!id) throw new Error("a review surface id is required.");
  const route = String(surface.route ?? "");
  if (!route.startsWith("/")) throw new Error(`review surface ${JSON.stringify(id)} has an invalid route ${JSON.stringify(route)}.`);
  const label = String(surface.label ?? id).trim();
  if (!label) throw new Error(`review surface ${JSON.stringify(id)} has an empty label.`);
  return { ...surface, id, route, label };
}

export function resolveReviewSurfaces(stored, requestedSurfaceId) {
  const declared = Array.isArray(stored?.adoption?.reviewSurfaces) ? stored.adoption.reviewSurfaces : [];
  const normalized = declared.map((surface) => resolveReviewSurface(surface));
  if (requestedSurfaceId === undefined) return normalized;
  const selected = normalized.filter((surface) => surface.id === String(requestedSurfaceId));
  if (selected.length === 0) throw new Error(`no review surface ${JSON.stringify(String(requestedSurfaceId))} in adoption.reviewSurfaces.`);
  return selected;
}

export async function waitForReviewSurfaceReady(page, route, timeoutMs = DEFAULT_REVIEW_CAPTURE_READY_TIMEOUT_MS) {
  await page.waitForFunction(isReviewRouteReady, { timeout: timeoutMs }, String(route));
}

export async function collectReviewState(page) {
  return page.evaluate(() => {
    const elements = [...document.querySelectorAll("[data-testid]")]
      .filter((element) => !element.closest("[data-agent-handles-overlay]"))
      .filter((element) => {
        const rect = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
      });
    const counts = new Map();
    for (const element of elements) {
      const testId = element.getAttribute("data-testid");
      if (testId) counts.set(testId, (counts.get(testId) ?? 0) + 1);
    }
    let duplicate = 0;
    let unidentified = 0;
    let reviewRequired = 0;
    let identified = 0;
    const observedTestIds = new Set();
    for (const element of elements) {
      const testId = element.getAttribute("data-testid");
      if (!testId) {
        const tag = element.tagName.toLowerCase();
        if (["button", "input", "select", "textarea", "summary"].includes(tag)
          || (tag === "a" && element.hasAttribute("href"))
          || (element.hasAttribute("contenteditable") && element.getAttribute("contenteditable") !== "false")) {
          unidentified += 1;
        } else {
          reviewRequired += 1;
        }
      } else if (counts.get(testId) > 1) {
        duplicate += 1;
      } else {
        identified += 1;
      }
      observedTestIds.add(testId);
    }
    return {
      route: location.pathname + location.search,
      title: document.title,
      visibleControls: elements.length,
      identifiedControls: identified,
      issues: {
        unidentified,
        unknown: 0,
        duplicate,
        reviewRequired,
      },
      observedTestIds: [...observedTestIds].filter(Boolean).sort(),
    };
  });
}

export function buildReviewCapturePayload(surface, state, { evidenceKind = "interactive-page-state", screenshot } = {}) {
  return {
    surfaceId: String(surface.id),
    route: String(surface.route),
    label: String(surface.label),
    ...(typeof state.title === "string" ? { title: state.title } : {}),
    ...(Number.isSafeInteger(state.visibleControls) ? { visibleControls: state.visibleControls } : {}),
    ...(Number.isSafeInteger(state.identifiedControls) ? { identifiedControls: state.identifiedControls } : {}),
    issues: {
      unidentified: Number.isSafeInteger(state?.issues?.unidentified) ? state.issues.unidentified : 0,
      unknown: Number.isSafeInteger(state?.issues?.unknown) ? state.issues.unknown : 0,
      duplicate: Number.isSafeInteger(state?.issues?.duplicate) ? state.issues.duplicate : 0,
      reviewRequired: Number.isSafeInteger(state?.issues?.reviewRequired) ? state.issues.reviewRequired : 0,
    },
    observedTestIds: Array.isArray(state.observedTestIds) ? state.observedTestIds : [],
    ...(screenshot ? { screenshot } : {}),
    evidenceKind,
  };
}

export async function postReviewCapture({ baseUrl, body, fetchImpl = fetch }) {
  const response = await fetchImpl(`${baseUrl}${REVIEW_VISUAL_API_PATH}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error ?? `visual review endpoint returned ${response.status}`);
  return payload;
}

export async function captureReviewSurfaces({
  baseUrl,
  page,
  surfaces,
  outDir,
  readReviewState = collectReviewState,
  timeoutMs = DEFAULT_REVIEW_CAPTURE_READY_TIMEOUT_MS,
  postCapture = postReviewCapture,
}) {
  const results = [];
  for (const surface of surfaces) {
    const target = new URL(surface.route, baseUrl).toString();
    await page.goto(target, { waitUntil: "domcontentloaded" });
    await waitForReviewSurfaceReady(page, surface.route, timeoutMs);
    const reviewState = await readReviewState(page);
    let screenshot;
    if (outDir && typeof page.screenshot === "function") {
      await fs.mkdir(outDir, { recursive: true });
      const screenshotName = `${safeName(surface.id)}.png`;
      const screenshotPath = path.join(outDir, screenshotName);
      await page.screenshot({ path: screenshotPath });
      screenshot = path.relative(process.cwd(), screenshotPath).replaceAll("\\", "/");
    }
    const payload = buildReviewCapturePayload(surface, reviewState, { screenshot });
    const record = await postCapture({ baseUrl, body: payload });
    results.push({ surface, payload, record });
  }
  return results;
}
