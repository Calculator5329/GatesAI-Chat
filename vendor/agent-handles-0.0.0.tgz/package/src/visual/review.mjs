import fs from "node:fs/promises";
import path from "node:path";
import { isReviewRouteReady, reviewId as generateReviewId } from "./capture.mjs";

export const VISUAL_REVIEW_SCHEMA = "agent-handles/page-state-review/v1";

const ISSUE_FIELDS = ["unidentified", "unknown", "duplicate", "reviewRequired"];

const isPlainObject = (value) => Boolean(value) && typeof value === "object" && !Array.isArray(value);

const describeValue = (value) => (typeof value === "number" ? String(value) : JSON.stringify(value) ?? typeof value);

// One count contract for producers and readers. A control count is a
// non-negative safe integer or it is absent; nothing is coerced. `Number(x)`
// read "many", `[]` and NaN as zero, and passed -3 and 1.5 straight through
// into a total the reader then called clean.
function assertCount(value, field) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0) {
    throw new Error(`visual review ${field} must be a non-negative integer, received ${describeValue(value)}`);
  }
  return value;
}

// Absent means "this producer records no count here" and is legal input.
// Present-but-not-a-count (including the `null` that JSON leaves behind for
// NaN and Infinity) is refused rather than read as zero.
const optionalCount = (value, field) => (value === undefined ? 0 : assertCount(value, field));

function normalizeIssues(issues = {}) {
  if (!isPlainObject(issues)) throw new Error("visual review issues must be an object of measured counts");
  return Object.fromEntries(ISSUE_FIELDS.map((field) => [field, optionalCount(issues[field], `issues.${field}`)]));
}

/**
 * Validate a receipt this read has already selected, before it is allowed to
 * contribute to a clean verdict. `trustedRunEvidence` marks records handed
 * over by `readObservationRun`, the only source allowed to assert
 * observation-run provenance.
 */
function assertVisualReviewRecord(record, { trustedRunEvidence = false } = {}) {
  if (!isPlainObject(record)) throw new Error("visual review receipt must be an object");
  if (record.schema !== VISUAL_REVIEW_SCHEMA) throw new Error(`expected ${VISUAL_REVIEW_SCHEMA}`);
  if (!trustedRunEvidence && record.artifactDirectory !== undefined) {
    throw new Error("a stored review receipt may not claim observation-run provenance");
  }
  if (!isPlainObject(record.issues)) throw new Error("visual review issues must be an object of measured counts");
  for (const field of ISSUE_FIELDS) optionalCount(record.issues[field], `issues.${field}`);
  const visible = record.visibleControls === undefined ? undefined : assertCount(record.visibleControls, "visibleControls");
  const identified = record.identifiedControls === undefined ? undefined : assertCount(record.identifiedControls, "identifiedControls");
  if (record.measuredAt !== undefined
    && (typeof record.measuredAt !== "string" || !Number.isFinite(Date.parse(record.measuredAt)))) {
    throw new Error("visual review measuredAt must be an ISO-8601 timestamp");
  }
  // The compiled producer partitions one observed control list by presence of
  // a testId, so visible === identified + unidentified holds there. The
  // overlay's statuses are disjoint, so its identifiedControls excludes the
  // unknown and duplicate controls the compiled count includes, and the same
  // sum does not hold for interactive receipts.
  if (record.evidenceKind === "compiled-journey-final" && visible !== undefined && identified !== undefined
    && identified + optionalCount(record.issues.unidentified, "issues.unidentified") !== visible) {
    throw new Error("compiled final-state control counts are inconsistent");
  }
  return record;
}

export function normalizeVisualReview(input, { evidenceKind = "interactive-page-state" } = {}) {
  const route = String(input?.route ?? "");
  const label = String(input?.label ?? "").trim();
  if (!route.startsWith("/")) throw new Error("visual review route must start with /");
  if (!label || label.length > 120) throw new Error("visual review label must contain 1 to 120 characters");
  const issues = normalizeIssues(input.issues === undefined ? {} : input.issues);
  const visibleControls = optionalCount(input.visibleControls, "visibleControls");
  const identifiedControls = optionalCount(input.identifiedControls, "identifiedControls");
  const observedTestIds = [...new Set((input.observedTestIds ?? [])
    .filter((value) => typeof value === "string" && value.length > 0))].sort();
  const id = generateReviewId({ surfaceId: input.surfaceId, route, label });
  return {
    schema: VISUAL_REVIEW_SCHEMA,
    id,
    ...(input.surfaceId ? { surfaceId: String(input.surfaceId) } : {}),
    measuredAt: new Date().toISOString(),
    route,
    label,
    title: String(input.title ?? "").slice(0, 160),
    evidenceKind,
    ...(input.journeyName ? { journeyName: String(input.journeyName) } : {}),
    visibleControls,
    identifiedControls,
    issues,
    observedTestIds,
    ...(input.screenshot ? { screenshot: String(input.screenshot) } : {}),
    statement: `${visibleControls} controls observed in ${label}; this is page/state evidence, and unvisited states remain uncovered.`,
  };
}

export { isReviewRouteReady };

export function evaluateVisualReviewGate(summary, {
  required = false,
  expectedJourneyNames = [],
  expectedSurfaceIds = [],
  minimumJourneyMeasuredAt = 0,
  minimumSurfaceMeasuredAt = 0,
} = {}) {
  if (!required) return { passed: true, required: false, reasons: [] };
  const reasons = [];
  if (summary.invalid.length > 0) reasons.push(`${summary.invalid.length} visual review receipt(s) are invalid.`);
  if (summary.records.length === 0) reasons.push("No page/state review evidence was recorded.");
  if (expectedSurfaceIds.length === 0) reasons.push("No page/state review surfaces are declared in adoption.reviewSurfaces.");
  const issueCount = Object.values(summary.issueTotals).reduce((total, count) => total + count, 0);
  if (issueCount > 0) reasons.push(`${issueCount} visual review issue(s) remain.`);
  const journeyRecords = new Map(summary.records
    .filter((record) => record.evidenceKind === "compiled-journey-final" && record.journeyName)
    .map((record) => [record.journeyName, record]));
  for (const journeyName of expectedJourneyNames) {
    const record = journeyRecords.get(journeyName);
    if (!record) reasons.push(`Journey ${journeyName} has no final page/state review receipt.`);
    else if (!record.screenshot) reasons.push(`Journey ${journeyName} has no durable final-state screenshot.`);
    else if (minimumJourneyMeasuredAt > 0 && !(Date.parse(record.measuredAt) >= minimumJourneyMeasuredAt)) {
      reasons.push(`Journey ${journeyName} has no fresh final-state screenshot from this verification run.`);
    }
  }
  const surfaceRecords = new Map(summary.records
    .filter((record) => record.surfaceId)
    .map((record) => [record.surfaceId, record]));
  for (const surfaceId of expectedSurfaceIds) {
    const record = surfaceRecords.get(surfaceId);
    if (!record) reasons.push(`Declared page/state ${surfaceId} has no review receipt.`);
    else if (minimumSurfaceMeasuredAt > 0 && !(Date.parse(record.measuredAt) >= minimumSurfaceMeasuredAt)) {
      reasons.push(`Declared page/state ${surfaceId} has no current review receipt from this adoption pass.`);
    }
  }
  return { passed: reasons.length === 0, required: true, reasons };
}

export async function writeVisualReview(appRoot, input, options) {
  const review = normalizeVisualReview(input, options);
  const directory = path.join(appRoot, ".agent-handles", "visual-reviews");
  const file = path.join(directory, `${review.id}.json`);
  const temporary = `${file}.${process.pid}.tmp`;
  await fs.mkdir(directory, { recursive: true });
  await fs.writeFile(temporary, `${JSON.stringify(review, null, 2)}\n`);
  await fs.rename(temporary, file);
  return { ...review, receiptPath: path.relative(appRoot, file).replaceAll("\\", "/") };
}

export async function readVisualReviews(appRoot, { since = 0, compiledRun } = {}) {
  const directory = path.join(appRoot, ".agent-handles", "visual-reviews");
  const names = await fs.readdir(directory).catch((error) => {
    if (error?.code === "ENOENT") return [];
    throw error;
  });
  const records = [];
  const invalid = [];
  for (const name of names.filter((candidate) => candidate.endsWith(".json")).sort()) {
    const file = path.join(directory, name);
    try {
      const record = JSON.parse(await fs.readFile(file, "utf8"));
      if (record?.schema !== VISUAL_REVIEW_SCHEMA) throw new Error(`expected ${VISUAL_REVIEW_SCHEMA}`);
      // Selection stays ahead of semantics. A stored compiled receipt is
      // obsolete once an explicit run is supplied, and undated evidence cannot
      // prove it is from this window (the old `NaN < since` kept it in every
      // window). Neither is this read's evidence, so neither may fail it.
      if (since > 0 && !(Date.parse(record.measuredAt) >= since)) continue;
      if (compiledRun && record.evidenceKind === "compiled-journey-final") continue;
      records.push({ ...assertVisualReviewRecord(record), receiptPath: path.relative(appRoot, file).replaceAll("\\", "/") });
    } catch (error) {
      invalid.push({ file: path.relative(appRoot, file).replaceAll("\\", "/"), error: error.message });
    }
  }
  for (const record of compiledRun?.visual ?? []) {
    try {
      records.push(assertVisualReviewRecord(record, { trustedRunEvidence: true }));
    } catch (error) {
      invalid.push({ file: record?.receiptPath ?? "(observation run)", error: error.message });
    }
  }
  const issueTotals = records.reduce((totals, record) => {
    for (const key of ISSUE_FIELDS) totals[key] += record.issues[key] ?? 0;
    return totals;
  }, { unidentified: 0, unknown: 0, duplicate: 0, reviewRequired: 0 });
  return {
    schema: "agent-handles/page-state-review-summary/v1",
    records,
    invalid,
    pageStatesReviewed: records.length,
    routesReviewed: [...new Set(records.map((record) => record.route))].sort(),
    screenshots: records.filter((record) => record.screenshot).length,
    issueTotals,
    clean: invalid.length === 0 && Object.values(issueTotals).every((count) => count === 0),
    statement: `${records.length} page/state review receipt(s) across ${new Set(records.map((record) => record.route)).size} route(s); unvisited routes and states remain uncovered.`,
  };
}
