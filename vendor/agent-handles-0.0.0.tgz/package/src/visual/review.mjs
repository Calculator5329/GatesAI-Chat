import { createHash } from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";

export const VISUAL_REVIEW_SCHEMA = "agent-handles/page-state-review/v1";

const safeName = (value) => String(value)
  .toLowerCase()
  .replace(/[^a-z0-9._-]+/gu, "-")
  .replace(/^-+|-+$/gu, "")
  .slice(0, 80) || "state";

function reviewId({ surfaceId, route, label }) {
  if (surfaceId) return safeName(surfaceId);
  const digest = createHash("sha256").update(`${route}\0${label}`).digest("hex").slice(0, 12);
  return `${safeName(label)}-${digest}`;
}

function normalizeIssues(issues = {}) {
  return {
    unidentified: Math.max(0, Number(issues.unidentified) || 0),
    unknown: Math.max(0, Number(issues.unknown) || 0),
    duplicate: Math.max(0, Number(issues.duplicate) || 0),
    reviewRequired: Math.max(0, Number(issues.reviewRequired) || 0),
  };
}

export function normalizeVisualReview(input, { evidenceKind = "interactive-page-state" } = {}) {
  const route = String(input?.route ?? "");
  const label = String(input?.label ?? "").trim();
  if (!route.startsWith("/")) throw new Error("visual review route must start with /");
  if (!label || label.length > 120) throw new Error("visual review label must contain 1 to 120 characters");
  const issues = normalizeIssues(input.issues);
  const observedTestIds = [...new Set((input.observedTestIds ?? [])
    .filter((value) => typeof value === "string" && value.length > 0))].sort();
  const id = reviewId({ surfaceId: input.surfaceId, route, label });
  return {
    schema: VISUAL_REVIEW_SCHEMA,
    id,
    ...(input.surfaceId ? { surfaceId: String(input.surfaceId) } : {}),
    measuredAt: new Date().toISOString(),
    route,
    label,
    title: String(input.title ?? "").slice(0, 160),
    evidenceKind,
    ...(input.journeyName ? { journeyName: String(input.journeyName) } : {}),
    visibleControls: Math.max(0, Number(input.visibleControls) || 0),
    identifiedControls: Math.max(0, Number(input.identifiedControls) || 0),
    issues,
    observedTestIds,
    ...(input.screenshot ? { screenshot: String(input.screenshot) } : {}),
    statement: `${Math.max(0, Number(input.visibleControls) || 0)} controls observed in ${label}; this is page/state evidence, and unvisited states remain uncovered.`,
  };
}

export function evaluateVisualReviewGate(summary, {
  required = false,
  expectedJourneyNames = [],
  expectedSurfaceIds = [],
  minimumJourneyMeasuredAt = 0,
  minimumSurfaceMeasuredAt = 0,
} = {}) {
  if (!required) return { passed: true, required: false, reasons: [] };
  const reasons = [];
  if (summary.invalid.length > 0) reasons.push(`${summary.invalid.length} visual review receipt(s) are invalid.`);
  if (summary.records.length === 0) reasons.push("No page/state review evidence was recorded.");
  if (expectedSurfaceIds.length === 0) reasons.push("No page/state review surfaces are declared in adoption.reviewSurfaces.");
  const issueCount = Object.values(summary.issueTotals).reduce((total, count) => total + count, 0);
  if (issueCount > 0) reasons.push(`${issueCount} visual review issue(s) remain.`);
  const journeyRecords = new Map(summary.records
    .filter((record) => record.evidenceKind === "compiled-journey-final" && record.journeyName)
    .map((record) => [record.journeyName, record]));
  for (const journeyName of expectedJourneyNames) {
    const record = journeyRecords.get(journeyName);
    if (!record) reasons.push(`Journey ${journeyName} has no final page/state review receipt.`);
    else if (!record.screenshot) reasons.push(`Journey ${journeyName} has no durable final-state screenshot.`);
    else if (minimumJourneyMeasuredAt > 0 && Date.parse(record.measuredAt) < minimumJourneyMeasuredAt) {
      reasons.push(`Journey ${journeyName} has no fresh final-state screenshot from this verification run.`);
    }
  }
  const surfaceRecords = new Map(summary.records
    .filter((record) => record.surfaceId)
    .map((record) => [record.surfaceId, record]));
  for (const surfaceId of expectedSurfaceIds) {
    const record = surfaceRecords.get(surfaceId);
    if (!record) reasons.push(`Declared page/state ${surfaceId} has no review receipt.`);
    else if (minimumSurfaceMeasuredAt > 0 && Date.parse(record.measuredAt) < minimumSurfaceMeasuredAt) {
      reasons.push(`Declared page/state ${surfaceId} has no current review receipt from this adoption pass.`);
    }
  }
  return { passed: reasons.length === 0, required: true, reasons };
}

export async function writeVisualReview(appRoot, input, options) {
  const review = normalizeVisualReview(input, options);
  const directory = path.join(appRoot, ".agent-handles", "visual-reviews");
  const file = path.join(directory, `${review.id}.json`);
  const temporary = `${file}.${process.pid}.tmp`;
  await fs.mkdir(directory, { recursive: true });
  await fs.writeFile(temporary, `${JSON.stringify(review, null, 2)}\n`);
  await fs.rename(temporary, file);
  return { ...review, receiptPath: path.relative(appRoot, file).replaceAll("\\", "/") };
}

export async function readVisualReviews(appRoot, { since = 0 } = {}) {
  const directory = path.join(appRoot, ".agent-handles", "visual-reviews");
  const names = await fs.readdir(directory).catch((error) => {
    if (error?.code === "ENOENT") return [];
    throw error;
  });
  const records = [];
  const invalid = [];
  for (const name of names.filter((candidate) => candidate.endsWith(".json")).sort()) {
    const file = path.join(directory, name);
    try {
      const record = JSON.parse(await fs.readFile(file, "utf8"));
      if (record.schema !== VISUAL_REVIEW_SCHEMA) throw new Error(`expected ${VISUAL_REVIEW_SCHEMA}`);
      if (since > 0 && Date.parse(record.measuredAt) < since) continue;
      records.push({ ...record, receiptPath: path.relative(appRoot, file).replaceAll("\\", "/") });
    } catch (error) {
      invalid.push({ file: path.relative(appRoot, file).replaceAll("\\", "/"), error: error.message });
    }
  }
  const issueTotals = records.reduce((totals, record) => {
    for (const key of Object.keys(totals)) totals[key] += Number(record.issues?.[key]) || 0;
    return totals;
  }, { unidentified: 0, unknown: 0, duplicate: 0, reviewRequired: 0 });
  return {
    schema: "agent-handles/page-state-review-summary/v1",
    records,
    invalid,
    pageStatesReviewed: records.length,
    routesReviewed: [...new Set(records.map((record) => record.route))].sort(),
    screenshots: records.filter((record) => record.screenshot).length,
    issueTotals,
    clean: invalid.length === 0 && Object.values(issueTotals).every((count) => count === 0),
    statement: `${records.length} page/state review receipt(s) across ${new Set(records.map((record) => record.route)).size} route(s); unvisited routes and states remain uncovered.`,
  };
}
