export interface AgentHandlesViteOptions {
  appRoot?: string;
  sourceRoot?: string;
  /** Explicit app and consumed-library directories; overrides sourceRoot. */
  sourceRoots?: string[];
  registryPath?: string;
  journeyManifestPath?: string;
  ratchetPath?: string;
  config?: Record<string, unknown>;
  /** Emit positive affected-test associations; AO retains selection authority. */
  affectedMap?: {
    /** Relative to appRoot; emitted source/test paths are relative to this root. */
    repositoryRoot?: string;
    fileName?: string;
    /** Existing test files, relative to appRoot, keyed by journey name. */
    testsByJourney?: Record<string, string[]>;
  };
}

// Keep the public seam Vite-version-neutral. Importing this package's own
// Vite Plugin type makes otherwise-compatible adopters fail when their Vite
// major differs; Vite only requires the structural plugin name from callers.
export interface AgentHandlesVitePlugin {
  name: "agent-handles";
}

export declare const VIRTUAL_CLIENT: "virtual:agent-handles-client";

export declare function agentHandles(options?: AgentHandlesViteOptions): AgentHandlesVitePlugin;

export default agentHandles;
