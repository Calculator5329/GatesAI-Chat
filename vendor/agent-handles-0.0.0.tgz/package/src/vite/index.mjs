// The Vite adapter. Verify-only at transform time (adding an id is a
// source-writing codemod, never an injection); the registry is a build
// artifact; the ratchet gates the build; the drive middleware and page
// executor exist only under `serve`, so a production build carries no
// executor. That last claim is enforced by test, not asserted.
import fs from "node:fs/promises";
import { createAdapter, renderClient } from "../adapter/index.mjs";
import { affectedBuildArtifacts } from "../affected/vite.mjs";
import path from "node:path";
import {
  scanTsxText,
  isRegistrySource,
} from "../scan/index.mjs";

const VIRTUAL_CLIENT = "virtual:agent-handles-client";
const RESOLVED_VIRTUAL_CLIENT = "\0virtual:agent-handles-client";

async function readJson(file, fallback) {
  try { return JSON.parse(await fs.readFile(file, "utf8")); }
  catch (error) {
    if (error?.code === "ENOENT") return fallback;
    throw error;
  }
}

/**
 * @param {object} [options]
 * @param {string} [options.appRoot]  defaults to Vite root; registry paths are relative to it
 * @param {string} [options.sourceRoot] defaults to <appRoot>/src
 * @param {string} [options.registryPath] defaults to <appRoot>/testid-registry.json
 * @param {string} [options.journeyManifestPath] defaults to <appRoot>/journeys/manifest.json
 * @param {string} [options.ratchetPath] defaults to <appRoot>/testid-ratchet.json
 * @param {object} [options.config] schema names for the registry (DEFAULT_CONFIG when absent)
 * @param {boolean} [options.writeRegistry] dev server rewrites the committed registry on source
 *   and journey-manifest saves (default true; false leaves it to `scan regenerate`)
 */
export default function agentHandles(options = {}) {
  let resolved; // filled from Vite's resolved config
  let isServe = false;

  let adapter;
  const paths = (...args) => adapter.paths(...args);
  const resolveConfig = (...args) => adapter.resolveConfig(...args);
  const renderCurrentRegistry = () => adapter.renderCurrentRegistry();
  const checkRatchet = (logger) => adapter.checkRatchet(logger);

  // Regenerate the committed registry at startup and after each save that
  // can change it. One sync runs at a time; a save during a sync runs one more
  // after it, so the last write always reflects the last save.
  function watchRegistry(server) {
    const logger = server.config.logger;
    let running = false;
    let again = false;
    let timer;
    let skippedOnce = false;
    const sync = async () => {
      if (running) { again = true; return; }
      running = true;
      try {
        do {
          again = false;
          try {
            const result = await adapter.syncRegistryFile();
            if (result.written) logger.info(`[agent-handles] ${path.relative(resolved.root, result.path)} updated: ${result.entries} identities`, { timestamp: true });
            if (result.skipped && !skippedOnce) { skippedOnce = true; logger.warn(`[agent-handles] ${result.skipped}`); }
          } catch (error) {
            logger.error(`[agent-handles] registry not updated: ${error.message}`, { timestamp: true });
          }
        } while (again);
      } finally {
        running = false;
      }
    };
    const schedule = () => { clearTimeout(timer); timer = setTimeout(sync, 150); };
    sync();
    server.watcher.on("all", (event, file) => {
      if (!["add", "change", "unlink"].includes(event)) return;
      const current = paths(resolved.root);
      const roots = current.sourceRoots ?? [current.sourceRoot];
      const isSource = isRegistrySource(path.basename(file))
        && roots.some((directory) => file.startsWith(directory + path.sep));
      if (isSource || file === current.journeyManifestPath) schedule();
    });
    server.httpServer?.once("close", () => clearTimeout(timer));
  }

  return {
    name: "agent-handles",

    configResolved(viteConfig) {
      resolved = viteConfig;
      adapter = createAdapter(options, resolved.root);
      isServe = viteConfig.command === "serve";
    },

    // Transform-time verification of the file being compiled. A sealed app
    // rejects invalid identities immediately; an active adoption carries them
    // as migration evidence so the dev server remains usable. Nothing is injected.
    async transform(code, id) {
      const file = id.split("?")[0];
      if (!isRegistrySource(path.basename(file))) return null;
      await resolveConfig(resolved.root);
      const relative = path.relative(paths(resolved.root).appRoot, file);
      const scan = scanTsxText(relative, code, {
        candidateMode: true,
        interactiveComponents: adapter.config.interactiveComponents,
      });
      if (scan.invalidIdentities.length > 0) {
        const adoptionState = await readJson(
          path.join(paths(resolved.root).appRoot, ".agent-handles/adoption-state.json"),
          null,
        );
        if (adoptionState?.status !== "in_progress" || adoptionState?.sealedRatchet) {
          const detail = scan.invalidIdentities
            .map(({ id: identity, line }) => `${identity} at ${relative}:${line}`)
            .join(", ");
          throw new Error(`invalid stable identities: ${detail}`);
        }
      }
      return null;
    },

    // Build: hold the ratchet, then ship the registry as a build artifact.
    async buildStart() {
      if (isServe) return; // dev handles this in configureServer, non-fatally
      await checkRatchet({ warn: (message) => this.warn(message) });
    },
    async generateBundle(_outputOptions, bundle) {
      const registrySource = await renderCurrentRegistry();
      this.emitFile({ type: "asset", fileName: "testid-registry.json", source: registrySource });
      const { appRoot, journeyManifestPath } = paths(resolved.root);
      const stored = await readJson(path.join(appRoot, "agent-handles.json"), {});
      const affectedMap = options.affectedMap ?? stored.affectedMap;
      if (affectedMap) {
        if (typeof affectedMap !== "object" || Array.isArray(affectedMap)) throw new Error("affectedMap must be an options object");
        const artifacts = await affectedBuildArtifacts({
          context: this,
          appRoot,
          config: affectedMap,
          registry: JSON.parse(registrySource),
          manifest: await readJson(journeyManifestPath, null),
          defaultTestFile: stored.playwrightSpecPath ?? "tests/journeys.spec.ts",
        });
        for (const artifact of artifacts) {
          if (bundle && Object.hasOwn(bundle, artifact.fileName)) throw new Error(`affected map cannot overwrite build artifact ${artifact.fileName}`);
          this.emitFile(artifact);
        }
      }
    },

    // Dev only: drive middleware plus the page executor. None of this branch
    // exists under `build`.
    configureServer(server) {
      const middleware = adapter.createMiddleware();
      server.middlewares.use((req, res, next) => {
        middleware.then((handler) => handler(req, res, next)).catch(next);
      });
      checkRatchet(server.config.logger).catch((error) => {
        server.config.logger.error(`[agent-handles] ${error.message}`);
      });
      if (options.writeRegistry !== false) watchRegistry(server);
    },
    resolveId(source) {
      if (source === VIRTUAL_CLIENT) return isServe ? RESOLVED_VIRTUAL_CLIENT : "\0empty";
      if (source === "\0empty") return source;
      return null;
    },
    async load(id) {
      if (id === RESOLVED_VIRTUAL_CLIENT) {
        return renderClient();
      }
      if (id === "\0empty") return "export {};";
      return null;
    },
    transformIndexHtml() {
      if (!isServe) return undefined;
      return [{ tag: "script", attrs: { type: "module", src: `/@id/${VIRTUAL_CLIENT}` }, injectTo: "body" }];
    },
  };
}

export { agentHandles, VIRTUAL_CLIENT };
