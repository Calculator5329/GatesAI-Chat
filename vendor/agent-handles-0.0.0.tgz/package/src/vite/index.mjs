// The Vite adapter. Verify-only at transform time (adding an id is a
// source-writing codemod, never an injection); the registry is a build
// artifact; the ratchet gates the build; the drive middleware and page
// executor exist only under `serve`, so a production build carries no
// executor. That last claim is enforced by test, not asserted.
import fs from "node:fs/promises";
import { affectedBuildArtifacts } from "../affected/vite.mjs";
import path from "node:path";
import {
  scanTsxText,
  isRegistrySource,
  DEFAULT_CONFIG,
  extendInteractiveComponents,
  renderRegistry,
} from "../scan/index.mjs";
import { assertRatchetNotRaised, evaluateRatchet, emptyRatchet, RATCHET_SCHEMA } from "../ratchet/index.mjs";
import { createDriveMiddleware, DRIVE_CLIENT_PATH } from "../drive/index.mjs";
import { renderRuntimeObservationPredicate } from "../runtime/observation.mjs";
import { readVisualReviews, writeVisualReview } from "../visual/review.mjs";

const VIRTUAL_CLIENT = "virtual:agent-handles-client";
const RESOLVED_VIRTUAL_CLIENT = "\0virtual:agent-handles-client";

async function readJson(file, fallback) {
  try { return JSON.parse(await fs.readFile(file, "utf8")); }
  catch (error) {
    if (error?.code === "ENOENT") return fallback;
    throw error;
  }
}

/**
 * @param {object} [options]
 * @param {string} [options.appRoot]  defaults to Vite root; registry paths are relative to it
 * @param {string} [options.sourceRoot] defaults to <appRoot>/src
 * @param {string} [options.registryPath] defaults to <appRoot>/testid-registry.json
 * @param {string} [options.journeyManifestPath] defaults to <appRoot>/journeys/manifest.json
 * @param {string} [options.ratchetPath] defaults to <appRoot>/testid-ratchet.json
 * @param {object} [options.config] schema names for the registry (DEFAULT_CONFIG when absent)
 */
export default function agentHandles(options = {}) {
  let resolved; // filled from Vite's resolved config
  let isServe = false;

  const paths = (root) => {
    const appRoot = options.appRoot ?? root;
    return {
      appRoot,
      sourceRoot: options.sourceRoot ?? path.join(appRoot, "src"),
      registryPath: options.registryPath ?? path.join(appRoot, "testid-registry.json"),
      journeyManifestPath: options.journeyManifestPath ?? path.join(appRoot, "journeys/manifest.json"),
      ratchetPath: options.ratchetPath ?? path.join(appRoot, "testid-ratchet.json"),
    };
  };
  // agent-handles.json's `interactiveComponents` keeps the plugin and the
  // CLI counting with the same predicate; explicit plugin options win.
  let config = options.config ?? DEFAULT_CONFIG;
  async function resolveConfig(root) {
    if (options.config) return;
    const stored = await readJson(path.join(paths(root).appRoot, "agent-handles.json"), {});
    config = extendInteractiveComponents(config, stored.interactiveComponents);
    if (stored.config) config = { ...config, ...stored.config };
    if (stored.controlJudgments) config = { ...config, controlJudgments: stored.controlJudgments };
    if (stored.identityRenames) config = { ...config, identityRenames: stored.identityRenames };
    if (stored.identityTombstones) config = { ...config, identityTombstones: stored.identityTombstones };
  }

  async function renderCurrentRegistry() {
    await resolveConfig(resolved.root);
    return renderRegistry({ ...paths(resolved.root), config });
  }

  // The build gate: regenerate the registry in memory and hold it to the
  // committed ratchet floors. Regression throws (build fails, loudly).
  async function checkRatchet(logger) {
    const { appRoot, ratchetPath } = paths(resolved.root);
    const registry = JSON.parse(await renderCurrentRegistry());
    const ratchet = await readJson(ratchetPath, emptyRatchet());
    if (ratchet.schema !== RATCHET_SCHEMA) {
      throw new Error(`${ratchetPath} does not carry schema ${RATCHET_SCHEMA}`);
    }
    const adoptionState = await readJson(path.join(appRoot, ".agent-handles/adoption-state.json"), null);
    const mode = adoptionState?.status === "in_progress" ? "adoption" : "sealed";
    if ((registry.invalidIdentities?.length ?? 0) > 0) {
      const examples = registry.invalidIdentities
        .slice(0, 5)
        .map(({ reason }) => reason)
        .join("; ");
      const detail = `${registry.invalidIdentities.length} invalid or legacy identity declaration(s) require migration: ${examples}`;
      if (mode === "sealed") throw new Error(detail);
      logger.warn(`[agent-handles] ${detail}`);
    }
    if (mode === "sealed") assertRatchetNotRaised(ratchet, adoptionState?.sealedRatchet);
    const result = evaluateRatchet(registry, ratchet, { mode });
    for (const warning of result.warnings) logger.warn(`[agent-handles] ${warning}`);
    return { registry, result };
  }

  return {
    name: "agent-handles",

    configResolved(viteConfig) {
      resolved = viteConfig;
      isServe = viteConfig.command === "serve";
    },

    // Transform-time verification of the file being compiled. A sealed app
    // rejects invalid identities immediately; an active adoption carries them
    // as migration evidence so the dev server remains usable. Nothing is injected.
    async transform(code, id) {
      const file = id.split("?")[0];
      if (!isRegistrySource(path.basename(file))) return null;
      await resolveConfig(resolved.root);
      const relative = path.relative(paths(resolved.root).appRoot, file);
      const scan = scanTsxText(relative, code, {
        candidateMode: true,
        interactiveComponents: config.interactiveComponents,
      });
      if (scan.invalidIdentities.length > 0) {
        const adoptionState = await readJson(
          path.join(paths(resolved.root).appRoot, ".agent-handles/adoption-state.json"),
          null,
        );
        if (adoptionState?.status !== "in_progress") {
          const detail = scan.invalidIdentities
            .map(({ id: identity, line }) => `${identity} at ${relative}:${line}`)
            .join(", ");
          throw new Error(`invalid stable identities: ${detail}`);
        }
      }
      return null;
    },

    // Build: hold the ratchet, then ship the registry as a build artifact.
    async buildStart() {
      if (isServe) return; // dev handles this in configureServer, non-fatally
      await checkRatchet({ warn: (message) => this.warn(message) });
    },
    async generateBundle(_outputOptions, bundle) {
      const registrySource = await renderCurrentRegistry();
      this.emitFile({ type: "asset", fileName: "testid-registry.json", source: registrySource });
      const { appRoot, journeyManifestPath } = paths(resolved.root);
      const stored = await readJson(path.join(appRoot, "agent-handles.json"), {});
      const affectedMap = options.affectedMap ?? stored.affectedMap;
      if (affectedMap) {
        if (typeof affectedMap !== "object" || Array.isArray(affectedMap)) throw new Error("affectedMap must be an options object");
        const artifacts = await affectedBuildArtifacts({
          context: this,
          appRoot,
          config: affectedMap,
          registry: JSON.parse(registrySource),
          manifest: await readJson(journeyManifestPath, null),
          defaultTestFile: stored.playwrightSpecPath ?? "tests/journeys.spec.ts",
        });
        for (const artifact of artifacts) {
          if (bundle && Object.hasOwn(bundle, artifact.fileName)) throw new Error(`affected map cannot overwrite build artifact ${artifact.fileName}`);
          this.emitFile(artifact);
        }
      }
    },

    // Dev only: drive middleware plus the page executor. None of this branch
    // exists under `build`.
    configureServer(server) {
      // Read fresh per request so manifest edits show up on the live map
      // without a server restart.
      const loadMapContext = async () => {
        const { appRoot, journeyManifestPath } = paths(resolved.root);
        const manifest = await readJson(journeyManifestPath, null);
        const stored = await readJson(path.join(appRoot, "agent-handles.json"), {});
        return {
          manifest,
          unreachable: stored.unreachableSurfaces,
          reviewSurfaces: stored.adoption?.reviewSurfaces ?? [],
          visualReviews: await readVisualReviews(appRoot),
          appLabel: stored.appLabel || path.basename(appRoot),
        };
      };
      const appRoot = paths(resolved.root).appRoot;
      server.middlewares.use(createDriveMiddleware({
        renderRegistry: renderCurrentRegistry,
        loadMapContext,
        loadVisualReviews: () => readVisualReviews(appRoot),
        recordVisualReview: (input) => writeVisualReview(appRoot, input),
      }));
      checkRatchet(server.config.logger).catch((error) => {
        server.config.logger.error(`[agent-handles] ${error.message}`);
      });
    },
    resolveId(source) {
      if (source === VIRTUAL_CLIENT) return isServe ? RESOLVED_VIRTUAL_CLIENT : "\0empty";
      if (source === "\0empty") return source;
      return null;
    },
    async load(id) {
      if (id === RESOLVED_VIRTUAL_CLIENT) {
        const client = await fs.readFile(DRIVE_CLIENT_PATH, "utf8");
        return `${renderRuntimeObservationPredicate()}\n\n${client}`;
      }
      if (id === "\0empty") return "export {};";
      return null;
    },
    transformIndexHtml() {
      if (!isServe) return undefined;
      return [{ tag: "script", attrs: { type: "module", src: `/@id/${VIRTUAL_CLIENT}` }, injectTo: "body" }];
    },
  };
}

export { agentHandles, VIRTUAL_CLIENT };
