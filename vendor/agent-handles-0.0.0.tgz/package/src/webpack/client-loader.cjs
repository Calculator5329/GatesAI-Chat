module.exports = function agentHandlesClientLoader() {
  const callback = this.async();
  import('../adapter/index.mjs').then(({ renderClient }) => renderClient())
    .then((source) => callback(null, `if (!window.__agentHandlesWebpackStarted) { window.__agentHandlesWebpackStarted = true;\n${source.replace(/^export /gm, "")}\n}`), callback);
};
