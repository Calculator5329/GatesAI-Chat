// Source for the dev-only executor loader. Production never references it.
