const path = require('node:path');
const PLUGIN = 'AgentHandlesPlugin';

// A synchronous CommonJS interface fits CRA/react-app-rewired as well as ESM
// configs. The shared registry/drive implementation loads only in Node hooks.
class AgentHandlesPlugin {
  constructor(options = {}) { this.options = options; }
  apply(compiler) {
    if (Number(compiler.webpack?.version?.split('.')[0]) !== 5) {
      throw new Error('Agent Handles requires Webpack 5.');
    }
    const root = this.options.appRoot ?? compiler.context;
    const adapter = import('../adapter/index.mjs').then(({ createAdapter }) => createAdapter(this.options, root));
    compiler.hooks.beforeCompile.tapPromise(PLUGIN, async () => {
      await (await adapter).checkRatchet(compiler.getInfrastructureLogger(PLUGIN));
    });
    compiler.hooks.thisCompilation.tap(PLUGIN, (compilation) => {
      compilation.hooks.processAssets.tapPromise({ name: PLUGIN,
        stage: compiler.webpack.Compilation.PROCESS_ASSETS_STAGE_ADDITIONAL }, async () => {
        const registry = await (await adapter).renderCurrentRegistry();
        if (compilation.getAsset('testid-registry.json')) throw new Error('Agent Handles registry asset already exists.');
        compilation.emitAsset('testid-registry.json', new compiler.webpack.sources.RawSource(registry));
      });
    });
    // Even an explicit drive:true cannot put the executor in production.
    if (compiler.options.mode === 'development' && this.options.drive === true) {
      const request = `${path.join(__dirname, 'client-loader.cjs')}!${path.join(__dirname, 'empty.js')}`;
      const prepend = (entries) => Object.fromEntries(Object.entries(entries).map(([name, entry]) => [name,
        { ...entry, import: [request, ...(entry.import ?? [])] }]));
      const entry = compiler.options.entry;
      compiler.options.entry = typeof entry === 'function' ? async () => prepend(await entry()) : prepend(entry);
    }
  }
}

function withAgentHandlesDevServer(config = {}, options = {}) {
  const setup = config.setupMiddlewares;
  // Do not eagerly import or create sessions while evaluating a build config.
  let middleware;
  return { ...config, setupMiddlewares(middlewares, server) {
    const result = setup ? setup.call(this, middlewares, server) : middlewares;
    if (!Array.isArray(result)) throw new Error('Existing setupMiddlewares must return a middleware array.');
    const root = options.appRoot ?? server?.compiler?.context;
    if (!root) throw new Error('Agent Handles dev-server requires appRoot or compiler.context.');
    middleware ??= import('../adapter/index.mjs').then(({ createAdapter }) => createAdapter(options, root).createMiddleware());
    result.unshift({ name: 'agent-handles', middleware(req, res, next) {
      middleware.then((handler) => handler(req, res, next)).catch(next);
    } });
    return result;
  } };
}

module.exports = { AgentHandlesPlugin, withAgentHandlesDevServer };
