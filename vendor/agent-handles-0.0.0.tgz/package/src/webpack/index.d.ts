import type { Compiler, WebpackPluginInstance } from "webpack";
export interface AgentHandlesWebpackOptions {
  appRoot?: string;
  sourceRoot?: string;
  /** Explicit app and consumed-library directories; overrides sourceRoot. */
  sourceRoots?: string[];
  registryPath?: string;
  journeyManifestPath?: string;
  ratchetPath?: string;
  config?: Record<string, unknown>;
  /** Explicit dev-server opt-in. Ignored in production mode. */
  drive?: boolean;
}
export declare class AgentHandlesPlugin implements WebpackPluginInstance {
  constructor(options?: AgentHandlesWebpackOptions);
  apply(compiler: Compiler): void;
}
export declare function withAgentHandlesDevServer<T extends Record<string, unknown>>(config?: T, options?: AgentHandlesWebpackOptions): T;
